#!/usr/bin/env python3
"""
Script2Vec Demo - Comprehensive demonstration of the Script2Vec library
integrated with CTRM-Powered LLM OS
"""

import asyncio
import json
import os
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from script2vec import (
    Script2Vec,
    CTRMScriptInterface,
    auto_vectorize,
    vectorize_class,
    create_web_interface
)
from ctrm_core.truth_manager import CTRMTruthManager
from ctrm_core.database import CTRMDatabase
from lm_studio.integration import LMStudioIntegration

async def demo_basic_conversion():
    """Demonstrate basic script to vector conversion"""
    print("🚀 Demo 1: Basic Script to Vector Conversion")

    s2v = Script2Vec()

    # Example Python script
    script = """
import numpy as np
from typing import List, Dict

class DataAnalyzer:
    '''A class for analyzing numerical data'''

    def __init__(self, data: List[float]):
        self.data = data
        self.mean = np.mean(data)
        self.std = np.std(data)

    def normalize(self) -> List[float]:
        '''Normalize data using z-score'''
        return [(x - self.mean) / self.std for x in self.data]

    def get_stats(self) -> Dict:
        '''Get basic statistics'''
        return {
            'mean': self.mean,
            'std': self.std,
            'min': min(self.data),
            'max': max(self.data),
            'range': max(self.data) - min(self.data)
        }

# Example usage
if __name__ == "__main__":
    analyzer = DataAnalyzer([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    normalized_data = analyzer.normalize()
    stats = analyzer.get_stats()
    print(f"Statistics: {stats}")
"""

    print("📝 Converting Python script to vector...")

    # Convert using different strategies
    semantic_vector = s2v.python_to_vector(script, strategy="semantic")
    ast_vector = s2v.python_to_vector(script, strategy="ast")
    hybrid_vector = s2v.python_to_vector(script, strategy="hybrid")

    print(f"✅ Semantic vector: {len(semantic_vector['vector'])} dimensions")
    print(f"✅ AST vector: {len(ast_vector['vector'])} dimensions")
    print(f"✅ Hybrid vector: {len(hybrid_vector['vector'])} dimensions")
    print(f"🔑 Script hash: {semantic_vector['script_hash']}")
    print(f"💡 Extracted concepts: {len(semantic_vector['concepts'])} concepts")
    print(f"📊 Cache stats: {s2v.get_cache_stats()}")

    return script

async def demo_ctrm_integration(script):
    """Demonstrate CTRM integration"""
    print("\n🔄 Demo 2: CTRM Integration")

    # Create CTRM interface
    ctrm_interface = CTRMScriptInterface()

    print("📡 Sending script to CTRM...")

    # Store script in CTRM
    ctrm_result = await ctrm_interface.script_to_ctrm(
        script,
        purpose="data_analysis",
        tags=["machine_learning", "data_processing", "statistics"],
        priority="high"
    )

    print(f"✅ CTRM storage successful!")
    print(f"🔑 CTRM vector hash: {ctrm_result['ctrm_vector_hash']}")
    print(f"📋 Metadata: {ctrm_result['metadata']}")

    # Find similar code
    print("\n🔍 Finding similar code in CTRM...")
    similar_results = await ctrm_interface.find_similar_code_in_ctrm(script, threshold=0.7)

    print(f"📊 Found {len(similar_results)} similar scripts")
    for i, result in enumerate(similar_results):
        print(f"  {i+1}. Similarity: {(result['similarity'] * 100):.1f}%")
        print(f"     Purpose: {result['likely_purpose']}")
        print(f"     Suggested use: {result['suggested_use']}")

    # Improve script
    print("\n💡 Getting improvement suggestions...")
    improvement_result = await ctrm_interface.improve_script_via_ctrm(
        script,
        improvement_type="optimize"
    )

    print(f"📋 Improvement suggestions ({len(improvement_result['suggestions'])}):")
    for suggestion in improvement_result['suggestions']:
        print(f"  - {suggestion['type']}: {suggestion['description']}")

    return ctrm_result

async def demo_decorators():
    """Demonstrate decorator usage"""
    print("\n🎯 Demo 3: Decorator Usage")

    # Create a CTRM manager for direct integration
    db = CTRMDatabase("data/script2vec_demo.db")
    await db.initialize()

    # Mock embedder for testing
    class MockEmbedder:
        async def embed(self, text: str) -> list:
            import numpy as np
            import hashlib
            hash_obj = hashlib.md5(text.encode())
            hash_int = int(hash_obj.hexdigest(), 16)
            np.random.seed(hash_int % 1000)
            return list(np.random.randn(1536))

    embedder = MockEmbedder()
    ctrm_manager = CTRMTruthManager(db, embedder)

    # Test auto_vectorize decorator
    @auto_vectorize(purpose="optimization_function", ctrm_manager=ctrm_manager)
    def optimize_data(data):
        """Optimize data processing"""
        return [x * 2 for x in data]

    # Test the decorated function
    result = optimize_data([1, 2, 3, 4, 5])
    print(f"✅ Decorated function result: {result}")

    # Get vector metadata
    metadata = optimize_data._vector_metadata
    if metadata:
        print(f"📊 Vector metadata: {len(metadata['vector'])} dimensions")
        print(f"🔑 Vector hash: {metadata['vector_hash']}")
        print(f"💡 Concepts: {len(metadata['concepts'])} concepts")

    # Test vectorize_class decorator
    @vectorize_class(purpose="data_processor", ctrm_manager=ctrm_manager)
    class DataProcessor:
        def __init__(self, data):
            self.data = data

        def process(self):
            return sum(self.data)

    processor = DataProcessor([1, 2, 3])
    processed_result = processor.process()
    print(f"✅ Class method result: {processed_result}")

    # Get class metadata
    class_metadata = DataProcessor._vector_metadata
    if class_metadata:
        print(f"📊 Class vector metadata: {len(class_metadata['vector'])} dimensions")

async def demo_file_and_directory_processing():
    """Demonstrate file and directory processing"""
    print("\n📁 Demo 4: File and Directory Processing")

    s2v = Script2Vec()

    # Create a temporary directory with Python files
    import tempfile
    import os

    with tempfile.TemporaryDirectory() as temp_dir:
        # Create some test files
        file_paths = []
        for i in range(3):
            file_path = os.path.join(temp_dir, f"test_{i}.py")
            with open(file_path, 'w') as f:
                f.write(f"""
def function_{i}(x, y):
    '''Function {i} for testing'''
    return x + y + {i}

class Class_{i}:
    def method(self):
        return {i}
""")
            file_paths.append(file_path)

        print(f"📁 Created {len(file_paths)} test files")

        # Process individual files
        for file_path in file_paths:
            file_result = s2v.embed_file(file_path)
            print(f"✅ Embedded {os.path.basename(file_path)}: {file_result['type']}")

        # Process entire directory
        directory_result = s2v.embed_directory(temp_dir)
        print(f"📊 Directory embedding: {directory_result['file_count']} files")
        print(f"🔑 Directory vector: {len(directory_result['directory_vector'])} dimensions")

async def demo_cli_usage():
    """Demonstrate CLI usage"""
    print("\n💻 Demo 5: CLI Usage")

    from script2vec.cli import Script2VecCLI

    cli = Script2VecCLI()

    # Create a temporary test file
    import tempfile
    import os

    with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
        f.write("""
def cli_test_function():
    '''Test function for CLI demo'''
    return "CLI works!"
""")
        temp_file = f.name

    try:
        # Create CLI args
        class Args:
            command = "convert"
            filepath = temp_file
            output = None
            strategy = "semantic"
            ctrm = False
            purpose = "cli_demo"

        # Run CLI command
        result = await cli._handle_convert(Args())
        print(f"✅ CLI conversion successful!")
        print(f"🔑 Script hash: {result['script_hash']}")
        print(f"📊 Vector dimensions: {len(result['vector'])}")

    finally:
        # Clean up
        os.unlink(temp_file)

async def demo_web_interface():
    """Demonstrate web interface"""
    print("\n🌐 Demo 6: Web Interface")

    try:
        # Create web interface
        web_interface = create_web_interface(host="127.0.0.1", port=8001)

        if web_interface.available:
            print("✅ Web interface created successfully!")
            print(f"🌐 Would run on: http://{web_interface.host}:{web_interface.port}")
            print("📋 Available endpoints:")
            print("  - GET / - Main page")
            print("  - POST /upload-script - Upload Python script")
            print("  - POST /find-similar - Find similar scripts")
            print("  - POST /improve-script - Improve script")
            print("  - GET /stats - System statistics")
        else:
            print("⚠️  Web interface not available (FastAPI not installed)")

    except ImportError:
        print("⚠️  Web interface not available (FastAPI not installed)")

async def demo_comprehensive_integration():
    """Demonstrate comprehensive integration with CTRM"""
    print("\n🔧 Demo 7: Comprehensive CTRM Integration")

    # Create all components
    s2v = Script2Vec()
    ctrm_interface = CTRMScriptInterface()

    # Example script that represents a complete data processing pipeline
    pipeline_script = """
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import joblib
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("data_pipeline")

class DataPipeline:
    '''End-to-end data processing and machine learning pipeline'''

    def __init__(self, config: dict):
        self.config = config
        self.scaler = StandardScaler()
        self.model = RandomForestClassifier(
            n_estimators=config.get('n_estimators', 100),
            max_depth=config.get('max_depth', 5),
            random_state=42
        )
        self.trained = False

    def load_data(self, filepath: str) -> pd.DataFrame:
        '''Load data from CSV file'''
        logger.info(f"Loading data from {filepath}")
        try:
            data = pd.read_csv(filepath)
            logger.info(f"Loaded {len(data)} records")
            return data
        except Exception as e:
            logger.error(f"Error loading data: {e}")
            raise

    def preprocess_data(self, data: pd.DataFrame) -> tuple:
        '''Preprocess data for machine learning'''
        logger.info("Preprocessing data")

        # Handle missing values
        data = data.fillna(data.mean())

        # Separate features and target
        X = data.drop(self.config['target_column'], axis=1)
        y = data[self.config['target_column']]

        # Scale features
        X_scaled = self.scaler.fit_transform(X)

        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X_scaled, y,
            test_size=self.config.get('test_size', 0.2),
            random_state=42
        )

        return X_train, X_test, y_train, y_test

    def train_model(self, X_train, y_train):
        '''Train the machine learning model'''
        logger.info("Training model")
        self.model.fit(X_train, y_train)
        self.trained = True
        logger.info("Model training completed")

    def evaluate_model(self, X_test, y_test) -> dict:
        '''Evaluate model performance'''
        if not self.trained:
            raise RuntimeError("Model not trained")

        logger.info("Evaluating model")
        predictions = self.model.predict(X_test)
        accuracy = accuracy_score(y_test, predictions)

        return {
            'accuracy': accuracy,
            'n_samples': len(y_test),
            'model_type': 'RandomForestClassifier',
            'timestamp': pd.Timestamp.now().isoformat()
        }

    def save_model(self, filepath: str):
        '''Save trained model to file'''
        if not self.trained:
            raise RuntimeError("Model not trained")

        logger.info(f"Saving model to {filepath}")
        joblib.dump({
            'model': self.model,
            'scaler': self.scaler,
            'config': self.config
        }, filepath)
        logger.info("Model saved successfully")

    def load_model(self, filepath: str):
        '''Load trained model from file'''
        logger.info(f"Loading model from {filepath}")
        saved_data = joblib.load(filepath)
        self.model = saved_data['model']
        self.scaler = saved_data['scaler']
        self.config = saved_data['config']
        self.trained = True
        logger.info("Model loaded successfully")

# Example usage
if __name__ == "__main__":
    # Configuration
    config = {
        'target_column': 'target',
        'n_estimators': 100,
        'max_depth': 5,
        'test_size': 0.2
    }

    # Create pipeline
    pipeline = DataPipeline(config)

    try:
        # Load and process data
        data = pipeline.load_data('data.csv')
        X_train, X_test, y_train, y_test = pipeline.preprocess_data(data)

        # Train and evaluate
        pipeline.train_model(X_train, y_train)
        evaluation = pipeline.evaluate_model(X_test, y_test)

        print(f"Model evaluation: {evaluation}")

        # Save model
        pipeline.save_model('trained_model.joblib')

    except Exception as e:
        logger.error(f"Pipeline failed: {e}")
        raise
"""

    print("📝 Processing comprehensive data pipeline script...")

    # Convert to vector
    vector_result = s2v.python_to_vector(pipeline_script, strategy="hybrid")
    print(f"✅ Hybrid vector: {len(vector_result['vector'])} dimensions")

    # Convert to CTRM format
    ctrm_format = s2v.to_ctrm_format(pipeline_script, {
        "source": "data_pipeline",
        "complexity": "high",
        "domain": "machine_learning"
    })

    print(f"📋 CTRM format: {len(ctrm_format['concepts'])} concepts")

    # Store in CTRM
    ctrm_result = await ctrm_interface.script_to_ctrm(
        pipeline_script,
        purpose="machine_learning_pipeline",
        tags=["ml", "data_processing", "end_to_end"],
        complexity="high"
    )

    print(f"✅ CTRM storage: {ctrm_result['status']}")

    # Analyze script quality
    quality_result = await ctrm_interface.analyze_script_quality(pipeline_script)
    print(f"📊 Quality score: {quality_result['quality_score']:.2f}")

    # Track evolution (simulate by modifying the script slightly)
    modified_script = pipeline_script.replace("RandomForestClassifier", "GradientBoostingClassifier")
    evolution_result = await ctrm_interface.track_script_evolution(
        modified_script,
        pipeline_script
    )

    print(f"🔄 Evolution tracking: Generation {evolution_result['generation']}")

async def main():
    """Run all demonstrations"""
    print("🎯 Script2Vec Comprehensive Demo")
    print("=" * 50)

    try:
        # Run all demos
        script = await demo_basic_conversion()
        await demo_ctrm_integration(script)
        await demo_decorators()
        await demo_file_and_directory_processing()
        await demo_cli_usage()
        await demo_web_interface()
        await demo_comprehensive_integration()

        print("\n🎉 All demos completed successfully!")
        print("\n📋 Script2Vec Features Demonstrated:")
        print("  ✅ Basic script to vector conversion")
        print("  ✅ Multiple embedding strategies (semantic, AST, hybrid)")
        print("  ✅ CTRM integration and storage")
        print("  ✅ Similar code finding")
        print("  ✅ Script improvement suggestions")
        print("  ✅ Decorator-based automatic vectorization")
        print("  ✅ File and directory processing")
        print("  ✅ CLI interface")
        print("  ✅ Web interface")
        print("  ✅ Comprehensive CTRM integration")

    except Exception as e:
        print(f"❌ Demo failed: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(main())