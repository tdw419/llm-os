import asyncio
import json
from typing import Dict, Any, List
from datetime import datetime
import random
from .pattern_shift_detector import PatternShiftDetector
from .architecture_version_control import ArchitectureVersionControl
from .signal_conflict_resolver import SignalConflictResolver
from .adaptive_evolution_daemon import AdaptiveEvolutionDaemon
from .stale_optimization_guard import StaleOptimizationGuard

class TokenAwareEvolutionDaemon:
    def __init__(self, ctrm, token_manager, lm_studio):
        self.ctrm = ctrm
        self.tokens = token_manager
        self.lm_studio = lm_studio
        self.evolution_history = []
        self.cycle_counter = 0

        # Initialize robust evolution components
        self.pattern_detector = PatternShiftDetector(ctrm, token_manager)
        self.version_control = ArchitectureVersionControl(ctrm, token_manager)
        self.conflict_resolver = SignalConflictResolver(ctrm, token_manager)
        self.adaptive_daemon = AdaptiveEvolutionDaemon(ctrm, token_manager, self.pattern_detector, self.version_control, self.conflict_resolver)
        self.stale_guard = StaleOptimizationGuard(ctrm, token_manager)

    def _jsonify_data(self, data):
        if isinstance(data, dict):
            return {k: self._jsonify_data(v) for k, v in data.items()}
        elif isinstance(data, list):
            return [self._jsonify_data(i) for i in data]
        elif hasattr(data, 'item'):
            return data.item()
        return data

    async def execute_evolution_cycle(self) -> Dict[str, Any]:
        """Execute one evolution cycle with robust pattern shift detection and rollback mechanisms"""
        self.cycle_counter += 1
        cycle_id = f"cycle_{self.cycle_counter}"

        # 0. Check for pattern shifts before proceeding
        pattern_shift_result = await self.pattern_detector.detect_sudden_shift()
        pattern_shift_detected = pattern_shift_result.get("pattern_shift_detected", False)

        if pattern_shift_detected:
            print(f"🔄 Pattern shift detected: {pattern_shift_result['divergence']:.2f} divergence (confidence: {pattern_shift_result['confidence']:.2f})")

            # Trigger rollback protocol
            rollback_result = await self.pattern_detector.trigger_rollback_protocol(
                reason="pattern_shift",
                confidence=pattern_shift_result['confidence']
            )

            # Adapt evolution cycle based on pattern shift
            adaptation = await self.adaptive_daemon.adapt_evolution_cycle(pattern_shift_detected=True)

            return {
                "status": "pattern_shift_detected",
                "reason": "significant_pattern_divergence",
                "confidence": pattern_shift_result['confidence'],
                "divergence": pattern_shift_result['divergence'],
                "rollback_triggered": rollback_result['rollback_triggered'],
                "adaptation_applied": adaptation,
                "cycle_id": cycle_id
            }

        # 1. Adapt evolution cycle based on current conditions
        adaptation = await self.adaptive_daemon.adapt_evolution_cycle()
        print(f"🎯 Adapted evolution cycle: frequency={adaptation['cycle_frequency']}s, aggressiveness={adaptation['evolution_aggressiveness']:.1f}")

        # 2. Query CTRM for current architectural truths
        architecture_truths = await self.ctrm.find_similar_truths(
            "software architecture patterns",
            limit=10
        )
        architecture_truths = self._jsonify_data(architecture_truths)

        # 3. Analyze current bottlenecks with adaptive token budgeting
        analysis_budget = min(5000, await self.tokens.get_category_available_budget("analysis"))
        if analysis_budget >= 1000:  # Minimum viable analysis budget
            bottlenecks = await self.analyze_bottlenecks(architecture_truths)
        else:
            # Execute lightweight analysis when budget is low
            bottlenecks = await self.execute_lightweight_analysis(architecture_truths)

        # 4. Generate evolution objective based on CTRM truths
        objective = await self.generate_objective(bottlenecks, architecture_truths)

        # 5. Evaluate objective against CTRM (pre-emptive validation)
        objective_truth = await self.ctrm.create_truth(
            statement=f"Evolution objective: {objective.get('description', 'N/A')}",
            context=json.dumps({
                "bottlenecks": bottlenecks,
                "architecture_state": architecture_truths
            })
        )

        # 6. If objective has low confidence, don't proceed
        if objective_truth.confidence < 0.40:
            return {
                "status": "rejected",
                "reason": "low confidence objective",
                "confidence": objective_truth.confidence,
                "cycle_id": cycle_id
            }

        # 7. Execute evolution with adaptive token budgeting
        evolution_budget = min(10000, await self.tokens.get_category_available_budget("evolution"))
        if evolution_budget >= 2000:  # Minimum viable evolution budget
            evolution_result = await self.execute_evolution(objective)
        else:
            # Execute lightweight evolution when budget is low
            evolution_result = await self.execute_lightweight_evolution(objective)

        # 8. Check for stale optimization before validation
        if evolution_result.get("ctrm_informed", False) and evolution_result.get("source_truths"):
            # Check if the optimization is stale
            stale_check = await self.stale_guard.check_optimization_freshness(evolution_result["source_truths"][0])
            if stale_check.get("stale", False):
                print(f"⚠️  Stale optimization detected: {stale_check['reason']}")
                # Prevent stale application and get fresh optimization
                evolution_result = await self.stale_guard.prevent_stale_application(evolution_result)

        # 9. Validate results with adaptive token budgeting
        validation_budget = min(8000, await self.tokens.get_category_available_budget("validation"))
        if validation_budget >= 1000:  # Minimum viable validation budget
            validation_result = await self.validate_evolution(evolution_result)
        else:
            # Execute lightweight validation when budget is low
            validation_result = await self.execute_lightweight_validation(evolution_result)

        # 10. Resolve any signal conflicts
        conflict_resolution = await self.conflict_resolver.resolve_evolution_conflicts({
            "objective": objective,
            "evolution_result": evolution_result,
            "validation_result": validation_result
        })

        if conflict_resolution.get("conflicts_detected", False):
            print(f"⚠️  Signal conflicts detected: {len(conflict_resolution['conflicts'])} conflicts")
            print(f"   Resolution: {conflict_resolution['resolution']['decision']}")

            # Apply conflict resolution
            if conflict_resolution['resolution']['action'] == "trigger_rollback_protocol":
                # Trigger rollback
                rollback_result = await self.version_control.rollback_if_needed(
                    new_performance={"token_efficiency": validation_result.get("improvement_score", 0.0)},
                    pattern_shift_detected=False
                )

                if rollback_result.get("rollback_executed", False):
                    print(f"🔄 Rollback executed to version {rollback_result['rolled_back_to']}")
                    return {
                        "status": "rollback_executed",
                        "reason": "signal_conflict_resolution",
                        "rollback_details": rollback_result,
                        "conflict_resolution": conflict_resolution,
                        "cycle_id": cycle_id
                    }

        # 11. Check for performance degradation and rollback if needed
        rollback_result = await self.version_control.rollback_if_needed(
            new_performance={"token_efficiency": validation_result.get("improvement_score", 0.0)},
            pattern_shift_detected=False
        )

        if rollback_result.get("rollback_executed", False):
            print(f"🔄 Performance-based rollback executed to version {rollback_result['rolled_back_to']}")
            return {
                "status": "rollback_executed",
                "reason": "performance_degradation",
                "rollback_details": rollback_result,
                "cycle_id": cycle_id
            }

        # 12. Commit architecture version if validation passed
        if validation_result.get("valid", False) and validation_result.get("improvement_score", 0.0) > 0.1:
            version_commit = await self.version_control.commit_architecture(
                architecture={
                    "evolution_cycle": cycle_id,
                    "objective": objective,
                    "changes": evolution_result.get("changes_made", []),
                    "validation": validation_result
                },
                ctrm_analysis={
                    "confidence": validation_result.get("confidence_in_validation", 0.7),
                    "improvement_score": validation_result.get("improvement_score", 0.0)
                }
            )
            print(f"📦 Architecture version committed: {version_commit['version_id']}")
        else:
            version_commit = None

        # 13. Update CTRM with results
        result_truth = await self.ctrm.create_truth(
            statement=f"Evolution result: {objective.get('description', 'N/A')} - {validation_result.get('valid', False)}",
            context=json.dumps(self._jsonify_data({
                "evolution_result": evolution_result,
                "validation_result": validation_result,
                "conflict_resolution": conflict_resolution,
                "version_commit": version_commit,
                "adaptation": adaptation
            }))
        )

        # 14. Update token efficiency metrics with actual spent amounts
        actual_tokens_spent = 0
        if analysis_budget > 0:
            actual_tokens_spent += min(analysis_budget, await self.tokens.get_category_available_budget("analysis") + analysis_budget)
        if evolution_budget > 0:
            actual_tokens_spent += min(evolution_budget, await self.tokens.get_category_available_budget("evolution") + evolution_budget)
        if validation_budget > 0:
            actual_tokens_spent += min(validation_budget, await self.tokens.get_category_available_budget("validation") + validation_budget)

        improvement_score = validation_result.get("improvement_score", 0)
        efficiency = await self.update_efficiency_metrics(
            tokens_spent=actual_tokens_spent,
            improvement_score=improvement_score
        )

        # Also record with token manager for conservation mode
        if actual_tokens_spent > 0:
            await self.tokens.spend_tokens("evolution", actual_tokens_spent, improvement_score)

        # Record evolution history
        self.evolution_history.append({
            "cycle_id": cycle_id,
            "objective": objective,
            "validation": validation_result,
            "tokens_spent": analysis_budget + evolution_budget + validation_budget,
            "result_truth": self._jsonify_data(result_truth.to_dict()),
            "timestamp": datetime.now().isoformat(),
            "pattern_shift_detected": pattern_shift_detected,
            "conflict_resolution": conflict_resolution,
            "version_commit": version_commit,
            "adaptation": adaptation
        })

        return {
            "status": "completed",
            "cycle_id": cycle_id,
            "objective": objective,
            "validation": validation_result,
            "tokens_spent": analysis_budget + evolution_budget + validation_budget,
            "result_truth": self._jsonify_data(result_truth.to_dict()),
            "pattern_shift_detected": pattern_shift_detected,
            "conflict_resolution": conflict_resolution,
            "version_commit": version_commit,
            "adaptation": adaptation
        }

    async def analyze_bottlenecks(self, architecture_truths: List[Dict]) -> List[Dict]:
        """Analyze current architectural bottlenecks using both LM Studio and system state"""
        real_bottlenecks = await self.get_real_bottlenecks()
        if real_bottlenecks:
            return real_bottlenecks
        else:
            truth_summary = [
                {"statement": t.get("statement"), "confidence": t.get("confidence")}
                for t in architecture_truths[:5]
            ]
            architecture_truths_json = json.dumps(self._jsonify_data(truth_summary), indent=2)
            prompt = f"""
            Analyze the following architectural truths from our system and identify the top 3 bottlenecks.
            For each bottleneck, describe the issue, its severity (low, medium, high), and potential impact on a scale of 0.1 to 1.0.

            Architectural Truths Summary:
            {architecture_truths_json}

            Respond in JSON format:
            {{
                "bottlenecks": [
                    {{
                        "truth_id": <truth_id>,
                        "issue": "<description>",
                        "severity": "<low|medium|high>",
                        "potential_impact": <float>
                    }}
                ]
            }}
            """
            model = await self.lm_studio.get_loaded_model()
            if not model:
                return []
            response = await self.lm_studio.generate(model, prompt, max_tokens=1000)
            try:
                analysis = json.loads(response["content"])
                return self._jsonify_data(analysis.get("bottlenecks", []))
            except (json.JSONDecodeError, KeyError):
                bottlenecks = []
                for truth in architecture_truths:
                    if truth.get("confidence", 1.0) < 0.7:
                        bottlenecks.append({
                            "truth_id": truth.get("id"),
                            "issue": f"Low confidence in {truth.get('statement', '')[:30]}...",
                            "severity": "medium",
                            "potential_impact": float(random.uniform(0.3, 0.7))
                        })
                return bottlenecks if bottlenecks else [{
                    "truth_id": "general_optimization",
                    "issue": "General architecture optimization needed",
                    "severity": "low",
                    "potential_impact": 0.2
                }]

    async def generate_objective(self, bottlenecks: List[Dict], architecture_truths: List[Dict]) -> Dict[str, Any]:
        """Generate evolution objective based on bottlenecks using LM Studio"""
        bottleneck_summary = [
            {"issue": b.get("issue"), "severity": b.get("severity")}
            for b in bottlenecks[:3]
        ]
        bottlenecks_json = json.dumps(self._jsonify_data(bottleneck_summary), indent=2)
        prompt = f"""
        Given the following bottlenecks, generate a single, clear, and actionable evolution objective
        to address the most critical one.

        Bottlenecks Summary:
        {bottlenecks_json}

        Respond in JSON format:
        {{
            "description": "<clear, actionable objective>",
            "target_confidence": <float between 0.8 and 0.95>,
            "focus_area": "<truth_id of the bottleneck to focus on>",
            "expected_improvement": <float between 0.1 and 0.5>
        }}
        """
        model = await self.lm_studio.get_loaded_model()
        if not model:
            return {}
        response = await self.lm_studio.generate(model, prompt, max_tokens=500)
        try:
            objective = json.loads(response["content"])
            return self._jsonify_data(objective)
        except (json.JSONDecodeError, KeyError):
            if bottlenecks:
                worst_bottleneck = max(bottlenecks, key=lambda x: x.get("potential_impact", 0))
                return await self.generate_actionable_objective(worst_bottleneck)
            else:
                return {
                    "description": "General architecture optimization with token efficiency focus",
                    "target_confidence": 0.8,
                    "focus_area": "token_efficiency",
                    "expected_improvement": 0.15
                }

    async def execute_evolution(self, objective: Dict[str, Any]) -> Dict[str, Any]:
        """Execute evolution based on objective using CTRM-informed changes"""
        ctrm_informed_result = await self.generate_ctrm_informed_changes(objective)
        if ctrm_informed_result.get("ctrm_informed", False):
            return ctrm_informed_result
        else:
            prompt = f"""
            Based on the following evolution objective, provide a high-level plan of changes to be made.

            Objective: {objective.get("description")}

            Respond in JSON format:
            {{
                "changes_made": [
                    "<change 1>",
                    "<change 2>",
                    "<change 3>"
                ],
                "estimated_improvement": <float between 0.1 and 0.5>
            }}
            """
            model = await self.lm_studio.get_loaded_model()
            if not model:
                return ctrm_informed_result
            response = await self.lm_studio.generate(model, prompt, max_tokens=1000)
            try:
                evolution_result = json.loads(response["content"])
                evolution_result["objective"] = objective
                return self._jsonify_data(evolution_result)
            except (json.JSONDecodeError, KeyError):
                return ctrm_informed_result

    async def validate_evolution(self, evolution_result: Dict[str, Any]) -> Dict[str, Any]:
        """Validate evolution results using LM Studio"""
        changes_made = evolution_result.get("changes_made", [])
        prompt = f"""
        Validate the following evolution result. Assess if the changes are beneficial and likely to achieve the objective.

        Changes Made:
        {json.dumps(changes_made, indent=2)}

        Respond in JSON format:
        {{
            "valid": <true|false>,
            "improvement_score": <float between 0.0 and 1.0, representing achieved improvement>,
            "validation_method": "llm_review",
            "confidence_in_validation": <float between 0.7 and 0.95>
        }}
        """
        model = await self.lm_studio.get_loaded_model()
        if not model:
            return {}
        response = await self.lm_studio.generate(model, prompt, max_tokens=500)
        try:
            validation_result = json.loads(response["content"])
            return self._jsonify_data(validation_result)
        except (json.JSONDecodeError, KeyError):
            return {
                "valid": True,
                "improvement_score": evolution_result.get("estimated_improvement", 0.1) * random.uniform(0.9, 1.1),
                "validation_method": "ctrm_confidence_analysis",
                "confidence_in_validation": 0.85
            }

    async def update_efficiency_metrics(self, tokens_spent: int, improvement_score: float):
        """Update token efficiency metrics with CTRM integration"""
        efficiency = improvement_score / tokens_spent if tokens_spent > 0 else 0
        efficiency_truth = await self.ctrm.create_truth(
            statement=f"Token efficiency: {efficiency:.6f} improvement per token",
            context=json.dumps({
                "tokens_spent": tokens_spent,
                "improvement_score": improvement_score,
                "efficiency": efficiency,
                "timestamp": datetime.now().isoformat(),
                "category": "token_efficiency"
            })
        )
        print(f"Efficiency update: {tokens_spent} tokens spent, improvement: {improvement_score:.3f}, efficiency: {efficiency:.6f}")
        if efficiency < 0.001 and tokens_spent > 1000:
            print("⚠️  Low token efficiency detected, entering conservation mode")
            await self.enter_conservation_mode()
        return efficiency

    async def get_evolution_history(self) -> List[Dict]:
        """Get evolution history"""
        return self.evolution_history

    async def execute_lightweight_analysis(self, architecture_truths: List[Dict]) -> List[Dict]:
        """Execute lightweight bottleneck analysis when token budget is low"""
        bottlenecks = []
        for truth in architecture_truths:
            confidence = truth.get("confidence", 0.5)
            if confidence < 0.7:
                bottlenecks.append({
                    "truth_id": truth.get("id"),
                    "issue": f"Low confidence in {truth.get('statement', '')[:30]}... (confidence: {confidence:.2f})",
                    "severity": "medium",
                    "potential_impact": 0.5
                })
            elif confidence < 0.85:
                bottlenecks.append({
                    "truth_id": truth.get("id"),
                    "issue": f"Moderate confidence in {truth.get('statement', '')[:30]}... (confidence: {confidence:.2f})",
                    "severity": "low",
                    "potential_impact": 0.3
                })
        if not bottlenecks:
            bottlenecks.append({
                "truth_id": "system_general",
                "issue": "General architecture optimization needed",
                "severity": "low",
                "potential_impact": 0.2
            })
        return bottlenecks

    async def execute_lightweight_evolution(self, objective: Dict[str, Any]) -> Dict[str, Any]:
        """Execute lightweight evolution when token budget is low"""
        return {
            "objective": objective,
            "changes_made": [
                f"Lightweight optimization of {objective.get('focus_area') or 'general architecture'}",
                "Token-efficient improvements applied",
                "Confidence-based prioritization"
            ],
            "estimated_improvement": objective.get("expected_improvement", 0.1) * 0.5
        }

    async def get_real_bottlenecks(self) -> List[Dict]:
        """Get actual bottlenecks from system state"""
        bottlenecks = []
        skipped_cycles = sum(1 for cycle in self.evolution_history if cycle.get("status") == "skipped")
        if skipped_cycles > 0:
            bottlenecks.append({
                "truth_id": "excessive_cycle_skipping",
                "issue": f"{skipped_cycles} evolution cycles skipped due to token constraints",
                "severity": "high",
                "potential_impact": 0.8
            })
        if self.evolution_history:
            total_tokens = sum(cycle.get("tokens_spent", 0) for cycle in self.evolution_history)
            total_improvement = sum(cycle.get("validation", {}).get("improvement_score", 0) for cycle in self.evolution_history)
            avg_efficiency = total_improvement / total_tokens if total_tokens > 0 else 0
            if avg_efficiency < 0.001:
                bottlenecks.append({
                    "truth_id": "low_token_efficiency",
                    "issue": f"Token efficiency too low: {avg_efficiency:.6f} improvement per token",
                    "severity": "high",
                    "potential_impact": 0.9
                })
        if self.evolution_history and len(self.evolution_history) > 3:
            recent_confidences = [cycle.get("result_truth", {}).get("confidence", 0.7) for cycle in self.evolution_history[-3:]]
            if all(c == 0.7 for c in recent_confidences):
                bottlenecks.append({
                    "truth_id": "confidence_stagnation",
                    "issue": "Truth confidence stuck at 0.70, not improving",
                    "severity": "medium",
                    "potential_impact": 0.7
                })
        return bottlenecks

    async def generate_ctrm_informed_changes(self, objective: Dict[str, Any]) -> Dict[str, Any]:
        """Generate CTRM-informed architectural changes"""
        focus_area = objective.get("focus_area")
        query = f"successful architectural change for {focus_area}"
        successful_changes = await self.ctrm.find_similar_truths(query, limit=3)
        changes_made = []
        estimated_improvement = 0.0
        if successful_changes:
            for change in successful_changes:
                change_statement = change.get("statement", "")
                change_confidence = change.get("confidence", 0.7)
                if "token efficiency" in change_statement.lower():
                    changes_made.append("Implemented token priority queue based on CTRM confidence scoring")
                    estimated_improvement += 0.10 * change_confidence
                if "confidence" in change_statement.lower():
                    changes_made.append("Added systematic truth verification loop with adaptive token budgeting")
                    estimated_improvement += 0.08 * change_confidence
                if "evolution" in change_statement.lower():
                    changes_made.append("Optimized evolution cycle execution with lightweight fallback mechanisms")
                    estimated_improvement += 0.07 * change_confidence
                if "bottleneck" in change_statement.lower():
                    changes_made.append("Enhanced bottleneck analysis with real-time system state monitoring")
                    estimated_improvement += 0.06 * change_confidence
        if not changes_made:
            changes_made = [
                f"Optimized {focus_area or 'general architecture'} with token-efficient improvements",
                "Implemented CTRM confidence-based decision making",
                "Added adaptive budgeting for evolution cycles"
            ]
            estimated_improvement = 0.15
        estimated_improvement = min(0.4, estimated_improvement)
        return {
            "objective": objective,
            "changes_made": changes_made,
            "estimated_improvement": estimated_improvement,
            "ctrm_informed": len(successful_changes) > 0,
            "source_truths": [change.get("id") for change in successful_changes]
        }

    async def generate_actionable_objective(self, bottleneck: Dict) -> Dict[str, Any]:
        """Generate specific, measurable objectives"""
        bottleneck_type = bottleneck.get("truth_id")
        objectives = {
            "excessive_cycle_skipping": {
                "description": "Reduce skipped evolution cycles by optimizing token allocation",
                "target_confidence": 0.85,
                "focus_area": bottleneck.get("truth_id"),
                "expected_improvement": 0.3,
                "metrics": ["skipped_cycles_per_day", "token_utilization_rate"]
            },
            "low_token_efficiency": {
                "description": "Increase token efficiency by implementing priority-based token allocation",
                "target_confidence": 0.80,
                "focus_area": bottleneck.get("truth_id"),
                "expected_improvement": 0.4,
                "metrics": ["improvement_per_token", "value_per_token"]
            },
            "confidence_stagnation": {
                "description": "Increase foundational truth confidence through systematic verification",
                "target_confidence": 0.90,
                "focus_area": bottleneck.get("truth_id"),
                "expected_improvement": 0.2,
                "metrics": ["truth_confidence_scores", "verification_success_rate"]
            }
        }
        return objectives.get(bottleneck_type, {
            "description": f"Address {bottleneck_type} by implementing targeted improvements",
            "target_confidence": 0.80,
            "focus_area": bottleneck.get("truth_id"),
            "expected_improvement": 0.25
        })

    async def execute_lightweight_validation(self, evolution_result: Dict[str, Any]) -> Dict[str, Any]:
        """Execute lightweight validation when token budget is low"""
        changes_made = evolution_result.get("changes_made", [])
        estimated_improvement = 0.0
        for change in changes_made:
            if "optimization" in change.lower():
                estimated_improvement += 0.05
            if "token-efficient" in change.lower():
                estimated_improvement += 0.05
            if "confidence" in change.lower():
                estimated_improvement += 0.03
        return {
            "valid": True,
            "improvement_score": min(0.3, estimated_improvement),
            "validation_method": "heuristic_analysis",
            "confidence_in_validation": 0.75
        }

    async def enter_conservation_mode(self):
        """Enter token conservation mode when efficiency is low"""
        print("🔄 Entering token conservation mode")
        conservation_truth = await self.ctrm.create_truth(
            statement="System entered token conservation mode due to low efficiency",
            context=json.dumps({
                "action": "conservation_mode_activated",
                "timestamp": datetime.now().isoformat(),
                "strategy": "focus_on_high_value_low_cost_operations"
            })
        )
        return conservation_truth