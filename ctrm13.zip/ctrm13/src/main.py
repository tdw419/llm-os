import asyncio
import json
from typing import Dict, Any
from datetime import datetime
from ctrm_core.database import CTRMDatabase
from ctrm_core.truth_manager import CTRMTruthManager
from token_manager.token_manager import TokenManager
from evolution.evolution_daemon import TokenAwareEvolutionDaemon
from lm_studio.integration import VectorModelRouter, CTRMPromptOptimizer, LMStudioIntegration
from vector_llm_tools.vector_analytics import VectorAnalyticsForLLMs
from vector_llm_tools.vector_qa import VectorQAForLLMs
from vector_llm_tools.vector_evolution_tracker import VectorEvolutionTracker
from vector_llm_tools.vector_protocol import LLMVectorProtocol
from vector_llm_tools.vector_space_mapper import VectorSpaceMapper
from vector_llm_tools.vector_interface import CTRMVectorInterface

class MockEmbedder:
    """Mock embedding model for testing"""
    async def embed(self, text: str) -> list:
        # Simple mock embedding - in reality this would use a proper embedding model
        import numpy as np
        import hashlib

        # Create a deterministic "embedding" based on text hash
        hash_obj = hashlib.md5(text.encode())
        hash_int = int(hash_obj.hexdigest(), 16)

        # Create a 1536-dimensional vector (simplified for mock)
        np.random.seed(hash_int % 1000)
        return list(np.random.randn(1536))

class CTRMLLMOSDaemon:
    def __init__(self):
        self.embedder = MockEmbedder()
        self.db = CTRMDatabase("data/ctrm_llm_os.db")
        self.ctrm = CTRMTruthManager(self.db, self.embedder)
        self.token_manager = TokenManager()
        self.lm_studio = LMStudioIntegration()
        self.model_router = VectorModelRouter(self.ctrm)
        self.prompt_optimizer = CTRMPromptOptimizer(self.ctrm)
        self.evolution_daemon = TokenAwareEvolutionDaemon(self.ctrm, self.token_manager, self.lm_studio)

        # Initialize LLM-optimized vector tools
        self.vector_analytics = VectorAnalyticsForLLMs(self.ctrm, self.lm_studio)
        self.vector_qa = VectorQAForLLMs(self.ctrm, self.lm_studio)
        self.vector_evolution = VectorEvolutionTracker(self.ctrm, self.lm_studio, self.db)
        self.vector_protocol = LLMVectorProtocol(
            self.ctrm, self.lm_studio,
            self.vector_analytics, self.vector_qa, self.vector_evolution
        )
        self.vector_mapper = VectorSpaceMapper(self.ctrm, self.lm_studio, self.db)
        self.vector_interface = CTRMVectorInterface(
            self.ctrm, self.lm_studio, self.db,
            self.vector_analytics, self.vector_qa,
            self.vector_evolution, self.vector_protocol,
            self.vector_mapper
        )

        # Initialize with foundational truths
        self.foundational_truths = [
            "We develop this system to honor our Creator",
            "CTRM provides the knowledge management framework",
            "Token efficiency is critical for sustainable operation",
            "Architectural stability is more important than novelty",
            "Validation must precede deployment of changes"
        ]

    async def initialize(self):
        """Initialize system with foundational truths"""
        print("🚀 Initializing CTRM-Powered LLM OS")

        # Initialize database
        await self.db.initialize()

        # Load or create foundational truths
        for truth_statement in self.foundational_truths:
            existing = await self.ctrm.find_similar_truths(truth_statement, limit=1)
            if not existing or existing[0]["confidence"] < 0.9:
                foundational_truth = await self.ctrm.create_truth(
                    statement=truth_statement,
                    context="system_foundation"
                )
                print(f"  📜 {foundational_truth.statement} (confidence: {foundational_truth.confidence:.2f})")

        # Initialize token budget
        await self.token_manager.reset_daily_budget()

        print("✅ CTRM LLM OS initialized")

    async def run_continual_evolution(self):
        """Main daemon loop"""
        print("🔄 Starting continual evolution loop")

        while True:
            await self.token_manager.reset_daily_budget()

            # Check if we should verify foundational truths first
            if await self.token_manager.has_budget_for("verification", 2000):
                print("🔍 Checking foundational truth confidence...")
                verification_result = await self.ctrm.verify_foundational_truths(max_tokens=3000)
                print(f"🔍 Verified {verification_result['verified_truths']} truths, used {verification_result['total_tokens_used']} tokens")

            # Check token budget for evolution
            if not await self.token_manager.has_budget_for("evolution", 2000):
                print("⏸️  Evolution paused - insufficient token budget")
                await asyncio.sleep(300)  # Wait 5 minutes
                continue

            # Execute evolution cycle
            evolution_result = await self.evolution_daemon.execute_evolution_cycle()

            # Log with CTRM analysis
            evolution_truth = await self.ctrm.create_truth(
                statement=f"Evolution cycle {evolution_result.get('cycle_id', 'N/A')}: {evolution_result.get('status', 'N/A')}",
                context=json.dumps(evolution_result, default=self._json_serializer)
            )

            # Update system state based on results
            if evolution_result.get("status") == "completed":
                await self.update_system_state(evolution_result)

            # Check efficiency and adjust sleep time
            efficiency_status = await self.token_manager.get_efficiency_status()
            sleep_time = self.calculate_sleep_time(evolution_result, efficiency_status)
            print(f"💤 Sleeping for {sleep_time} seconds before next evolution cycle")
            print(f"📊 Efficiency: {efficiency_status.get('average_efficiency', 0):.6f}, Conservation: {efficiency_status.get('conservation_mode', False)}")
            await asyncio.sleep(sleep_time)

    @staticmethod
    def _json_serializer(obj):
        """Convert non-serializable objects (like datetimes) to JSON-safe values."""
        if isinstance(obj, datetime):
            return obj.isoformat()
        if hasattr(obj, "to_dict"):
            return obj.to_dict()
        return str(obj)

    async def process_user_query(self, query: str, model: str = "default") -> Dict[str, Any]:
        """Process user query with CTRM-enhanced pipeline"""
        print(f"📝 Processing query: {query[:50]}...")

        # 0. System context reset for large queries
        if len(query) > 500:  # Large query detected
            print("⚠️  Large query detected, resetting system context")
            # Clear accumulated context by creating a fresh prompt optimizer
            self.prompt_optimizer = CTRMPromptOptimizer(self.ctrm)

        # 1. Route to best model using vector similarity
        if model == "default":
            routing = await self.model_router.route_to_best_model(query, {})
            model_to_use = routing["model"]
            routing_confidence = routing['confidence']
            print(f"🎯 Routed to model: {model_to_use} (confidence: {routing_confidence:.2f})")
        else:
            model_to_use = model
            routing_confidence = 1.0
            print(f"🎯 Using specified model: {model_to_use}")

        # 1.5. Pre-optimization context validation
        context_length = self.lm_studio.get_model_context_length(model_to_use)
        base_query_tokens = self.lm_studio.estimate_token_count(query)

        # If the base query is already too large, truncate it before optimization
        if base_query_tokens > context_length * 0.6:  # More than 60% of context
            print(f"⚠️  Base query too large: {base_query_tokens} tokens vs {context_length} limit")
            # Apply aggressive truncation to the base query
            max_query_words = int((context_length * 0.4) / 1.3)  # Target 40% of context
            query_words = query.split()
            truncated_query = " ".join(query_words[-max_query_words:])  # Keep end of query
            print(f"⚠️  Pre-truncated query from {len(query_words)} to {len(truncated_query.split())} words")
            query = truncated_query

        # 2. Optimize prompt using CTRM truths (with constrained context)
        optimized_prompt = await self.prompt_optimizer.optimize_prompt(
            base_prompt=query,
            objective="answer user query"
        )
        print(f"📝 Optimized prompt (length: {len(optimized_prompt)} chars)")

        # 3. Post-optimization context validation
        estimated_prompt_tokens = self.lm_studio.estimate_token_count(optimized_prompt)

        if estimated_prompt_tokens > context_length * 0.8:  # More than 80% of context
            print(f"⚠️  Optimized prompt too large: {estimated_prompt_tokens} tokens vs {context_length} limit")
            # Apply final truncation to ensure it fits
            max_prompt_words = int((context_length * 0.7) / 1.3)  # Target 70% of context
            prompt_words = optimized_prompt.split()
            truncated_prompt = "[Context truncated] ... " + " ".join(prompt_words[-max_prompt_words:])
            optimized_prompt = truncated_prompt
            print(f"⚠️  Post-truncated prompt to {len(truncated_prompt.split())} words")

        # 4. Check token budget for inference
        estimated_tokens = estimated_prompt_tokens + 1000  # Prompt + response estimate

        if not await self.token_manager.spend_tokens("inference", int(estimated_tokens)):
            return {
                "error": "Inference budget exceeded",
                "suggestion": "Try again later or simplify query"
            }

        # 5. Execute query with LM Studio (context management handled internally)
        try:
            response = await self.lm_studio.generate(
                model=model_to_use,
                prompt=optimized_prompt,
                temperature=0.7,
                max_tokens=min(1000, context_length // 4)  # Limit response to 25% of context
            )
        except Exception as e:
            return {
                "error": f"Query processing failed: {str(e)}",
                "suggestion": "The query may be too complex for the current model context window"
            }

        # 5. Create CTRM truth for this interaction
        interaction_truth = await self.ctrm.create_truth(
            statement=f"User query processed: {query[:50]}...",
            context=json.dumps({
                "query": query,
                "model_used": model_to_use,
                "routing_confidence": routing_confidence,
                "response_length": len(response["content"]),
                "token_usage": response["token_usage"]
            })
        )

        # 6. Update model performance in CTRM
        await self.update_model_performance(
            model=model_to_use,
            query_type=self.classify_query(query),
            quality_score=self.rate_response_quality(query, response["content"]),
            token_efficiency=len(response["content"]) / response["token_usage"]["completion_tokens"]
        )

        return {
            "response": response["content"],
            "model": model_to_use,
            "routing_confidence": routing_confidence,
            "tokens_used": response["token_usage"],
            "ctrm_truth_id": interaction_truth.id
        }

    async def process_vector_operation(self, operation: str, **kwargs) -> Dict[str, Any]:
        """Process vector operations using LLM-optimized tools"""
        print(f"🔢 Processing vector operation: {operation}")

        # Route to appropriate vector tool
        if operation == "store_vector":
            return await self.vector_interface.llm_store_vector(**kwargs)
        elif operation == "find_similar":
            return await self.vector_interface.llm_find_similar_vectors(**kwargs)
        elif operation == "analyze_space":
            return await self.vector_interface.llm_analyze_vector_space(**kwargs)
        elif operation == "track_evolution":
            return await self.vector_interface.track_vector_evolution(**kwargs)
        else:
            # Use vector protocol for other operations
            return await self.vector_interface.llm_vector_operation(operation, **kwargs)

    async def analyze_query_vectors(self, query: str) -> Dict[str, Any]:
        """Analyze vectors related to a user query"""
        print(f"🔍 Analyzing vectors for query: {query[:50]}...")

        # Generate embedding for the query
        model = await self.lm_studio.get_loaded_model()
        if not model:
            return {"error": "No LLM model available for vector analysis"}

        # Generate query embedding
        query_embedding = await self.lm_studio.generate_embedding(model, query)

        # Store the query vector
        query_vector_result = await self.vector_interface.llm_store_vector(
            vector=query_embedding,
            metadata={
                "source": "user_query",
                "description": f"User query: {query[:100]}...",
                "source_llm": model,
                "query_type": self.classify_query(query)
            }
        )

        # Find similar vectors
        similar_vectors = await self.vector_interface.llm_find_similar_vectors(
            query_vector=query_embedding,
            min_similarity=0.6,
            limit=5
        )

        # Analyze the query vector
        vector_analysis = await self.vector_analytics.analyze_vector_for_llm(
            query_embedding, model
        )

        # Create CTRM truth about this analysis
        analysis_truth = await self.ctrm.create_truth(
            statement=f"Query vector analysis: {query[:50]}...",
            confidence=vector_analysis["confidence"],
            vector=query_embedding,
            metadata={
                "query": query,
                "vector_analysis": vector_analysis,
                "similar_vectors": similar_vectors,
                "query_vector_hash": query_vector_result["vector_hash"],
                "timestamp": datetime.now().isoformat()
            }
        )

        return {
            "query_vector": query_vector_result,
            "similar_vectors": similar_vectors,
            "vector_analysis": vector_analysis,
            "ctrm_truth_id": analysis_truth.id,
            "recommendations": self.get_vector_recommendations(vector_analysis, similar_vectors)
        }

    def get_vector_recommendations(self, vector_analysis: Dict, similar_vectors: Dict) -> List[str]:
        """Get recommendations based on vector analysis"""
        recommendations = []

        # Quality-based recommendations
        if vector_analysis["quality_score"] < 0.6:
            recommendations.append("query_vector_quality_low")

        # Similarity-based recommendations
        if similar_vectors["found_count"] == 0:
            recommendations.append("no_similar_vectors_found")
        elif similar_vectors["found_count"] >= 3:
            recommendations.append("strong_similarity_pattern_detected")

        # Semantic recommendations
        primary_concepts = vector_analysis.get("primary_concepts", [])
        if primary_concepts:
            recommendations.append(f"focus_on_{primary_concepts[0]['concept']}")

        return recommendations

    async def enhance_evolution_with_vectors(self):
        """Enhance evolution system with vector analysis"""
        print("🔄 Enhancing evolution with vector analysis")

        # Analyze current vector space
        space_analysis = await self.vector_interface.llm_analyze_vector_space()

        # Get evolution patterns
        evolution_patterns = await self.vector_evolution.find_evolution_patterns()

        # Create comprehensive vector-enhanced evolution analysis
        vector_evolution_truth = await self.ctrm.create_truth(
            statement=f"Vector-enhanced evolution analysis: {space_analysis['space_analysis']['vector_count']} vectors analyzed",
            confidence=0.9,
            metadata={
                "space_analysis": space_analysis,
                "evolution_patterns": evolution_patterns,
                "vector_quality": space_analysis["space_analysis"]["quality_trends"],
                "coverage_score": space_analysis["space_analysis"]["coverage_score"],
                "timestamp": datetime.now().isoformat()
            }
        )

        return {
            "space_analysis": space_analysis,
            "evolution_patterns": evolution_patterns,
            "ctrm_truth_id": vector_evolution_truth.id,
            "recommendations": self.get_evolution_recommendations(space_analysis, evolution_patterns)
        }

    def get_evolution_recommendations(self, space_analysis: Dict, evolution_patterns: Dict) -> List[str]:
        """Get evolution recommendations based on vector analysis"""
        recommendations = []

        # Space coverage recommendations
        if space_analysis["space_analysis"]["coverage_score"] < 0.4:
            recommendations.append("expand_vector_space_coverage")

        # Quality recommendations
        if space_analysis["space_analysis"]["quality_trends"]["average_quality"] < 0.7:
            recommendations.append("improve_vector_quality")

        # Pattern recommendations
        if evolution_patterns["total_patterns"] < 3:
            recommendations.append("encourage_more_evolution_patterns")

        return recommendations

    async def update_system_state(self, evolution_result: Dict[str, Any]):
        """Update system state based on evolution results"""
        # This would update various system components
        print(f"🔧 Updated system state based on evolution {evolution_result['cycle_id']}")

    def calculate_sleep_time(self, evolution_result: Dict[str, Any], efficiency_status: Dict[str, Any] = None) -> int:
        """Calculate sleep time based on evolution efficiency and system status"""
        base_sleep = 5  # Base sleep time

        # Adjust based on evolution result
        if evolution_result.get("status") == "completed":
            base_sleep = 5
        else:
            base_sleep = 10

        # Adjust based on efficiency
        if efficiency_status:
            avg_efficiency = efficiency_status.get("average_efficiency", 0)
            conservation_mode = efficiency_status.get("conservation_mode", False)

            if conservation_mode:
                base_sleep = max(15, base_sleep * 2)  # Sleep longer in conservation mode
            elif avg_efficiency > 0.002:  # Good efficiency
                base_sleep = max(3, base_sleep // 2)  # Sleep less when efficient
            elif avg_efficiency < 0.0005:  # Very poor efficiency
                base_sleep = min(30, base_sleep * 3)  # Sleep much longer when inefficient

        return base_sleep

    async def update_model_performance(self, model: str, query_type: str, quality_score: float, token_efficiency: float):
        """Update model performance metrics in CTRM"""
        # Create truth about model performance
        await self.ctrm.create_truth(
            statement=f"Model {model} performance for {query_type}: quality={quality_score:.2f}, efficiency={token_efficiency:.2f}",
            context=json.dumps({
                "model": model,
                "query_type": query_type,
                "quality_score": quality_score,
                "token_efficiency": token_efficiency,
                "timestamp": datetime.now().isoformat(),
                "category": "model_performance"
            })
        )

    def classify_query(self, query: str) -> str:
        """Classify query type"""
        query_lower = query.lower()
        if "code" in query_lower or "program" in query_lower:
            return "coding"
        elif "math" in query_lower or "calculate" in query_lower:
            return "mathematics"
        elif "write" in query_lower or "compose" in query_lower:
            return "writing"
        else:
            return "general"

    def rate_response_quality(self, query: str, response: str) -> float:
        """Rate response quality (mock implementation)"""
        # Simple mock rating based on response length and query match
        length_factor = min(1.0, len(response) / 500)
        match_factor = 0.5 if query.lower() in response.lower() else 0.2
        return 0.6 + length_factor * 0.2 + match_factor * 0.2

async def main():
    """Main entry point"""
    daemon = CTRMLLMOSDaemon()

    # Initialize system
    await daemon.initialize()

    # Start evolution loop in background
    evolution_task = asyncio.create_task(daemon.run_continual_evolution())

    # Get the loaded model from LM Studio
    loaded_model = await daemon.lm_studio.get_loaded_model()

    # Example: Process a user query once at startup
    try:
        query_result = await daemon.process_user_query(
            "Explain the CTRM-Powered LLM OS architecture and its key innovations",
            model=loaded_model
        )
        print(f"🎉 Query result: {query_result['response'][:100]}...")
        print(f"💰 Tokens used: {query_result['tokens_used']['total_tokens']}")

        # Demonstrate vector analysis
        vector_analysis = await daemon.analyze_query_vectors(
            "Explain the CTRM-Powered LLM OS architecture and its key innovations"
        )
        print(f"🔢 Vector analysis: {len(vector_analysis.get('similar_vectors', {}).get('similar_vectors', []))} similar vectors found")
        print(f"🎯 Primary concepts: {vector_analysis.get('vector_analysis', {}).get('primary_concepts', [])}")

        # Demonstrate vector-enhanced evolution
        evolution_analysis = await daemon.enhance_evolution_with_vectors()
        print(f"🔄 Evolution analysis: {evolution_analysis.get('space_analysis', {}).get('space_analysis', {}).get('vector_count', 0)} vectors analyzed")
        print(f"📊 Coverage score: {evolution_analysis.get('space_analysis', {}).get('space_analysis', {}).get('coverage_score', 0):.2f}")

    except Exception as e:
        print(f"❌ Error processing query: {e}")

    # Keep running until interrupted
    try:
        await evolution_task  # This will run indefinitely
    except asyncio.CancelledError:
        pass
    except KeyboardInterrupt:
        print("🛑 Received shutdown signal, cancelling evolution loop...")
        evolution_task.cancel()
        try:
            await evolution_task
        except asyncio.CancelledError:
            pass

    print("👋 CTRM LLM OS shutting down")

if __name__ == "__main__":
    asyncio.run(main())
