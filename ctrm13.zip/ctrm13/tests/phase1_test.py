
import asyncio
import sys
import os

# Add project root to path
sys.path.append(os.getcwd())

from src.ctrm_core.database import CTRMDatabase
from src.ctrm_core.truth_manager import CTRMTruthManager, CTRMTruth

class MockEmbedder:
    async def embed(self, text):
        # Return a random 1536-dim vector simulated with numpy
        import numpy as np
        return np.random.rand(1536).tolist()

async def main():
    print("Testing Phase 1 Implementation...")
    
    # 1. Setup Database
    db = CTRMDatabase("test_ctrm.db")
    await db.initialize()
    print("✓ Database initialized")

    # 2. Setup Manager
    embedder = MockEmbedder()
    manager = CTRMTruthManager(db, embedder)
    print("✓ Manager initialized")

    # 3. Create Truth
    statement = "The sky is blue because of Rayleigh scattering."
    truth = await manager.create_truth(statement, context="physics textbook")
    print(f"✓ Created truth: {truth.id[:10]}... (Confidence: {truth.confidence})")

    # 4. Find Similar
    similar = await manager.find_similar_truths("Why is the sky blue?")
    print(f"✓ Found {len(similar)} similar truths")
    if similar:
        print(f"   Top match: {similar[0]['statement']} (Score: {similar[0]['relevance_score']:.4f})")

    # 5. Verify Truth (Mocked LM Studio)
    # We expect this to fail or succeed based on mock, but it should run without error.
    # Note: The mock LM Studio in integration.py returns a fixed response which might trigger 'True' or not.
    # Actually, integration.py mock returns "content": "[GPT-4 Response] Verify this statement..."
    # And parse_verification checks for "true" in content.
    # So unlikely to be "true" unless we tweak the mock.
    
    # But let's just see if it runs.
    result = await manager.verify_truth(truth.id, evidence="Direct observation")
    print(f"✓ Verification Result: {result['verified']} (Cost: {result['token_cost']['total_tokens']})")

    # Cleanup
    db.close()
    if os.path.exists("test_ctrm.db"):
        os.remove("test_ctrm.db")

if __name__ == "__main__":
    asyncio.run(main())
