import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock
from datetime import datetime
from src.evolution.evolution_daemon import TokenAwareEvolutionDaemon
from src.evolution.pattern_shift_detector import PatternShiftDetector
from src.evolution.architecture_version_control import ArchitectureVersionControl
from src.evolution.signal_conflict_resolver import SignalConflictResolver
from src.evolution.adaptive_evolution_daemon import AdaptiveEvolutionDaemon
from src.evolution.stale_optimization_guard import StaleOptimizationGuard

@pytest.mark.asyncio
async def test_pattern_shift_detection_and_rollback():
    """Test the complete pattern shift detection and rollback workflow"""

    # Create mock CTRM, token manager, and LM Studio
    mock_ctrm = MagicMock()
    mock_token_manager = MagicMock()
    mock_lm_studio = MagicMock()

    # Mock pattern shift detection
    mock_pattern_detector = MagicMock(spec=PatternShiftDetector)
    mock_pattern_detector.detect_sudden_shift.return_value = {
        "pattern_shift_detected": True,
        "reason": "significant_divergence",
        "confidence": 0.85,
        "divergence": 0.82
    }
    mock_pattern_detector.trigger_rollback_protocol.return_value = {
        "rollback_triggered": True,
        "ctrm_truth_id": "rollback_truth_123",
        "confidence": 0.85
    }

    # Create evolution daemon with mocked components
    daemon = TokenAwareEvolutionDaemon(mock_ctrm, mock_token_manager, mock_lm_studio)

    # Replace the pattern detector with our mock
    daemon.pattern_detector = mock_pattern_detector

    # Mock adaptive daemon
    mock_adaptive_daemon = MagicMock(spec=AdaptiveEvolutionDaemon)
    mock_adaptive_daemon.adapt_evolution_cycle.return_value = {
        "cycle_frequency": 10,
        "evolution_aggressiveness": 0.2,
        "rollback_readiness": 0.8,
        "validation_intensity": 0.9
    }
    daemon.adaptive_daemon = mock_adaptive_daemon

    # Execute evolution cycle
    result = await daemon.execute_evolution_cycle()

    # Verify pattern shift was detected and handled
    assert result["status"] == "pattern_shift_detected"
    assert result["reason"] == "significant_pattern_divergence"
    assert result["confidence"] == 0.85
    assert result["divergence"] == 0.82
    assert result["rollback_triggered"] == True
    assert result["adaptation_applied"]["cycle_frequency"] == 10

    # Verify pattern detector was called
    mock_pattern_detector.detect_sudden_shift.assert_called_once()
    mock_pattern_detector.trigger_rollback_protocol.assert_called_once_with(
        reason="pattern_shift",
        confidence=0.85
    )

    # Verify adaptive daemon was called with pattern_shift_detected=True
    mock_adaptive_daemon.adapt_evolution_cycle.assert_called_once_with(pattern_shift_detected=True)

@pytest.mark.asyncio
async def test_normal_evolution_with_rollback_prevention():
    """Test normal evolution cycle with performance-based rollback prevention"""

    # Create mock CTRM, token manager, and LM Studio
    mock_ctrm = MagicMock()
    mock_token_manager = MagicMock()
    mock_lm_studio = MagicMock()

    # Mock pattern shift detection (no shift)
    mock_pattern_detector = MagicMock(spec=PatternShiftDetector)
    mock_pattern_detector.detect_sudden_shift.return_value = {
        "pattern_shift_detected": False,
        "reason": "no_significant_divergence",
        "confidence": 0.2,
        "divergence": 0.1
    }

    # Mock adaptive daemon
    mock_adaptive_daemon = MagicMock(spec=AdaptiveEvolutionDaemon)
    mock_adaptive_daemon.adapt_evolution_cycle.return_value = {
        "cycle_frequency": 5,
        "evolution_aggressiveness": 0.5,
        "rollback_readiness": 0.3,
        "validation_intensity": 0.7
    }

    # Mock version control
    mock_version_control = MagicMock(spec=ArchitectureVersionControl)
    mock_version_control.rollback_if_needed.return_value = {
        "rollback_executed": False,
        "reason": "no_rollback_needed",
        "confidence": 0.0
    }

    # Mock conflict resolver
    mock_conflict_resolver = MagicMock(spec=SignalConflictResolver)
    mock_conflict_resolver.resolve_evolution_conflicts.return_value = {
        "conflicts_detected": False,
        "conflicts": [],
        "resolution": {
            "decision": "no_conflicts",
            "confidence": 1.0,
            "action": "proceed_with_optimization"
        }
    }

    # Create evolution daemon
    daemon = TokenAwareEvolutionDaemon(mock_ctrm, mock_token_manager, mock_lm_studio)
    daemon.pattern_detector = mock_pattern_detector
    daemon.adaptive_daemon = mock_adaptive_daemon
    daemon.version_control = mock_version_control
    daemon.conflict_resolver = mock_conflict_resolver

    # Mock token budgets (make them async)
    async def mock_get_category_available_budget(*args, **kwargs):
        return 5000

    mock_token_manager.get_category_available_budget = mock_get_category_available_budget

    # Mock CTRM methods (make them async)
    async def mock_find_similar_truths(*args, **kwargs):
        return [
            {
                "id": "truth_1",
                "statement": "CTRM provides the knowledge management framework",
                "confidence": 0.8,
                "distance_from_center": 20
            }
        ]

    async def mock_create_truth(*args, **kwargs):
        return MagicMock(
            id="new_truth_1",
            confidence=0.85,
            to_dict=lambda: {
                "id": "new_truth_1",
                "statement": "test",
                "confidence": 0.85
            }
        )

    async def mock_get_truth(*args, **kwargs):
        return {
            "id": "truth_1",
            "statement": "CTRM provides the knowledge management framework",
            "confidence": 0.8,
            "distance_from_center": 20,
            "created_at": datetime.now()
        }

    mock_ctrm.find_similar_truths = mock_find_similar_truths
    mock_ctrm.create_truth = mock_create_truth
    mock_ctrm.get_truth = mock_get_truth

    # Mock LM Studio (make methods async)
    async def mock_get_loaded_model(*args, **kwargs):
        return "gpt-4"

    async def mock_generate(*args, **kwargs):
        return {
            "content": '{"bottlenecks": [{"truth_id": "general_optimization", "issue": "General architecture optimization needed", "severity": "low", "potential_impact": 0.2}]}',
            "token_usage": {"total_tokens": 100}
        }

    mock_lm_studio.get_loaded_model = mock_get_loaded_model
    mock_lm_studio.generate = mock_generate

    # Execute evolution cycle
    result = await daemon.execute_evolution_cycle()

    # Verify normal evolution completed
    assert result["status"] == "completed"
    assert result["pattern_shift_detected"] == False
    assert result["conflict_resolution"]["conflicts_detected"] == False

    # Verify all components were called appropriately
    mock_pattern_detector.detect_sudden_shift.assert_called_once()
    mock_adaptive_daemon.adapt_evolution_cycle.assert_called_once_with(pattern_shift_detected=False)
    mock_version_control.rollback_if_needed.assert_called()
    mock_conflict_resolver.resolve_evolution_conflicts.assert_called_once()

@pytest.mark.asyncio
async def test_stale_optimization_prevention():
    """Test stale optimization detection and prevention"""

    # Create mock CTRM, token manager, and LM Studio
    mock_ctrm = MagicMock()
    mock_token_manager = MagicMock()
    mock_lm_studio = MagicMock()

    # Mock stale optimization guard
    mock_stale_guard = MagicMock(spec=StaleOptimizationGuard)
    mock_stale_guard.check_optimization_freshness.return_value = {
        "stale": True,
        "reason": "pattern_shift_detected",
        "pattern_change_confidence": 0.85
    }

    fresh_optimization = {
        "objective": {"description": "Fresh optimization"},
        "changes_made": ["Fresh changes"],
        "estimated_improvement": 0.15,
        "ctrm_truth_id": "fresh_truth_1",
        "freshly_generated": True
    }
    mock_stale_guard.prevent_stale_application.return_value = fresh_optimization

    # Create evolution daemon
    daemon = TokenAwareEvolutionDaemon(mock_ctrm, mock_token_manager, mock_lm_studio)
    daemon.stale_guard = mock_stale_guard

    # Mock other components to allow execution to reach stale check
    mock_pattern_detector = MagicMock(spec=PatternShiftDetector)
    mock_pattern_detector.detect_sudden_shift.return_value = {
        "pattern_shift_detected": False
    }
    daemon.pattern_detector = mock_pattern_detector

    mock_adaptive_daemon = MagicMock(spec=AdaptiveEvolutionDaemon)
    mock_adaptive_daemon.adapt_evolution_cycle.return_value = {
        "cycle_frequency": 5,
        "evolution_aggressiveness": 0.5,
        "rollback_readiness": 0.3,
        "validation_intensity": 0.7
    }
    daemon.adaptive_daemon = mock_adaptive_daemon

    # Mock token budgets (make them async)
    async def mock_get_category_available_budget(*args, **kwargs):
        return 5000

    mock_token_manager.get_category_available_budget = mock_get_category_available_budget

    # Mock CTRM methods (make them async)
    async def mock_find_similar_truths(*args, **kwargs):
        return [{
            "id": "truth_1",
            "statement": "CTRM provides the knowledge management framework",
            "confidence": 0.8
        }]

    async def mock_create_truth(*args, **kwargs):
        return MagicMock(
            id="new_truth_1",
            confidence=0.85,
            to_dict=lambda: {"id": "new_truth_1", "statement": "test", "confidence": 0.85}
        )

    async def mock_get_truth(*args, **kwargs):
        return {
            "id": "truth_1",
            "statement": "CTRM provides the knowledge management framework",
            "confidence": 0.8,
            "distance_from_center": 20,
            "created_at": datetime.now()
        }

    mock_ctrm.find_similar_truths = mock_find_similar_truths
    mock_ctrm.create_truth = mock_create_truth
    mock_ctrm.get_truth = mock_get_truth

    # Mock LM Studio (make methods async)
    async def mock_get_loaded_model(*args, **kwargs):
        return "gpt-4"

    async def mock_generate(*args, **kwargs):
        # Return different responses based on call order
        if not hasattr(mock_generate, "call_count"):
            mock_generate.call_count = 0
        mock_generate.call_count += 1

        if mock_generate.call_count == 1:
            return {
                "content": '{"bottlenecks": [{"truth_id": "general_optimization", "issue": "General architecture optimization needed", "severity": "low", "potential_impact": 0.2}]}',
                "token_usage": {"total_tokens": 100}
            }
        elif mock_generate.call_count == 2:
            return {
                "content": '{"description": "General architecture optimization", "target_confidence": 0.8, "focus_area": "token_efficiency", "expected_improvement": 0.15}',
                "token_usage": {"total_tokens": 100}
            }
        elif mock_generate.call_count == 3:
            return {
                "content": '{"changes_made": ["Optimization 1"], "estimated_improvement": 0.15, "ctrm_informed": true, "source_truths": ["source_truth_1"]}',
                "token_usage": {"total_tokens": 100}
            }
        else:
            return {
                "content": '{"valid": true, "improvement_score": 0.1, "validation_method": "llm_review", "confidence_in_validation": 0.8}',
                "token_usage": {"total_tokens": 100}
            }

    mock_lm_studio.get_loaded_model = mock_get_loaded_model
    mock_lm_studio.generate = mock_generate

    # Execute evolution cycle
    result = await daemon.execute_evolution_cycle()

    # Verify stale optimization was detected and prevented
    mock_stale_guard.check_optimization_freshness.assert_called_once_with("source_truth_1")
    mock_stale_guard.prevent_stale_application.assert_called_once()

    # Verify the result contains the fresh optimization
    assert result["status"] == "completed"
    assert result["evolution_result"]["freshly_generated"] == True

@pytest.mark.asyncio
async def test_performance_based_rollback():
    """Test performance-based rollback mechanism"""

    # Create mock CTRM, token manager, and LM Studio
    mock_ctrm = MagicMock()
    mock_token_manager = MagicMock()
    mock_lm_studio = MagicMock()

    # Mock version control to trigger rollback
    mock_version_control = MagicMock(spec=ArchitectureVersionControl)
    mock_version_control.rollback_if_needed.return_value = {
        "rollback_executed": True,
        "rolled_back_to": "v46",
        "confidence": 0.88,
        "reason": "performance_degradation"
    }

    # Create evolution daemon
    daemon = TokenAwareEvolutionDaemon(mock_ctrm, mock_token_manager, mock_lm_studio)
    daemon.version_control = mock_version_control

    # Mock other components to allow execution to reach rollback check
    mock_pattern_detector = MagicMock(spec=PatternShiftDetector)
    mock_pattern_detector.detect_sudden_shift.return_value = {
        "pattern_shift_detected": False
    }
    daemon.pattern_detector = mock_pattern_detector

    mock_adaptive_daemon = MagicMock(spec=AdaptiveEvolutionDaemon)
    mock_adaptive_daemon.adapt_evolution_cycle.return_value = {
        "cycle_frequency": 5,
        "evolution_aggressiveness": 0.5,
        "rollback_readiness": 0.3,
        "validation_intensity": 0.7
    }
    daemon.adaptive_daemon = mock_adaptive_daemon

    mock_conflict_resolver = MagicMock(spec=SignalConflictResolver)
    mock_conflict_resolver.resolve_evolution_conflicts.return_value = {
        "conflicts_detected": False,
        "conflicts": [],
        "resolution": {
            "decision": "no_conflicts",
            "confidence": 1.0,
            "action": "proceed_with_optimization"
        }
    }
    daemon.conflict_resolver = mock_conflict_resolver

    # Mock token budgets (make them async)
    async def mock_get_category_available_budget(*args, **kwargs):
        return 5000

    mock_token_manager.get_category_available_budget = mock_get_category_available_budget

    # Mock CTRM methods (make them async)
    async def mock_find_similar_truths(*args, **kwargs):
        return [{
            "id": "truth_1",
            "statement": "CTRM provides the knowledge management framework",
            "confidence": 0.8
        }]

    async def mock_create_truth(*args, **kwargs):
        return MagicMock(
            id="new_truth_1",
            confidence=0.85,
            to_dict=lambda: {"id": "new_truth_1", "statement": "test", "confidence": 0.85}
        )

    async def mock_get_truth(*args, **kwargs):
        return {
            "id": "truth_1",
            "statement": "CTRM provides the knowledge management framework",
            "confidence": 0.8,
            "distance_from_center": 20,
            "created_at": datetime.now()
        }

    mock_ctrm.find_similar_truths = mock_find_similar_truths
    mock_ctrm.create_truth = mock_create_truth
    mock_ctrm.get_truth = mock_get_truth

    # Mock LM Studio (make methods async)
    async def mock_get_loaded_model(*args, **kwargs):
        return "gpt-4"

    async def mock_generate(*args, **kwargs):
        # Return different responses based on call order
        if not hasattr(mock_generate, "call_count"):
            mock_generate.call_count = 0
        mock_generate.call_count += 1

        if mock_generate.call_count == 1:
            return {
                "content": '{"bottlenecks": [{"truth_id": "general_optimization", "issue": "General architecture optimization needed", "severity": "low", "potential_impact": 0.2}]}',
                "token_usage": {"total_tokens": 100}
            }
        elif mock_generate.call_count == 2:
            return {
                "content": '{"description": "General architecture optimization", "target_confidence": 0.8, "focus_area": "token_efficiency", "expected_improvement": 0.15}',
                "token_usage": {"total_tokens": 100}
            }
        elif mock_generate.call_count == 3:
            return {
                "content": '{"changes_made": ["Optimization 1"], "estimated_improvement": 0.15}',
                "token_usage": {"total_tokens": 100}
            }
        else:
            return {
                "content": '{"valid": true, "improvement_score": 0.05, "validation_method": "llm_review", "confidence_in_validation": 0.7}',
                "token_usage": {"total_tokens": 100}
            }

    mock_lm_studio.get_loaded_model = mock_get_loaded_model
    mock_lm_studio.generate = mock_generate

    # Execute evolution cycle
    result = await daemon.execute_evolution_cycle()

    # Verify rollback was executed
    assert result["status"] == "rollback_executed"
    assert result["reason"] == "performance_degradation"
    assert result["rollback_details"]["rolled_back_to"] == "v46"
    assert result["rollback_details"]["confidence"] == 0.88

    # Verify version control was called twice (once for conflict resolution, once for performance)
    assert mock_version_control.rollback_if_needed.call_count == 2

if __name__ == "__main__":
    asyncio.run(pytest.main([__file__, "-v"]))