#!/usr/bin/env python3
"""
Final LLM OS Composition - Manual Integration
This script creates a working OS from the built components.
"""

import sys
import os
import json
from typing import Dict, Any, Optional, List
import importlib.util
from pathlib import Path

# Add components directory to Python path
components_dir = os.path.join(os.path.dirname(__file__), "components")
if components_dir not in sys.path:
    sys.path.insert(0, components_dir)

def load_component(module_name: str, file_path: str):
    """Load a component from file"""
    try:
        spec = importlib.util.spec_from_file_location(module_name, file_path)
        if spec and spec.loader:
            module = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = module
            spec.loader.exec_module(module)
            return module
        else:
            print(f"❌ Failed to load {module_name}: Invalid spec")
            return None
    except Exception as e:
        print(f"❌ Failed to load {module_name}: {e}")
        return None

def initialize_components() -> Dict[str, Any]:
    """Initialize all OS components"""
    print("🚀 Initializing LLM OS Components...")
    components = {}

    # Define component files and their expected classes
    component_files = {
        "vector_memory": "comp_1f2c42c1d9d2.py",
        "task_scheduler": "comp_6cfa222db85e.py",
        "plugin_manager": "comp_b1b3ab0352b7.py",
        "monitoring_system": "comp_f8f42300ab8c.py",
        "api_gateway": "comp_40d99d6a1691.py"
    }

    # Load each component
    for name, filename in component_files.items():
        try:
            filepath = os.path.join(components_dir, filename)
            module = load_component(name, filepath)

            if module:
                # Try to find the main class/function
                main_class = None
                for attr_name in dir(module):
                    if not attr_name.startswith('_'):
                        attr = getattr(module, attr_name)
                        if isinstance(attr, type):  # It's a class
                            main_class = attr
                            break

                if main_class:
                    components[name] = main_class()
                    print(f"   ✅ Loaded {name}: {main_class.__name__}")
                else:
                    print(f"   ⚠️  Loaded {name} but no main class found")
                    components[name] = module
            else:
                print(f"   ❌ Failed to load {name}")

        except Exception as e:
            print(f"   ❌ Error loading {name}: {e}")

    return components

def setup_component_communication(components: Dict[str, Any]):
    """Set up communication between components"""
    print("🔗 Setting up component communication...")

    # Connect components that need to interact
    for name, component in components.items():
        # Give each component access to other components
        component.components = components

        # Set up specific connections
        if hasattr(component, 'vector_memory') and 'vector_memory' in components:
            component.vector_memory = components['vector_memory']

        if hasattr(component, 'monitoring_system') and 'monitoring_system' in components:
            component.monitoring_system = components['monitoring_system']

    print("   ✅ Component communication established")

def create_unified_api(components: Dict[str, Any]):
    """Create a unified API for the OS"""
    class LLMOS:
        """Unified LLM OS API"""

        def __init__(self, components: Dict[str, Any]):
            self.components = components
            self.name = "LLM OS v1.0"
            self.version = "1.0.0"
            self.status = "running"

        def process_request(self, request: Dict[str, Any]) -> Dict[str, Any]:
            """Process a request through the OS"""
            result = {
                "status": "success",
                "component": "unknown",
                "data": None,
                "error": None
            }

            try:
                # Route request to appropriate component
                request_type = request.get("type", "unknown")

                if request_type == "memory" and "vector_memory" in self.components:
                    # Handle memory operations
                    operation = request.get("operation", "store")
                    if operation == "store":
                        data = request.get("data", {})
                        vector = request.get("vector", [])
                        # Call vector memory component
                        if hasattr(self.components["vector_memory"], "store"):
                            result["data"] = self.components["vector_memory"].store(data, vector)
                        else:
                            result["error"] = "Vector memory component missing store method"
                    elif operation == "retrieve":
                        query = request.get("query", "")
                        if hasattr(self.components["vector_memory"], "retrieve"):
                            result["data"] = self.components["vector_memory"].retrieve(query)
                        else:
                            result["error"] = "Vector memory component missing retrieve method"

                elif request_type == "task" and "task_scheduler" in self.components:
                    # Handle task operations
                    task_data = request.get("task", {})
                    if hasattr(self.components["task_scheduler"], "schedule"):
                        result["data"] = self.components["task_scheduler"].schedule(task_data)
                    else:
                        result["error"] = "Task scheduler component missing schedule method"

                elif request_type == "plugin" and "plugin_manager" in self.components:
                    # Handle plugin operations
                    plugin_path = request.get("path", "")
                    if hasattr(self.components["plugin_manager"], "load_plugin"):
                        result["data"] = self.components["plugin_manager"].load_plugin(plugin_path)
                    else:
                        result["error"] = "Plugin manager component missing load_plugin method"

                else:
                    result["error"] = f"Unknown request type: {request_type}"

            except Exception as e:
                result["status"] = "error"
                result["error"] = str(e)

            return result

        def get_status(self) -> Dict[str, Any]:
            """Get current OS status"""
            return {
                "name": self.name,
                "version": self.version,
                "status": self.status,
                "components": list(self.components.keys()),
                "timestamp": datetime.now().isoformat()
            }

        def monitor_performance(self) -> Dict[str, Any]:
            """Monitor OS performance"""
            if "monitoring_system" in self.components:
                return self.components["monitoring_system"].get_metrics()
            return {"error": "Monitoring system not available"}

    return LLMOS(components)

def main():
    """Main OS entry point"""
    print("🎯 LLM OS - Self-Building Operating System")
    print("=" * 60)

    # Step 1: Initialize components
    components = initialize_components()

    if not components:
        print("❌ No components loaded - cannot start OS")
        return

    # Step 2: Set up communication
    setup_component_communication(components)

    # Step 3: Create unified API
    llm_os = create_unified_api(components)

    print(f"✅ LLM OS initialized with {len(components)} components")
    print(f"📊 Status: {llm_os.get_status()}")

    # Step 4: Test the OS
    print("\n🧪 Testing OS functionality...")

    # Test memory operations
    try:
        memory_test = {
            "type": "memory",
            "operation": "store",
            "data": {"test": "data"},
            "vector": [0.1] * 1536
        }
        result = llm_os.process_request(memory_test)
        print(f"   Memory test: {result['status']}")
    except Exception as e:
        print(f"   Memory test failed: {e}")

    # Test task operations
    try:
        task_test = {
            "type": "task",
            "task": {"function": "test", "args": []}
        }
        result = llm_os.process_request(task_test)
        print(f"   Task test: {result['status']}")
    except Exception as e:
        print(f"   Task test failed: {e}")

    # Step 5: Run interactive mode
    print("\n🎮 LLM OS Interactive Mode")
    print("Commands: status, test, exit")

    while True:
        try:
            command = input("llm-os> ").strip().lower()

            if command == "exit":
                break
            elif command == "status":
                status = llm_os.get_status()
                print(json.dumps(status, indent=2))
            elif command == "test":
                # Run comprehensive test
                print("Running comprehensive OS test...")

                # Test each component
                for name, component in components.items():
                    try:
                        if hasattr(component, 'test'):
                            result = component.test()
                            print(f"   {name}: {result}")
                        else:
                            print(f"   {name}: No test method")
                    except Exception as e:
                        print(f"   {name}: Test failed - {e}")

            else:
                print(f"Unknown command: {command}")

        except KeyboardInterrupt:
            break
        except Exception as e:
            print(f"Error: {e}")

    print("\n👋 LLM OS shutdown complete")

if __name__ == "__main__":
    # Add datetime import for monitoring
    from datetime import datetime
    main()