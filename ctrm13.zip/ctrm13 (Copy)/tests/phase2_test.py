#!/usr/bin/env python3
"""
Test Phase 2: Token-Managed Evolution System
"""

import asyncio
import sys
import os

# Add src to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from ctrm_core.database import CTRMDatabase
from ctrm_core.truth_manager import CTRMTruthManager
from token_manager.token_manager import TokenManager
from evolution.evolution_daemon import TokenAwareEvolutionDaemon

class MockEmbedder:
    """Mock embedding model for testing"""
    async def embed(self, text: str) -> list:
        import numpy as np
        import hashlib

        # Create a deterministic "embedding" based on text hash
        hash_obj = hashlib.md5(text.encode())
        hash_int = int(hash_obj.hexdigest(), 16)

        # Create a 1536-dimensional vector (simplified for mock)
        np.random.seed(hash_int % 1000)
        return list(np.random.randn(1536))

async def main():
    print("Testing Phase 2: Token-Managed Evolution System")
    print("=" * 50)

    # Initialize components
    embedder = MockEmbedder()
    db = CTRMDatabase("data/test_phase2.db")
    ctrm = CTRMTruthManager(db, embedder)
    token_manager = TokenManager(daily_budget=50000)  # Smaller budget for testing
    evolution_daemon = TokenAwareEvolutionDaemon(ctrm, token_manager)

    # Initialize database
    await db.initialize()
    print("✓ Database initialized")

    # Create some foundational truths for testing
    foundational_truths = [
        "CTRM provides the knowledge management framework",
        "Token efficiency is critical for sustainable operation",
        "Architectural stability is more important than novelty"
    ]

    for truth_statement in foundational_truths:
        await ctrm.create_truth(
            statement=truth_statement,
            context="system_foundation"
        )
    print("✓ Foundational truths created")

    # Test token budget management
    print("\n--- Testing Token Budget Management ---")

    # Check initial budget status
    budget_status = await token_manager.get_budget_status()
    print(f"Initial budget: {budget_status['total_budget']} tokens")
    print(f"Evolution budget: {budget_status['categories']['evolution']['budget']} tokens")

    # Test spending tokens
    can_spend = await token_manager.spend_tokens("evolution", 1000)
    print(f"Can spend 1000 tokens on evolution: {can_spend}")

    budget_status = await token_manager.get_budget_status()
    print(f"Remaining evolution budget: {budget_status['categories']['evolution']['remaining']} tokens")

    # Test budget limits
    can_spend_large = await token_manager.spend_tokens("evolution", 20000)
    print(f"Can spend 20000 tokens on evolution: {can_spend_large}")

    # Test evolution cycle
    print("\n--- Testing Evolution Cycle ---")

    # Execute evolution cycle
    evolution_result = await evolution_daemon.execute_evolution_cycle()
    print(f"✓ Evolution cycle executed: {evolution_result['status']}")
    print(f"  Cycle ID: {evolution_result['cycle_id']}")
    print(f"  Tokens spent: {evolution_result['tokens_spent']}")
    print(f"  Objective: {evolution_result['objective']['description']}")

    # Check evolution history
    history = await evolution_daemon.get_evolution_history()
    print(f"✓ Evolution history contains {len(history)} cycles")

    # Test multiple cycles
    print("\n--- Testing Multiple Evolution Cycles ---")

    for i in range(2):
        print(f"\nCycle {i+2}:")
        evolution_result = await evolution_daemon.execute_evolution_cycle()
        print(f"  Status: {evolution_result['status']}")
        if 'tokens_spent' in evolution_result:
            print(f"  Tokens spent: {evolution_result['tokens_spent']}")

        # Check budget after each cycle
        budget_status = await token_manager.get_budget_status()
        print(f"  Remaining budget: {budget_status['remaining']} tokens")

    # Test budget exhaustion
    print("\n--- Testing Budget Exhaustion ---")

    # Try to execute when budget is low
    evolution_result = await evolution_daemon.execute_evolution_cycle()
    print(f"Final cycle status: {evolution_result['status']}")

    if evolution_result['status'] == 'skipped':
        print(f"  Reason: {evolution_result['reason']}")
        print("✓ Budget management working correctly")

    # Test prioritization
    print("\n--- Testing Operation Prioritization ---")

    # Create some test operations
    test_operations = [
        {"truth_id": "test1", "estimated_tokens": 1000},
        {"truth_id": "test2", "estimated_tokens": 500},
        {"truth_id": "test3", "estimated_tokens": 2000}
    ]

    # Create test truths for prioritization
    for i, op in enumerate(test_operations):
        truth = await ctrm.create_truth(
            statement=f"Test truth {i+1} for prioritization",
            context="test"
        )
        # Update the truth with specific values for testing
        truth.confidence = 0.7 + i * 0.1
        truth.importance_score = 0.5 + i * 0.2
        truth.distance_from_center = 20 - i * 5
        await ctrm.db.update_truth(truth.to_dict())

    prioritized = await token_manager.prioritize_operations(test_operations, ctrm)
    print(f"Prioritized {len(prioritized)} operations:")
    for i, op in enumerate(prioritized):
        print(f"  {i+1}. Truth {op['truth_id']}: priority={op['priority_score']:.4f}, value/token={op['value_per_token']:.4f}")

    print("\n✅ Phase 2 Testing Complete!")
    print(f"   - Token budget management: ✓")
    print(f"   - Evolution cycles: ✓")
    print(f"   - Operation prioritization: ✓")
    print(f"   - Budget exhaustion handling: ✓")

if __name__ == "__main__":
    asyncio.run(main())