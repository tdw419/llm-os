import asyncio
import pytest
import json
import numpy as np
from unittest.mock import AsyncMock, MagicMock
from datetime import datetime
from src.vector_llm_tools.vector_analytics import VectorAnalyticsForLLMs
from src.vector_llm_tools.vector_qa import VectorQAForLLMs
from src.vector_llm_tools.vector_evolution_tracker import VectorEvolutionTracker
from src.vector_llm_tools.vector_protocol import LLMVectorProtocol
from src.vector_llm_tools.vector_space_mapper import VectorSpaceMapper
from src.vector_llm_tools.vector_interface import CTRMVectorInterface

@pytest.mark.asyncio
async def test_vector_analytics_interpretation():
    """Test vector interpretation for LLMs"""

    # Create mock CTRM and LM Studio
    mock_ctrm = MagicMock()
    mock_lm_studio = MagicMock()

    # Create vector analytics
    vector_analytics = VectorAnalyticsForLLMs(mock_ctrm, mock_lm_studio)

    # Create test vector
    test_vector = list(np.random.randn(1536))

    # Mock LLM response
    async def mock_generate(*args, **kwargs):
        return {
            "content": json.dumps({
                "summary": "Database optimization vector with token efficiency focus",
                "confidence": 0.85,
                "primary_concepts": [
                    {"concept": "database_optimization", "strength": 0.87},
                    {"concept": "token_efficiency", "strength": 0.82}
                ],
                "secondary_concepts": [
                    {"concept": "query_processing", "strength": 0.65},
                    {"concept": "performance_monitoring", "strength": 0.58}
                ],
                "use_cases": ["database_management", "query_optimization", "resource_allocation"],
                "quality": "high"
            })
        }

    mock_lm_studio.generate = mock_generate
    mock_lm_studio.get_loaded_model = AsyncMock(return_value="test_model")

    # Mock CTRM create_truth
    async def mock_create_truth(*args, **kwargs):
        return MagicMock(
            id="vector_truth_1",
            confidence=0.85,
            to_dict=lambda: {"id": "vector_truth_1", "statement": "test", "confidence": 0.85}
        )

    mock_ctrm.create_truth = mock_create_truth

    # Test vector interpretation
    result = await vector_analytics.analyze_vector_for_llm(test_vector, "test_llm")

    assert result["vector_hash"] is not None
    assert result["ctrm_truth_id"] is not None
    assert result["primary_concepts"][0]["concept"] == "database_optimization"
    assert result["quality"] == "high"
    assert result["confidence"] == 0.85

@pytest.mark.asyncio
async def test_vector_qa_validation():
    """Test vector quality assurance"""

    # Create mock CTRM and LM Studio
    mock_ctrm = MagicMock()
    mock_lm_studio = MagicMock()

    # Create vector QA
    vector_qa = VectorQAForLLMs(mock_ctrm, mock_lm_studio)

    # Create test vector
    test_vector = list(np.random.randn(1536))

    # Mock LLM response
    async def mock_generate(*args, **kwargs):
        return {
            "content": json.dumps({
                "verdict": "high_quality",
                "confidence": 0.9,
                "reasoning": "Vector has good norm and distribution characteristics",
                "recommendation": "suitable_for_all_operations"
            })
        }

    mock_lm_studio.generate = mock_generate

    # Mock CTRM create_truth
    async def mock_create_truth(*args, **kwargs):
        return MagicMock(
            id="qa_truth_1",
            confidence=0.9,
            to_dict=lambda: {"id": "qa_truth_1", "statement": "test", "confidence": 0.9}
        )

    mock_ctrm.create_truth = mock_create_truth

    # Test vector validation
    result = await vector_qa.validate_vector_quality(test_vector, "test_llm")

    assert result["quality_score"] > 0.5
    assert result["passed"] is True
    assert result["llm_assessment"]["verdict"] == "high_quality"
    assert result["truth_id"] is not None

@pytest.mark.asyncio
async def test_vector_protocol_rpc():
    """Test vector protocol RPC operations"""

    # Create mock components
    mock_ctrm = MagicMock()
    mock_lm_studio = MagicMock()
    mock_vector_analytics = MagicMock()
    mock_vector_qa = MagicMock()
    mock_vector_evolution = MagicMock()

    # Create vector protocol
    vector_protocol = LLMVectorProtocol(
        mock_ctrm, mock_lm_studio,
        mock_vector_analytics, mock_vector_qa, mock_vector_evolution
    )

    # Test vector generation
    async def mock_generate_embedding(*args, **kwargs):
        return list(np.random.randn(1536))

    mock_lm_studio.generate_embedding = mock_generate_embedding
    mock_lm_studio.get_loaded_model = AsyncMock(return_value="test_model")

    # Mock vector QA validation
    async def mock_validate(*args, **kwargs):
        return {
            "quality_score": 0.85,
            "llm_assessment": {"verdict": "high_quality"},
            "truth_id": "validation_truth_1",
            "vector_hash": "test_hash_1"
        }

    mock_vector_qa.validate_vector_quality = mock_validate

    # Mock CTRM create_truth
    async def mock_create_truth(*args, **kwargs):
        return MagicMock(
            id="protocol_truth_1",
            confidence=0.95,
            to_dict=lambda: {"id": "protocol_truth_1", "statement": "test", "confidence": 0.95}
        )

    mock_ctrm.create_truth = mock_create_truth

    # Test generate vector command
    result = await vector_protocol.llm_vector_rpc(
        "GENERATE_VECTOR",
        concept="test concept",
        dimensions=1536
    )

    assert result["vector"] is not None
    assert len(result["vector"]) == 1536
    assert result["metadata"]["concept"] == "test concept"
    assert result["ctrm_truth_id"] is not None
    assert result["status"] == "success"

@pytest.mark.asyncio
async def test_vector_interface_integration():
    """Test complete vector interface integration"""

    # Create mock components
    mock_ctrm = MagicMock()
    mock_lm_studio = MagicMock()
    mock_db = MagicMock()
    mock_vector_analytics = MagicMock()
    mock_vector_qa = MagicMock()
    mock_vector_evolution = MagicMock()
    mock_vector_protocol = MagicMock()
    mock_vector_mapper = MagicMock()

    # Create vector interface
    vector_interface = CTRMVectorInterface(
        mock_ctrm, mock_lm_studio, mock_db,
        mock_vector_analytics, mock_vector_qa,
        mock_vector_evolution, mock_vector_protocol,
        mock_vector_mapper
    )

    # Test vector storage
    test_vector = list(np.random.randn(1536))

    # Mock database operations
    async def mock_execute(*args, **kwargs):
        return None

    async def mock_query(*args, **kwargs):
        return []

    mock_db.execute = mock_execute
    mock_db.query = mock_query

    # Mock LLM operations
    mock_lm_studio.get_loaded_model = AsyncMock(return_value="test_model")

    # Mock vector QA validation
    async def mock_validate(*args, **kwargs):
        return {
            "valid": True,
            "quality_score": 0.85,
            "llm_feedback": "High quality vector",
            "confidence": 0.9,
            "vector_metrics": {
                "norm": 10.5,
                "mean": 0.01,
                "std": 0.5
            },
            "recommendation": "use_with_confidence"
        }

    mock_vector_qa.validate_for_llm = mock_validate

    # Mock CTRM create_truth
    async def mock_create_truth(*args, **kwargs):
        return MagicMock(
            id="interface_truth_1",
            confidence=0.85,
            to_dict=lambda: {"id": "interface_truth_1", "statement": "test", "confidence": 0.85}
        )

    mock_ctrm.create_truth = mock_create_truth

    # Test vector storage
    result = await vector_interface.llm_store_vector(
        vector=test_vector,
        metadata={
            "source": "test",
            "description": "Test vector for integration",
            "source_llm": "test_model"
        }
    )

    assert result["vector_hash"] is not None
    assert result["truth_id"] is not None
    assert result["quality_score"] == 0.85
    assert result["status"] == "stored"

@pytest.mark.asyncio
async def test_vector_space_mapping():
    """Test vector space mapping functionality"""

    # Create mock components
    mock_ctrm = MagicMock()
    mock_lm_studio = MagicMock()
    mock_db = MagicMock()

    # Create vector mapper
    vector_mapper = VectorSpaceMapper(mock_ctrm, mock_lm_studio, mock_db)

    # Create test vectors
    test_vectors = [list(np.random.randn(1536)) for _ in range(10)]
    test_labels = [f"test_label_{i}" for i in range(10)]

    # Mock LLM operations
    async def mock_generate(*args, **kwargs):
        return {
            "content": json.dumps({
                "summary": "Diverse vector space with clear semantic regions",
                "confidence": 0.85,
                "regions": ["database_optimization", "query_processing", "token_management"]
            })
        }

    mock_lm_studio.generate = mock_generate

    # Mock CTRM create_truth
    async def mock_create_truth(*args, **kwargs):
        return MagicMock(
            id="space_truth_1",
            confidence=0.85,
            to_dict=lambda: {"id": "space_truth_1", "statement": "test", "confidence": 0.85}
        )

    mock_ctrm.create_truth = mock_create_truth

    # Test space mapping
    result = await vector_mapper.create_vector_space_map(test_vectors, test_labels)

    assert result["space_map"] is not None
    assert result["ctrm_truth_id"] is not None
    assert result["vector_count"] == 10
    assert result["dimensionality"] == 1536

@pytest.mark.asyncio
async def test_vector_evolution_tracking():
    """Test vector evolution tracking"""

    # Create mock components
    mock_ctrm = MagicMock()
    mock_lm_studio = MagicMock()
    mock_db = MagicMock()

    # Create vector evolution tracker
    vector_evolution = VectorEvolutionTracker(mock_ctrm, mock_lm_studio, mock_db)

    # Create test vectors
    parent_vector = list(np.random.randn(1536))
    child_vector = [v + np.random.normal(0, 0.1) for v in parent_vector]

    # Mock database operations
    async def mock_execute(*args, **kwargs):
        return None

    async def mock_query(*args, **kwargs):
        return []

    mock_db.execute = mock_execute
    mock_db.query = mock_query

    # Mock LLM operations
    async def mock_generate(*args, **kwargs):
        return {
            "content": json.dumps({
                "shift_type": "refinement",
                "confidence": 0.8,
                "description": "Vector represents refinement of parent concept",
                "semantic_impact": "enhanced_specificity"
            })
        }

    mock_lm_studio.generate = mock_generate

    # Mock CTRM create_truth
    async def mock_create_truth(*args, **kwargs):
        return MagicMock(
            id="evolution_truth_1",
            confidence=0.8,
            to_dict=lambda: {"id": "evolution_truth_1", "statement": "test", "confidence": 0.8}
        )

    mock_ctrm.create_truth = mock_create_truth

    # Test vector lineage tracking
    result = await vector_evolution.track_vector_lineage(child_vector, parent_vector)

    assert result is not None
    assert len(result) > 0

@pytest.mark.asyncio
async def test_comprehensive_vector_workflow():
    """Test comprehensive vector workflow from storage to analysis"""

    # Create mock components
    mock_ctrm = MagicMock()
    mock_lm_studio = MagicMock()
    mock_db = MagicMock()

    # Create all vector tools
    vector_analytics = VectorAnalyticsForLLMs(mock_ctrm, mock_lm_studio)
    vector_qa = VectorQAForLLMs(mock_ctrm, mock_lm_studio)
    vector_evolution = VectorEvolutionTracker(mock_ctrm, mock_lm_studio, mock_db)
    vector_protocol = LLMVectorProtocol(
        mock_ctrm, mock_lm_studio,
        vector_analytics, vector_qa, vector_evolution
    )
    vector_mapper = VectorSpaceMapper(mock_ctrm, mock_lm_studio, mock_db)
    vector_interface = CTRMVectorInterface(
        mock_ctrm, mock_lm_studio, mock_db,
        vector_analytics, vector_qa,
        vector_evolution, vector_protocol,
        vector_mapper
    )

    # Create test vector
    test_vector = list(np.random.randn(1536))

    # Mock all necessary operations
    async def mock_generate(*args, **kwargs):
        # Check if this is a vector interpretation call
        if len(args) > 2 and isinstance(args[2], dict) and args[2].get("max_tokens") == 500:
            # This is a vector interpretation call
            return {
                "content": json.dumps({
                    "summary": "Test vector analysis",
                    "confidence": 0.85,
                    "primary_concepts": [{"concept": "test_concept", "strength": 0.8}],
                    "secondary_concepts": [],
                    "use_cases": ["general_purpose"],
                    "quality": "high"
                })
            }
        else:
            # This is a quality validation call
            return {
                "content": json.dumps({
                    "verdict": "high_quality",
                    "confidence": 0.9,
                    "reasoning": "Good vector characteristics"
                })
            }

    mock_lm_studio.generate = mock_generate
    mock_lm_studio.get_loaded_model = AsyncMock(return_value="test_model")
    mock_lm_studio.generate_embedding = AsyncMock(return_value=test_vector)

    async def mock_execute(*args, **kwargs):
        return None

    async def mock_query(*args, **kwargs):
        return []

    mock_db.execute = mock_execute
    mock_db.query = mock_query

    async def mock_create_truth(*args, **kwargs):
        return MagicMock(
            id="workflow_truth_1",
            confidence=0.85,
            to_dict=lambda: {"id": "workflow_truth_1", "statement": "test", "confidence": 0.85}
        )

    mock_ctrm.create_truth = mock_create_truth

    # Test complete workflow
    # 1. Store vector
    store_result = await vector_interface.llm_store_vector(
        vector=test_vector,
        metadata={"source": "workflow_test", "description": "Comprehensive test"}
    )

    # 2. Analyze vector
    analysis_result = await vector_analytics.analyze_vector_for_llm(test_vector, "test_llm")

    # 3. Validate quality
    qa_result = await vector_qa.validate_vector_quality(test_vector, "test_llm")

    # 4. Use protocol
    protocol_result = await vector_protocol.llm_vector_rpc(
        "INTERPRET_VECTOR",
        vector=test_vector,
        context="workflow_test"
    )

    # Verify all steps succeeded
    assert store_result["status"] == "stored"
    assert analysis_result["confidence"] == 0.85
    assert qa_result["passed"] is True
    assert protocol_result["status"] == "success"

    print("✅ Comprehensive vector workflow test passed")