import asyncio
import json
import numpy as np
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime
import aiohttp
import sys
import os

# Add project root to Python path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from substrate.vector_db import VectorSubstrate, VectorType, VectorEntry

class SubstrateEvolutionAgent:
    """
    LM Studio agent that evolves the substrate computational medium
    Uses LM Studio to analyze, improve, and create new vectors
    """

    def __init__(self,
                 substrate_db: str = "./llm_os_substrate.db",
                 lm_studio_url: str = "http://localhost:1234/v1/completions",
                 api_key: str = None):

        self.substrate = VectorSubstrate(substrate_db)
        self.lm_studio_url = lm_studio_url
        self.api_key = api_key
        self.session = None
        self.evolution_history = []

        # Evolution strategies
        self.strategies = [
            "vector_refinement",
            "component_improvement",
            "relation_discovery",
            "gap_identification",
            "pattern_extraction",
            "abstraction_generation"
        ]

    async def connect(self):
        """Establish connection to LM Studio"""
        self.session = aiohttp.ClientSession(
            headers={
                "Authorization": f"Bearer {self.api_key}" if self.api_key else "",
                "Content-Type": "application/json"
            }
        )

    async def disconnect(self):
        """Close connection"""
        if self.session:
            await self.session.close()

    async def evolve_substrate(self,
                             strategy: str = "auto",
                             focus_area: Optional[str] = None,
                             max_iterations: int = 10):
        """
        Main evolution loop - LM Studio evolves the substrate

        Args:
            strategy: Evolution strategy or "auto" to choose best
            focus_area: Specific area to focus on (e.g., "vector_memory")
            max_iterations: Maximum evolution cycles
        """
        print(f"🧬 Starting substrate evolution with strategy: {strategy}")

        if not self.session:
            await self.connect()

        iterations = 0
        improvements = []

        while iterations < max_iterations:
            print(f"\n🔄 Evolution Cycle {iterations + 1}/{max_iterations}")

            try:
                # 1. Analyze current substrate state
                analysis = await self._analyze_substrate_state(focus_area)

                # 2. Choose evolution strategy
                if strategy == "auto":
                    chosen_strategy = await self._choose_evolution_strategy(analysis)
                else:
                    chosen_strategy = strategy

                print(f"   Strategy: {chosen_strategy}")

                # 3. Generate evolution plan using LM Studio
                evolution_plan = await self._generate_evolution_plan(
                    analysis, chosen_strategy, focus_area
                )

                # 4. Execute evolution plan
                evolution_results = await self._execute_evolution_plan(evolution_plan)

                # 5. Evaluate improvements
                improvement_score = await self._evaluate_improvement(
                    analysis, evolution_results
                )

                improvements.append({
                    'cycle': iterations + 1,
                    'strategy': chosen_strategy,
                    'improvement_score': improvement_score,
                    'results': evolution_results,
                    'timestamp': datetime.now().isoformat()
                })

                print(f"   Improvement score: {improvement_score:.3f}")

                # 6. Store evolution in substrate
                await self._store_evolution_result(
                    iterations + 1,
                    chosen_strategy,
                    improvement_score,
                    evolution_results
                )

                # Check if we should continue
                if improvement_score < 0.1:  # Minimal improvement
                    print(f"   ⏹️  Minimal improvement, stopping evolution")
                    break

                iterations += 1

                # Small delay between cycles
                await asyncio.sleep(2)

            except Exception as e:
                print(f"   ❌ Evolution cycle failed: {e}")
                await asyncio.sleep(5)

        # Final analysis
        print(f"\n✅ Evolution complete: {iterations} cycles")

        if improvements:
            avg_improvement = sum(i['improvement_score'] for i in improvements) / len(improvements)
            print(f"   Average improvement: {avg_improvement:.3f}")
            print(f"   Best cycle: {max(improvements, key=lambda x: x['improvement_score'])['cycle']}")

        return {
            'iterations': iterations,
            'improvements': improvements,
            'final_substrate_stats': await self.substrate.get_statistics()
        }

    async def _analyze_substrate_state(self, focus_area: Optional[str] = None) -> Dict[str, Any]:
        """Analyze current substrate state for LM Studio"""
        print("   📊 Analyzing substrate state...")

        # Get substrate statistics
        stats = await self.substrate.get_statistics()

        # Get sample vectors for analysis
        sample_vectors = await self._get_substrate_sample(focus_area)

        # Analyze vector quality
        quality_analysis = await self._analyze_vector_quality(sample_vectors)

        # Analyze relations
        relation_analysis = await self._analyze_relations()

        # Identify gaps and opportunities
        gap_analysis = await self._identify_gaps(sample_vectors)

        return {
            'statistics': stats,
            'sample_analysis': {
                'count': len(sample_vectors),
                'quality': quality_analysis,
                'diversity': await self._calculate_diversity(sample_vectors)
            },
            'relations': relation_analysis,
            'gaps': gap_analysis,
            'focus_area': focus_area,
            'timestamp': datetime.now().isoformat()
        }

    async def _get_substrate_sample(self, focus_area: Optional[str] = None,
                                  sample_size: int = 20) -> List[Dict[str, Any]]:
        """Get a sample of vectors from substrate"""
        sample = []

        # If focus area specified, search for related vectors
        if focus_area:
            search_results = await self.substrate.search_vectors(
                focus_area,
                limit=sample_size
            )
            sample.extend(search_results)

        # Always include some component vectors
        cursor = self.substrate.conn.execute(
            "SELECT id, vector_data FROM vectors WHERE vector_type = 'component' LIMIT ?",
            (sample_size // 2,)
        )

        for row in cursor:
            entry = VectorEntry.from_bytes(row['vector_data'])
            sample.append({
                'vector': entry,
                'metadata': entry.metadata,
                'type': entry.vector_type.value
            })

        # Include some code vectors
        cursor = self.substrate.conn.execute(
            "SELECT id, vector_data FROM vectors WHERE vector_type = 'code' LIMIT ?",
            (sample_size // 4,)
        )

        for row in cursor:
            entry = VectorEntry.from_bytes(row['vector_data'])
            sample.append({
                'vector': entry,
                'metadata': entry.metadata,
                'type': entry.vector_type.value
            })

        return sample[:sample_size]

    async def _analyze_vector_quality(self, sample_vectors: List[Dict]) -> Dict[str, Any]:
        """Analyze quality of vectors in substrate"""
        if not sample_vectors:
            return {'error': 'No vectors to analyze'}

        qualities = []

        for sample in sample_vectors:
            vector = sample['vector'].vector if hasattr(sample['vector'], 'vector') else sample['vector']

            # Calculate vector quality metrics
            vector_np = np.array(vector)

            quality = {
                'norm': float(np.linalg.norm(vector_np)),
                'mean': float(np.mean(vector_np)),
                'std': float(np.std(vector_np)),
                'sparsity': float(np.sum(np.abs(vector_np) < 0.01) / len(vector_np)),
                'confidence': sample['vector'].confidence if hasattr(sample['vector'], 'confidence') else 1.0
            }

            qualities.append(quality)

        # Aggregate metrics
        avg_norm = np.mean([q['norm'] for q in qualities])
        avg_confidence = np.mean([q['confidence'] for q in qualities])
        avg_sparsity = np.mean([q['sparsity'] for q in qualities])

        return {
            'avg_norm': avg_norm,
            'avg_confidence': avg_confidence,
            'avg_sparsity': avg_sparsity,
            'sample_count': len(qualities),
            'quality_distribution': {
                'excellent': len([q for q in qualities if q['confidence'] > 0.8]),
                'good': len([q for q in qualities if 0.6 < q['confidence'] <= 0.8]),
                'poor': len([q for q in qualities if q['confidence'] <= 0.6])
            }
        }

    async def _analyze_relations(self) -> Dict[str, Any]:
        """Analyze relations between vectors"""
        cursor = self.substrate.conn.execute("""
            SELECT relation_type, COUNT(*) as count, AVG(strength) as avg_strength
            FROM vector_relations
            GROUP BY relation_type
        """)

        relations = {}
        total_relations = 0

        for row in cursor:
            relations[row['relation_type']] = {
                'count': row['count'],
                'avg_strength': row['avg_strength']
            }
            total_relations += row['count']

        # Calculate relation density
        total_vectors = (await self.substrate.get_statistics())['total_vectors']
        density = total_relations / (total_vectors * (total_vectors - 1)) if total_vectors > 1 else 0

        return {
            'relations_by_type': relations,
            'total_relations': total_relations,
            'relation_density': density,
            'avg_relations_per_vector': total_relations / total_vectors if total_vectors > 0 else 0
        }

    async def _identify_gaps(self, sample_vectors: List[Dict]) -> List[Dict[str, Any]]:
        """Identify gaps in the substrate"""
        gaps = []

        # Analyze vector type distribution
        type_counts = {}
        for sample in sample_vectors:
            vec_type = sample['type']
            type_counts[vec_type] = type_counts.get(vec_type, 0) + 1

        # Check for missing vector types
        expected_types = ['code', 'component', 'os', 'knowledge', 'execution', 'evolution']
        for expected in expected_types:
            if expected not in type_counts or type_counts[expected] < 3:
                gaps.append({
                    'type': 'missing_vector_type',
                    'description': f'Few or no {expected} vectors in substrate',
                    'severity': 'high' if expected in ['code', 'component'] else 'medium',
                    'suggestion': f'Generate more {expected} vectors'
                })

        # Check for isolated vectors (few relations)
        for sample in sample_vectors[:10]:  # Check first 10
            if hasattr(sample['vector'], 'id'):
                relations = await self.substrate.get_related_vectors(sample['vector'].id)
                if len(relations) < 2:
                    gaps.append({
                        'type': 'isolated_vector',
                        'vector_id': sample['vector'].id[:12],
                        'vector_type': sample['type'],
                        'relation_count': len(relations),
                        'suggestion': 'Create more relations for this vector'
                    })

        # Check for low confidence vectors
        low_conf_vectors = []
        for sample in sample_vectors:
            if hasattr(sample['vector'], 'confidence') and sample['vector'].confidence < 0.5:
                low_conf_vectors.append(sample['vector'].id[:12])

        if low_conf_vectors:
            gaps.append({
                'type': 'low_confidence_vectors',
                'count': len(low_conf_vectors),
                'examples': low_conf_vectors[:5],
                'suggestion': 'Improve or remove low confidence vectors'
            })

        return gaps[:10]  # Limit to top 10 gaps

    async def _calculate_diversity(self, sample_vectors: List[Dict]) -> float:
        """Calculate diversity of vectors in sample"""
        if len(sample_vectors) < 2:
            return 0.0

        vectors = []
        for sample in sample_vectors:
            if hasattr(sample['vector'], 'vector'):
                vectors.append(np.array(sample['vector'].vector))
            elif isinstance(sample['vector'], list):
                vectors.append(np.array(sample['vector']))

        if not vectors:
            return 0.0

        # Calculate pairwise distances
        distances = []
        for i in range(len(vectors)):
            for j in range(i + 1, len(vectors)):
                dist = np.linalg.norm(vectors[i] - vectors[j])
                distances.append(dist)

        if distances:
            avg_distance = np.mean(distances)
            max_possible = np.sqrt(len(vectors[0]) * 2)  # Max distance for unit vectors
            diversity = avg_distance / max_possible if max_possible > 0 else 0.0
            return float(diversity)

        return 0.0

    async def _choose_evolution_strategy(self, analysis: Dict) -> str:
        """Let LM Studio choose the best evolution strategy"""
        prompt = f"""
        Analyze this substrate computational medium and choose the best evolution strategy:

        SUBSTRATE ANALYSIS:
        {json.dumps(analysis, indent=2, default=str)}

        Available strategies:
        1. vector_refinement - Improve existing vector quality and clarity
        2. component_improvement - Enhance existing components
        3. relation_discovery - Find and create new relations between vectors
        4. gap_identification - Identify and fill missing knowledge
        5. pattern_extraction - Extract patterns from existing vectors
        6. abstraction_generation - Create higher-level abstractions

        Based on the analysis, which strategy would be most effective now?
        Consider:
        - Vector quality metrics
        - Relation density
        - Identified gaps
        - Current focus area

        Return ONLY the strategy name (e.g., "vector_refinement") with no additional text.
        """

        response = await self._call_lm_studio(prompt, max_tokens=50, temperature=0.2)
        strategy = response.strip().lower()

        # Validate strategy
        if strategy in self.strategies:
            return strategy
        else:
            # Default based on analysis
            if analysis['gaps']:
                return "gap_identification"
            elif analysis['sample_analysis']['quality']['avg_confidence'] < 0.7:
                return "vector_refinement"
            elif analysis['relations']['relation_density'] < 0.1:
                return "relation_discovery"
            else:
                return "component_improvement"

    async def _generate_evolution_plan(self,
                                     analysis: Dict,
                                     strategy: str,
                                     focus_area: Optional[str] = None) -> Dict[str, Any]:
        """Generate evolution plan using LM Studio"""
        print(f"   📝 Generating {strategy} evolution plan...")

        prompt = f"""
        Generate a detailed evolution plan for the substrate computational medium.

        CURRENT STATE:
        {json.dumps(analysis, indent=2, default=str)}

        EVOLUTION STRATEGY: {strategy}
        FOCUS AREA: {focus_area or 'general improvement'}

        Create a step-by-step evolution plan that includes:
        1. Specific improvements to make
        2. New vectors to create
        3. Relations to establish
        4. Quality improvements needed
        5. Expected outcomes

        For each step, specify:
        - Action type (create_vector, improve_vector, create_relation, etc.)
        - Description of what to do
        - Target vectors or areas
        - Success criteria

        Return the plan as a JSON object with this structure:
        {{
            "strategy": "{strategy}",
            "focus_area": "{focus_area or 'general'}",
            "steps": [
                {{
                    "step_number": 1,
                    "action_type": "create_vector",
                    "description": "Create a vector for...",
                    "target": "specific area or vector ID",
                    "vector_type": "component|code|knowledge|etc",
                    "metadata_suggestions": {{}},
                    "success_criteria": "what success looks like"
                }},
                ... more steps ...
            ],
            "expected_improvements": [
                "Improved vector quality",
                "Better relation density",
                "etc"
            ]
        }}

        Make the plan actionable and specific to the current substrate state.
        """

        response = await self._call_lm_studio(prompt, max_tokens=2000, temperature=0.3)

        try:
            # Try to parse JSON from response
            plan_start = response.find('{')
            plan_end = response.rfind('}') + 1
            if plan_start >= 0 and plan_end > plan_start:
                plan_json = response[plan_start:plan_end]
                plan = json.loads(plan_json)

                # Validate plan structure
                if 'steps' in plan and isinstance(plan['steps'], list):
                    return plan
        except json.JSONDecodeError:
            pass

        # Fallback plan if JSON parsing fails
        return {
            'strategy': strategy,
            'focus_area': focus_area or 'general',
            'steps': [
                {
                    'step_number': 1,
                    'action_type': 'analyze_and_improve',
                    'description': 'Analyze low confidence vectors and improve them',
                    'target': 'low_confidence_vectors',
                    'vector_type': 'all',
                    'success_criteria': 'Increase average confidence by 0.1'
                }
            ],
            'expected_improvements': ['Improved vector quality']
        }

    async def _execute_evolution_plan(self, plan: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the evolution plan"""
        print(f"   ⚡ Executing evolution plan: {plan['strategy']}")

        results = {
            'strategy': plan['strategy'],
            'steps_executed': [],
            'vectors_created': [],
            'vectors_improved': [],
            'relations_created': [],
            'errors': []
        }

        for step in plan.get('steps', []):
            print(f"     Step {step.get('step_number', '?')}: {step.get('action_type', 'unknown')}")

            try:
                step_result = await self._execute_evolution_step(step)
                results['steps_executed'].append({
                    'step': step.get('step_number'),
                    'action': step.get('action_type'),
                    'result': step_result
                })

                # Track created/improved items
                if step_result.get('created_vector_id'):
                    results['vectors_created'].append(step_result['created_vector_id'])
                if step_result.get('improved_vector_id'):
                    results['vectors_improved'].append(step_result['improved_vector_id'])
                if step_result.get('created_relations'):
                    results['relations_created'].extend(step_result['created_relations'])

            except Exception as e:
                error_msg = f"Step {step.get('step_number', '?')} failed: {str(e)}"
                print(f"       ❌ {error_msg}")
                results['errors'].append(error_msg)

        return results

    async def _execute_evolution_step(self, step: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a single evolution step"""
        action_type = step.get('action_type', '').lower()

        if action_type == 'create_vector':
            return await self._execute_create_vector(step)
        elif action_type == 'improve_vector':
            return await self._execute_improve_vector(step)
        elif action_type == 'create_relation':
            return await self._execute_create_relation(step)
        elif action_type == 'refine_vector':
            return await self._execute_refine_vector(step)
        elif action_type == 'extract_pattern':
            return await self._execute_extract_pattern(step)
        elif action_type == 'generate_abstraction':
            return await self._execute_generate_abstraction(step)
        else:
            # Default: analyze and suggest
            return await self._execute_analyze_and_suggest(step)

    async def _execute_create_vector(self, step: Dict) -> Dict[str, Any]:
        """Create a new vector based on step description"""
        description = step.get('description', '')
        vector_type = step.get('vector_type', 'knowledge')
        metadata = step.get('metadata_suggestions', {})

        # Use LM Studio to generate vector content
        prompt = f"""
        Based on this evolution step, create content for a new vector:

        STEP: {description}
        VECTOR TYPE: {vector_type}
        METADATA SUGGESTIONS: {json.dumps(metadata)}

        For a {vector_type} vector, provide:
        1. A meaningful name/title
        2. Detailed content/description
        3. Key concepts or tags
        4. Suggested relations to other vectors

        Return as JSON:
        {{
            "name": "vector name",
            "content": "detailed description",
            "concepts": ["concept1", "concept2"],
            "suggested_relations": [
                {{"type": "relation_type", "to_concept": "target"}}
            ]
        }}
        """

        response = await self._call_lm_studio(prompt, max_tokens=500, temperature=0.4)

        try:
            content = json.loads(response)
        except:
            content = {
                "name": f"Vector for {description[:50]}",
                "content": description,
                "concepts": [vector_type, "evolution_generated"],
                "suggested_relations": []
            }

        # Create vector (simplified - in reality would generate proper embedding)
        vector = self._generate_vector_from_content(content)

        # Store vector
        vector_id = await self.substrate.store_vector(
            vector,
            VectorType(vector_type),
            metadata={
                **metadata,
                'evolution_generated': True,
                'evolution_step': step.get('step_number'),
                'content': content
            }
        )

        return {
            'created_vector_id': vector_id,
            'vector_type': vector_type,
            'content_summary': content.get('name', 'unnamed')
        }

    async def _execute_improve_vector(self, step: Dict) -> Dict[str, Any]:
        """Improve an existing vector"""
        target = step.get('target', '')

        # Find vector to improve
        vector_to_improve = None

        if target.startswith('vector_') or len(target) == 16:  # Looks like a vector ID
            vector_to_improve = await self.substrate.get_vector(target)

        if not vector_to_improve:
            # Search for vectors matching target
            search_results = await self.substrate.search_vectors(target, limit=1)
            if search_results:
                vector_to_improve = search_results[0]['vector']

        if not vector_to_improve:
            return {'error': f'No vector found for target: {target}'}

        # Use LM Studio to suggest improvements
        prompt = f"""
        Improve this existing vector:

        VECTOR ID: {vector_to_improve.id}
        TYPE: {vector_to_improve.vector_type.value}
        CURRENT METADATA: {json.dumps(vector_to_improve.metadata, indent=2, default=str)}
        IMPROVEMENT GOAL: {step.get('description', 'General improvement')}

        Suggest specific improvements:
        1. Metadata enhancements
        2. Content improvements
        3. Relation suggestions
        4. Confidence boost methods

        Return improvement suggestions as JSON.
        """

        response = await self._call_lm_studio(prompt, max_tokens=400, temperature=0.3)

        try:
            improvements = json.loads(response)
        except:
            improvements = {'suggestions': ['Increase confidence', 'Add more metadata']}

        # Apply improvements (simplified)
        improved_metadata = {
            **vector_to_improve.metadata,
            'improved': True,
            'improvement_suggestions': improvements,
            'last_improved': datetime.now().isoformat()
        }

        # Create improved version
        improved_vector = vector_to_improve.vector.copy()
        # Slightly modify vector (in reality, would use embedding of improved content)
        improved_vector = [v * 1.05 for v in improved_vector]  # Small boost

        improved_id = await self.substrate.store_vector(
            improved_vector,
            vector_to_improve.vector_type,
            metadata=improved_metadata
        )

        # Create relation from old to improved
        await self.substrate.create_relation(
            vector_to_improve.id, improved_id,
            relation_type='improved_to',
            strength=0.8,
            metadata={'improvement_step': step.get('step_number')}
        )

        return {
            'improved_vector_id': improved_id,
            'original_vector_id': vector_to_improve.id,
            'improvements_applied': list(improvements.keys()) if isinstance(improvements, dict) else []
        }

    async def _execute_create_relation(self, step: Dict) -> Dict[str, Any]:
        """Create new relations between vectors"""
        # This would analyze vectors and suggest meaningful relations
        # For now, create some sample relations

        # Get some vectors
        cursor = self.substrate.conn.execute(
            "SELECT id FROM vectors ORDER BY RANDOM() LIMIT 4"
        )
        vector_ids = [row['id'] for row in cursor]

        if len(vector_ids) < 2:
            return {'error': 'Not enough vectors to create relations'}

        # Create relations
        created = []
        for i in range(min(3, len(vector_ids) - 1)):
            await self.substrate.create_relation(
                vector_ids[i], vector_ids[i + 1],
                relation_type='semantically_related',
                strength=0.7,
                metadata={'evolution_generated': True}
            )
            created.append(f"{vector_ids[i][:8]}->{vector_ids[i+1][:8]}")

        return {'created_relations': created}

    async def _execute_refine_vector(self, step: Dict) -> Dict[str, Any]:
        """Refine vector quality"""
        # Get low confidence vectors
        cursor = self.substrate.conn.execute(
            "SELECT id FROM vectors WHERE confidence < 0.7 LIMIT 3"
        )

        refined = []
        for row in cursor:
            vector = await self.substrate.get_vector(row['id'])
            if vector:
                # Increase confidence
                await self.substrate.update_vector(
                    vector.id,
                    confidence=min(vector.confidence * 1.2, 0.95)
                )
                refined.append(vector.id[:12])

        return {'refined_vectors': refined}

    async def _execute_extract_pattern(self, step: Dict) -> Dict[str, Any]:
        """Extract patterns from existing vectors"""
        # Sample some vectors and look for patterns
        cursor = self.substrate.conn.execute(
            "SELECT vector_data FROM vectors WHERE vector_type = 'component' LIMIT 10"
        )

        patterns = []
        for row in cursor:
            entry = VectorEntry.from_bytes(row['vector_data'])
            # Extract concepts from metadata
            concepts = entry.metadata.get('concepts', [])
            if concepts and len(concepts) > 2:
                patterns.append({
                    'common_concepts': concepts[:3],
                    'vector_type': entry.vector_type.value
                })

        # Store pattern as knowledge vector
        if patterns:
            pattern_vector = self._generate_vector_from_content({'patterns': patterns[:3]})
            pattern_id = await self.substrate.store_vector(
                pattern_vector,
                VectorType.KNOWLEDGE_VECTOR,
                metadata={
                    'type': 'extracted_pattern',
                    'patterns': patterns[:3],
                    'source_count': len(patterns)
                }
            )

            return {
                'pattern_vector_id': pattern_id,
                'patterns_found': len(patterns),
                'example_patterns': patterns[:2]
            }

        return {'patterns_found': 0}

    async def _execute_generate_abstraction(self, step: Dict) -> Dict[str, Any]:
        """Generate higher-level abstractions"""
        # Get related vectors and create abstraction
        # Simplified for now

        abstraction_vector = [0.5] * 1536  # Placeholder
        abstraction_id = await self.substrate.store_vector(
            abstraction_vector,
            VectorType.KNOWLEDGE_VECTOR,
            metadata={
                'type': 'evolution_abstraction',
                'description': 'Higher-level abstraction generated by evolution',
                'evolution_step': step.get('step_number')
            }
        )

        return {'abstraction_vector_id': abstraction_id}

    async def _execute_analyze_and_suggest(self, step: Dict) -> Dict[str, Any]:
        """Generic analysis and suggestion step"""
        description = step.get('description', '')

        # Use LM Studio to analyze and suggest
        prompt = f"""
        Analyze and suggest improvements for the substrate based on:

        EVOLUTION STEP: {description}

        Provide specific, actionable suggestions for improving the substrate computational medium.
        Focus on practical changes that can be implemented.

        Return suggestions as a JSON list of actionable items.
        """

        response = await self._call_lm_studio(prompt, max_tokens=300, temperature=0.3)

        try:
            suggestions = json.loads(response)
        except:
            suggestions = ['Continue evolution process', 'Monitor improvement metrics']

        return {
            'analysis_complete': True,
            'suggestions': suggestions if isinstance(suggestions, list) else [suggestions]
        }

    async def _evaluate_improvement(self,
                                  before_analysis: Dict,
                                  evolution_results: Dict) -> float:
        """Evaluate how much improvement occurred"""

        # Get updated statistics
        stats = await self.substrate.get_statistics()

        # Calculate improvement score (0-1)
        improvement_factors = []

        # 1. Check if new vectors were created
        new_vectors = len(evolution_results.get('vectors_created', []))
        if new_vectors > 0:
            improvement_factors.append(min(new_vectors / 10, 1.0))

        # 2. Check if vectors were improved
        improved_vectors = len(evolution_results.get('vectors_improved', []))
        if improved_vectors > 0:
            improvement_factors.append(min(improved_vectors / 5, 1.0))

        # 3. Check if relations were created
        new_relations = len(evolution_results.get('relations_created', []))
        if new_relations > 0:
            improvement_factors.append(min(new_relations / 5, 1.0))

        # 4. Check for errors (negative factor)
        errors = len(evolution_results.get('errors', []))
        if errors > 0:
            improvement_factors.append(-min(errors / 3, 0.5))

        # Average the factors
        if improvement_factors:
            raw_score = sum(improvement_factors) / len(improvement_factors)
            # Normalize to 0-1 range
            improvement_score = max(0.0, min(1.0, (raw_score + 1) / 2))
            return improvement_score

        return 0.1  # Minimal improvement for trying

    async def _store_evolution_result(self,
                                    cycle: int,
                                    strategy: str,
                                    improvement_score: float,
                                    results: Dict[str, Any]):
        """Store evolution results in substrate"""

        # Create evolution result vector
        evolution_vector = self._generate_evolution_vector(cycle, strategy, improvement_score)

        await self.substrate.store_vector(
            evolution_vector,
            VectorType.EVOLUTION_VECTOR,
            metadata={
                'type': 'evolution_cycle_result',
                'cycle_number': cycle,
                'strategy': strategy,
                'improvement_score': improvement_score,
                'results_summary': {
                    'vectors_created': len(results.get('vectors_created', [])),
                    'vectors_improved': len(results.get('vectors_improved', [])),
                    'relations_created': len(results.get('relations_created', [])),
                    'errors': len(results.get('errors', []))
                },
                'timestamp': datetime.now().isoformat()
            }
        )

        # Store in history
        self.evolution_history.append({
            'cycle': cycle,
            'strategy': strategy,
            'improvement_score': improvement_score,
            'timestamp': datetime.now().isoformat()
        })

    def _generate_vector_from_content(self, content: Dict) -> List[float]:
        """Generate a vector from content (simplified)"""
        # In reality, would use proper embedding model
        # For now, create deterministic vector from content hash

        import hashlib
        content_str = json.dumps(content, sort_keys=True)
        content_hash = hashlib.sha256(content_str.encode()).hexdigest()

        # Convert hash to vector
        vector = [0.0] * 1536
        for i in range(0, len(content_hash), 6):
            hex_val = content_hash[i:i+6]
            try:
                val = int(hex_val, 16) / 0xFFFFFF  # Normalize to 0-1
                dim = i // 6 % 1536
                vector[dim] = val
            except:
                pass

        return vector

    def _generate_evolution_vector(self, cycle: int, strategy: str, score: float) -> List[float]:
        """Generate vector representing evolution cycle"""
        # Create deterministic vector based on evolution parameters
        base = [0.0] * 1536

        # Encode cycle number
        cycle_hash = hash(str(cycle)) % 1000 / 1000
        base[0] = cycle_hash

        # Encode strategy
        strategy_idx = self.strategies.index(strategy) if strategy in self.strategies else 0
        base[1] = strategy_idx / len(self.strategies)

        # Encode improvement score
        base[2] = score

        # Add some noise for uniqueness
        import random
        for i in range(10, 20):
            base[i] = random.random() * 0.1

        return base

    async def _call_lm_studio(self,
                            prompt: str,
                            max_tokens: int = 500,
                            temperature: float = 0.3) -> str:
        """Call LM Studio API"""
        if not self.session:
            await self.connect()

        try:
            async with self.session.post(
                self.lm_studio_url,
                json={
                    "prompt": prompt,
                    "max_tokens": max_tokens,
                    "temperature": temperature,
                    "stop": ["###", "```", "<|endoftext|>"]
                }
            ) as response:
                if response.status == 200:
                    result = await response.json()
                    return result.get("choices", [{}])[0].get("text", "").strip()
                else:
                    error_text = await response.text()
                    print(f"LM Studio error: {response.status} - {error_text}")
                    return f"# Error from LM Studio: {response.status}"
        except Exception as e:
            print(f"LM Studio connection error: {e}")
            # Fallback response
            return json.dumps({
                "error": "LM Studio unavailable",
                "fallback": "Using fallback evolution logic"
            })

    async def get_evolution_report(self) -> Dict[str, Any]:
        """Generate evolution report"""
        stats = await self.substrate.get_statistics()

        return {
            'evolution_history': self.evolution_history,
            'current_substrate': stats,
            'total_evolution_cycles': len(self.evolution_history),
            'avg_improvement': (
                sum(h['improvement_score'] for h in self.evolution_history) /
                len(self.evolution_history) if self.evolution_history else 0
            ),
            'preferred_strategies': (
                max(set(h['strategy'] for h in self.evolution_history),
                    key=[h['strategy'] for h in self.evolution_history].count)
                if self.evolution_history else 'none'
            )
        }

async def main():
    agent = SubstrateEvolutionAgent()
    await agent.connect()
    await agent.evolve_substrate(max_iterations=1)
    await agent.disconnect()

if __name__ == "__main__":
    asyncio.run(main())