from typing import List, Dict, Any
import json
from datetime import datetime

class TokenManager:
    def __init__(self, daily_budget: int = 100000):
        self.daily_budget = daily_budget
        self.spent_today = 0
        self.budget_categories = {
            "evolution": 0.40,      # 40% for architecture evolution
            "verification": 0.30,   # 30% for truth verification
            "inference": 0.20,      # 20% for user queries
            "maintenance": 0.10     # 10% for system maintenance
        }
        self.category_spending = {
            "evolution": 0,
            "verification": 0,
            "inference": 0,
            "maintenance": 0
        }
        self.efficiency_tracker = TokenEfficiencyTracker()

    async def spend_tokens(self, operation: str, estimated_cost: int, improvement: float = 0.0) -> bool:
        """Check if tokens can be spent, and record if so"""
        category = self.categorize_operation(operation)
        category_budget = self.daily_budget * self.budget_categories[category]
        category_spent = self.category_spending[category]

        if category_spent + estimated_cost > category_budget:
            return False  # Budget exceeded

        if self.spent_today + estimated_cost > self.daily_budget:
            return False  # Overall budget exceeded

        # Check conservation mode for non-critical operations
        if self.efficiency_tracker.is_in_conservation_mode() and estimated_cost > 1000:
            if operation not in ["verification", "critical_evolution"]:
                print(f"⚠️  Conservation mode: blocking {operation} with {estimated_cost} tokens")
                return False

        # Record spending
        self.category_spending[category] += estimated_cost
        self.spent_today += estimated_cost

        # Track efficiency if improvement is provided
        if improvement > 0:
            await self.efficiency_tracker.record_efficiency(operation, estimated_cost, improvement)

        return True

    async def prioritize_operations(self, operations: List[Dict], ctrm) -> List[Dict]:
        """Prioritize operations based on CTRM confidence and token efficiency"""
        prioritized = []
        for op in operations:
            # Calculate expected value per token
            truth = await ctrm.get_truth(op["truth_id"])

            if truth:
                expected_value = (
                    truth["confidence"] * 0.4 +
                    truth["importance_score"] * 0.3 +
                    (1 - truth["distance_from_center"] / 100) * 0.3
                )

                value_per_token = expected_value / op["estimated_tokens"]

                prioritized.append({
                    **op,
                    "value_per_token": value_per_token,
                    "priority_score": value_per_token * expected_value
                })

        return sorted(prioritized, key=lambda x: x["priority_score"], reverse=True)

    def categorize_operation(self, operation: str) -> str:
        """Categorize operation for budgeting"""
        if "evolution" in operation.lower():
            return "evolution"
        elif "verify" in operation.lower():
            return "verification"
        elif "inference" in operation.lower() or "query" in operation.lower():
            return "inference"
        else:
            return "maintenance"

    async def reset_daily_budget(self):
        """Reset daily token budget"""
        self.spent_today = 0
        self.category_spending = {
            "evolution": 0,
            "verification": 0,
            "inference": 0,
            "maintenance": 0
        }

    async def get_budget_status(self) -> Dict[str, Any]:
        """Get current budget status"""
        return {
            "total_budget": self.daily_budget,
            "total_spent": self.spent_today,
            "remaining": self.daily_budget - self.spent_today,
            "categories": {
                cat: {
                    "budget": self.daily_budget * self.budget_categories[cat],
                    "spent": self.category_spending[cat],
                    "remaining": self.daily_budget * self.budget_categories[cat] - self.category_spending[cat]
                }
                for cat in self.budget_categories
            }
        }

    async def has_budget_for(self, operation: str, estimated_cost: int) -> bool:
        """Check if there's budget for a specific operation"""
        category = self.categorize_operation(operation)
        category_budget = self.daily_budget * self.budget_categories[category]
        category_spent = self.category_spending[category]

        return (category_spent + estimated_cost <= category_budget and

class TokenEfficiencyTracker:
    def __init__(self):
        self.efficiency_history = []
        self.low_efficiency_threshold = 0.001  # Minimum acceptable efficiency
        self.conservation_mode = False

    async def record_efficiency(self, operation: str, tokens_spent: int, improvement: float):
        """Record token efficiency for an operation"""
        efficiency = improvement / tokens_spent if tokens_spent > 0 else 0
        self.efficiency_history.append({
            "operation": operation,
            "tokens_spent": tokens_spent,
            "improvement": improvement,
            "efficiency": efficiency,
            "timestamp": datetime.now().isoformat()
        })

        # Remove old entries (keep last 100)
        if len(self.efficiency_history) > 100:
            self.efficiency_history = self.efficiency_history[-100:]

        # Check if we should enter/exit conservation mode
        if tokens_spent > 1000:  # Only for significant operations
            if efficiency < self.low_efficiency_threshold:
                self.conservation_mode = True
                print(f"⚠️  Low efficiency detected: {efficiency:.6f}, entering conservation mode")
            elif efficiency > self.low_efficiency_threshold * 2 and self.conservation_mode:
                self.conservation_mode = False
                print(f"🌱 Efficiency recovered: {efficiency:.6f}, exiting conservation mode")

        return efficiency

    def get_current_efficiency(self) -> float:
        """Get current average efficiency"""
        if not self.efficiency_history:
            return 0.0
        recent_efficiency = self.efficiency_history[-10:] if len(self.efficiency_history) > 10 else self.efficiency_history
        avg_efficiency = sum(entry["efficiency"] for entry in recent_efficiency) / len(recent_efficiency)
        return avg_efficiency

    def is_in_conservation_mode(self) -> bool:
        """Check if in conservation mode"""
        return self.conservation_mode

    async def get_efficiency_report(self) -> Dict[str, Any]:
        """Get efficiency report"""
        if not self.efficiency_history:
            return {"status": "no_data"}

        total_tokens = sum(entry["tokens_spent"] for entry in self.efficiency_history)
        total_improvement = sum(entry["improvement"] for entry in self.efficiency_history)
        avg_efficiency = total_improvement / total_tokens if total_tokens > 0 else 0

        return {
            "total_operations": len(self.efficiency_history),
            "total_tokens_spent": total_tokens,
            "total_improvement": total_improvement,
            "average_efficiency": avg_efficiency,
            "conservation_mode": self.conservation_mode,
            "recent_trend": "improving" if avg_efficiency > self.low_efficiency_threshold else "declining"
        }
                self.spent_today + estimated_cost <= self.daily_budget)

    async def get_available_budget(self, category: str = None) -> int:
        """Get available budget for a specific category or overall"""
        if category:
            category_budget = self.daily_budget * self.budget_categories.get(category, 0)
            category_spent = self.category_spending.get(category, 0)
            return max(0, category_budget - category_spent)
        else:
            return max(0, self.daily_budget - self.spent_today)

    async def get_category_available_budget(self, operation: str) -> int:
        """Get available budget for a specific operation category"""
        category = self.categorize_operation(operation)

    async def get_efficiency_status(self) -> Dict[str, Any]:
        """Get current efficiency status"""
        return await self.efficiency_tracker.get_efficiency_report()

    def is_in_conservation_mode(self) -> bool:
        """Check if in conservation mode"""
        return self.efficiency_tracker.is_in_conservation_mode()
        return await self.get_available_budget(category)