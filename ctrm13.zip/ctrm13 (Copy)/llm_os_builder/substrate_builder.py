from substrate.vector_db import VectorSubstrate, VectorType, VectorEntry
from script2vec.script2vec import Script2Vec
import asyncio
import json
from typing import Dict, List, Any, Optional
import hashlib
import numpy as np
from datetime import datetime

class SubstrateLLMOSBuilder:
    """
    LLM OS Builder that uses Vector Substrate as computational medium
    No files - everything stored in the vector database
    """

    def __init__(self,
                 substrate_db: str = "./llm_os_substrate.db",
                 llm_endpoint: str = "http://localhost:1234/v1/completions"):

        # Initialize substrate
        self.substrate = VectorSubstrate(substrate_db)

        # Initialize tools
        self.script2vec = Script2Vec()

        # LLM connection
        self.llm_endpoint = llm_endpoint

        # Component registry (stored in substrate)
        self.component_registry = {}  # component_id -> substrate_vector_id

    async def build_component(self,
                            requirement: str,
                            component_name: Optional[str] = None) -> Dict[str, Any]:
        """
        Build component and store everything in substrate
        """
        print(f"🔨 Building component in substrate: {requirement}")

        # Step 1: Design (store design as vector)
        design = await self._llm_design(requirement)
        design_vector = self._design_to_vector(design)
        design_id = await self.substrate.store_vector(
            design_vector,
            VectorType.KNOWLEDGE_VECTOR,
            metadata={
                'type': 'component_design',
                'requirement': requirement,
                'design': design
            }
        )

        # Step 2: Write code (store code as vector)
        code = await self._llm_write_code(design, component_name)
        code_vector = self.script2vec.python_to_vector(code)

        # Store code vector
        code_id = await self.substrate.store_vector(
            code_vector["vector"],
            VectorType.CODE_VECTOR,
            metadata={
                'type': 'component_code',
                'component_name': component_name,
                'code': code,
                'concepts': code_vector["concepts"],
                'requirements': [requirement]
            }
        )

        # Step 3: Create relation between design and code
        await self.substrate.create_relation(
            design_id, code_id,
            relation_type="implements",
            strength=0.9,
            metadata={'mapping': 'design_to_implementation'}
        )

        # Step 4: Execute and test (store results as vector)
        execution_result = await self._execute_and_test_in_substrate(code)

        # Store execution vector
        execution_id = await self.substrate.store_vector(
            self._result_to_vector(execution_result),
            VectorType.EXECUTION_VECTOR,
            metadata={
                'type': 'component_execution',
                'code_id': code_id,
                'result': execution_result
            }
        )

        # Create relation between code and execution
        await self.substrate.create_relation(
            code_id, execution_id,
            relation_type="executes_to",
            strength=execution_result.get('success_rate', 0.5)
        )

        # Step 5: Create component composite vector
        component_vector = self._combine_component_vectors(
            design_vector, code_vector["vector"], execution_result
        )

        # Store component vector
        component_id = await self.substrate.store_vector(
            component_vector,
            VectorType.COMPONENT_VECTOR,
            metadata={
                'name': component_name or f"component_{code_id[:8]}",
                'requirement': requirement,
                'design_id': design_id,
                'code_id': code_id,
                'execution_id': execution_id,
                'tests_passed': execution_result.get('tests_passed', 0),
                'tests_total': execution_result.get('tests_total', 0)
            }
        )

        # Link all parts to component
        for part_id, relation_type in [
            (design_id, "has_design"),
            (code_id, "has_implementation"),
            (execution_id, "has_execution_result")
        ]:
            await self.substrate.create_relation(
                component_id, part_id, relation_type, strength=0.9
            )

        # Register component
        self.component_registry[component_id] = component_id

        print(f"✅ Component built in substrate: {component_id}")

        return {
            'component_id': component_id,
            'design_id': design_id,
            'code_id': code_id,
            'execution_id': execution_id,
            'metadata': {
                'name': component_name,
                'requirement': requirement,
                'tests_passed': execution_result.get('tests_passed', 0),
                'tests_total': execution_result.get('tests_total', 0)
            }
        }

    async def build_os_from_components(self,
                                     component_ids: List[str]) -> str:
        """
        Build OS by composing components in substrate
        """
        print(f"🧩 Composing OS from {len(component_ids)} components in substrate")

        # Get component vectors
        component_vectors = []
        for comp_id in component_ids:
            entry = await self.substrate.get_vector(comp_id)
            if entry and entry.vector_type == VectorType.COMPONENT_VECTOR:
                component_vectors.append(entry.vector)

        if not component_vectors:
            raise ValueError("No valid component vectors found")

        # Create OS vector (average of components)
        os_vector = self._average_vectors(component_vectors)

        # Ask LLM to compose integration code
        integration_code = await self._llm_compose_integration(component_ids)

        # Store integration as vector
        integration_vector = self.script2vec.python_to_vector(integration_code)
        integration_id = await self.substrate.store_vector(
            integration_vector["vector"],
            VectorType.CODE_VECTOR,
            metadata={
                'type': 'os_integration',
                'component_ids': component_ids,
                'code': integration_code
            }
        )

        # Create OS vector entry
        os_id = await self.substrate.store_vector(
            os_vector,
            VectorType.OS_VECTOR,
            metadata={
                'type': 'llm_os',
                'component_ids': component_ids,
                'integration_id': integration_id,
                'component_count': len(component_ids)
            }
        )

        # Create relations from OS to components
        for comp_id in component_ids:
            await self.substrate.create_relation(
                os_id, comp_id,
                relation_type="contains_component",
                strength=0.8
            )

        # Create relation to integration
        await self.substrate.create_relation(
            os_id, integration_id,
            relation_type="has_integration",
            strength=0.9
        )

        print(f"✅ OS composed in substrate: {os_id}")

        return os_id

    async def improve_component(self,
                              component_id: str,
                              issue: str) -> Dict[str, Any]:
        """
        Improve component using substrate context
        """
        print(f"🔄 Improving component: {component_id}")

        # Get component and its relations
        component = await self.substrate.get_vector(component_id)
        if not component:
            raise ValueError(f"Component {component_id} not found")

        # Get related vectors (design, code, execution)
        related = await self.substrate.get_related_vectors(component_id)

        # Find code implementation
        code_id = None
        for rel in related:
            if rel['relation_type'] == 'has_implementation':
                code_entry = await self.substrate.get_vector(rel['vector'].id)
                if code_entry and code_entry.vector_type == VectorType.CODE_VECTOR:
                    code_id = code_entry.id
                    break

        if not code_id:
            raise ValueError("No code implementation found for component")

        # Get the code
        code_entry = await self.substrate.get_vector(code_id)
        code = code_entry.metadata.get('code', '')

        # Ask LLM to improve code based on issue
        improved_code = await self._llm_improve_code(code, issue)

        # Create new code vector
        improved_vector = self.script2vec.python_to_vector(improved_code)
        improved_code_id = await self.substrate.store_vector(
            improved_vector["vector"],
            VectorType.CODE_VECTOR,
            metadata={
                'type': 'improved_component_code',
                'original_code_id': code_id,
                'improvement_reason': issue,
                'code': improved_code,
                'concepts': improved_vector["concepts"]
            }
        )

        # Create relation from old to new code
        await self.substrate.create_relation(
            code_id, improved_code_id,
            relation_type="improved_to",
            strength=0.7,
            metadata={'issue': issue}
        )

        # Create new component vector (evolved from original)
        component_entry = await self.substrate.get_vector(component_id)
        evolved_vector = self._evolve_vector(
            component_entry.vector,
            improved_vector.vector,
            evolution_rate=0.3
        )

        # Store evolved component
        evolved_id = await self.substrate.store_vector(
            evolved_vector,
            VectorType.COMPONENT_VECTOR,
            metadata={
                'type': 'evolved_component',
                'original_component_id': component_id,
                'improved_code_id': improved_code_id,
                'improvement_reason': issue,
                'evolution_step': component_entry.metadata.get('evolution_step', 0) + 1
            }
        )

        # Copy relations from original component
        for rel in related:
            if rel['relation_type'] not in ['has_implementation', 'has_execution_result']:
                await self.substrate.create_relation(
                    evolved_id, rel['vector'].id,
                    relation_type=rel['relation_type'],
                    strength=rel['strength'] * 0.9  # Slightly weaker for evolved version
                )

        # Link to improved code
        await self.substrate.create_relation(
            evolved_id, improved_code_id,
            relation_type="has_implementation",
            strength=0.9
        )

        print(f"✅ Component evolved: {evolved_id}")

        return {
            'evolved_component_id': evolved_id,
            'original_component_id': component_id,
            'improved_code_id': improved_code_id,
            'evolution_step': component_entry.metadata.get('evolution_step', 0) + 1
        }

    async def find_similar_components(self,
                                    query: str,
                                    top_k: int = 5) -> List[Dict[str, Any]]:
        """
        Find similar components in substrate
        """
        # Convert query to vector
        query_vector = self.script2vec.python_to_vector(query)

        # Search in substrate
        results = await self.substrate.find_similar_vectors(
            query_vector["vector"],
            vector_type=VectorType.COMPONENT_VECTOR,
            top_k=top_k,
            threshold=0.6
        )

        # Enrich results with metadata
        enriched = []
        for result in results:
            entry = await self.substrate.get_vector(result['id'])
            if entry:
                # Get related code
                related = await self.substrate.get_related_vectors(
                    entry.id, relation_type='has_implementation', max_depth=1
                )

                code_preview = ""
                if related:
                    code_entry = await self.substrate.get_vector(related[0]['vector'].id)
                    if code_entry:
                        code_preview = code_entry.metadata.get('code', '')[:200] + "..."

                enriched.append({
                    'component_id': entry.id,
                    'similarity': result['similarity'],
                    'metadata': entry.metadata,
                    'code_preview': code_preview,
                    'confidence': entry.confidence
                })

        return enriched

    async def analyze_os_state(self) -> Dict[str, Any]:
        """
        Analyze current OS state using substrate
        """
        print("🔍 Analyzing OS state in substrate")

        # Get all OS vectors
        stats = await self.substrate.get_statistics()

        # Get all components
        components = []
        cursor = self.substrate.conn.execute(
            "SELECT id, metadata_json FROM vectors WHERE vector_type = ?",
            ('component',)
        )

        for row in cursor:
            metadata = json.loads(row['metadata_json']) if row['metadata_json'] else {}
            components.append({
                'id': row['id'],
                'name': metadata.get('name', 'unknown'),
                'tests_passed': metadata.get('tests_passed', 0),
                'tests_total': metadata.get('tests_total', 0)
            })

        # Calculate component statistics
        total_tests = sum(c['tests_total'] for c in components)
        passed_tests = sum(c['tests_passed'] for c in components)
        test_success_rate = passed_tests / total_tests if total_tests > 0 else 0

        # Find component clusters
        clusters = await self.substrate.compute_clusters(
            vector_type=VectorType.COMPONENT_VECTOR,
            n_clusters=min(5, len(components))
        )

        # Generate OS summary vector
        if components:
            component_ids = [c['id'] for c in components]
            component_vectors = []

            for comp_id in component_ids:
                entry = await self.substrate.get_vector(comp_id)
                if entry:
                    component_vectors.append(entry.vector)

            if component_vectors:
                os_summary_vector = self._average_vectors(component_vectors)

                # Store OS state snapshot
                snapshot_id = await self.substrate.store_vector(
                    os_summary_vector,
                    VectorType.OS_VECTOR,
                    metadata={
                        'type': 'os_state_snapshot',
                        'timestamp': datetime.now().isoformat(),
                        'component_count': len(components),
                        'test_success_rate': test_success_rate,
                        'clusters': clusters.get('clusters', {})
                    }
                )

        return {
            'component_count': len(components),
            'total_tests': total_tests,
            'passed_tests': passed_tests,
            'test_success_rate': test_success_rate,
            'clusters': clusters.get('clusters', {}),
            'substrate_statistics': stats,
            'snapshot_id': snapshot_id if 'snapshot_id' in locals() else None
        }

    async def export_os(self, os_id: str, export_path: str):
        """
        Export OS from substrate to files (for execution)
        """
        print(f"📤 Exporting OS {os_id} to {export_path}")

        # Get OS vector
        os_entry = await self.substrate.get_vector(os_id)
        if not os_entry or os_entry.vector_type != VectorType.OS_VECTOR:
            raise ValueError(f"Not a valid OS vector: {os_id}")

        # Get components
        components = await self.substrate.get_related_vectors(
            os_id, relation_type="contains_component"
        )

        # Get integration code
        integration = await self.substrate.get_related_vectors(
            os_id, relation_type="has_integration"
        )

        # Create export directory
        import os
        os.makedirs(export_path, exist_ok=True)
        os.makedirs(f"{export_path}/components", exist_ok=True)

        # Export components
        for comp in components:
            comp_entry = comp['vector']

            # Get code implementation
            code_rels = await self.substrate.get_related_vectors(
                comp_entry.id, relation_type="has_implementation"
            )

            if code_rels:
                code_entry = code_rels[0]['vector']
                code = code_entry.metadata.get('code', '')

                # Write component file
                comp_name = comp_entry.metadata.get('name', comp_entry.id[:8])
                with open(f"{export_path}/components/{comp_name}.py", 'w') as f:
                    f.write(code)

        # Export integration
        if integration:
            code_entry = integration[0]['vector']
            code = code_entry.metadata.get('code', '')

            with open(f"{export_path}/main.py", 'w') as f:
                f.write(code)

        # Export metadata
        metadata = {
            'os_id': os_id,
            'export_timestamp': datetime.now().isoformat(),
            'component_count': len(components),
            'components': [
                {
                    'id': c['vector'].id,
                    'name': c['vector'].metadata.get('name', 'unknown')
                }
                for c in components
            ]
        }

        with open(f"{export_path}/metadata.json", 'w') as f:
            json.dump(metadata, f, indent=2)

        print(f"✅ OS exported to {export_path}")

    # Helper methods
    def _design_to_vector(self, design: Dict) -> List[float]:
        """Convert design JSON to vector"""
        design_str = json.dumps(design, sort_keys=True)
        # Simple hash-based vector (in reality, use proper embedding)
        vector = [0.0] * 1536
        design_hash = hashlib.sha256(design_str.encode()).hexdigest()

        for i in range(0, len(design_hash), 4):
            hex_val = design_hash[i:i+4]
            dim = int(hex_val, 16) % 1536
            vector[dim] = 1.0

        return vector

    def _result_to_vector(self, result: Dict) -> List[float]:
        """Convert execution result to vector"""
        vector = [0.0] * 1536

        # Encode success rate
        success = result.get('success', False)
        vector[0] = 1.0 if success else 0.0

        # Encode test results
        tests_passed = result.get('tests_passed', 0)
        tests_total = result.get('tests_total', 1)
        success_rate = tests_passed / tests_total
        vector[1] = success_rate

        # Encode error types if any
        if 'errors' in result:
            error_count = len(result['errors'])
            vector[2] = min(error_count / 10, 1.0)

        return vector

    def _combine_component_vectors(self,
                                 design_vector: List[float],
                                 code_vector: List[float],
                                 execution_result: Dict) -> List[float]:
        """Combine component parts into single vector"""
        result_vector = self._result_to_vector(execution_result)

        # Weighted combination
        combined = []
        for d, c, r in zip(design_vector, code_vector, result_vector):
            combined.append(0.3 * d + 0.5 * c + 0.2 * r)

        return combined

    def _average_vectors(self, vectors: List[List[float]]) -> List[float]:
        """Average multiple vectors"""
        if not vectors:
            return [0.0] * 1536

        avg = [0.0] * len(vectors[0])
        for vec in vectors:
            for i, val in enumerate(vec):
                avg[i] += val / len(vectors)

        return avg

    def _evolve_vector(self,
                      original: List[float],
                      improvement: List[float],
                      evolution_rate: float = 0.3) -> List[float]:
        """Evolve vector towards improvement"""
        evolved = []
        for orig, imp in zip(original, improvement):
            evolved.append(orig * (1 - evolution_rate) + imp * evolution_rate)

        return evolved

    async def _execute_and_test_in_substrate(self, code: str) -> Dict[str, Any]:
        """Execute code and return results (store in substrate)"""
        # Simplified execution for now
        # In reality: execute code, run tests, capture results

        return {
            'success': True,
            'tests_passed': 1,
            'tests_total': 1,
            'execution_time': 0.1,
            'memory_used': 1024
        }

    # LLM methods (same as before but store in substrate)
    async def _llm_design(self, requirement: str) -> Dict:
        """Generate design from requirement using LLM"""
        # Simplified for now - in reality would call LLM API
        return {
            'requirement': requirement,
            'design': f"Design for: {requirement}",
            'components': ['main_logic', 'error_handling'],
            'interfaces': ['input_validation', 'output_formatting']
        }

    async def _llm_write_code(self, design: Dict, name: Optional[str]) -> str:
        """Generate code from design using LLM"""
        # Simplified for now
        component_name = name or "generated_component"
        return f"""
class {component_name}:
    def __init__(self):
        pass

    def execute(self):
        # Implementation based on design: {design['requirement']}
        return "Result from {component_name}"
"""

    async def _llm_compose_integration(self, component_ids: List[str]) -> str:
        """Generate integration code for components"""
        imports = "\n".join(f"from components.comp_{i} import Component{i}" for i in range(len(component_ids)))
        component_instances = ",\n            ".join(f"Component{i}()" for i in range(len(component_ids)))

        return f"""
# Integration code for {len(component_ids)} components
import sys
import os

# Import components
{imports}

class LLMOS:
    def __init__(self):
        self.components = [
            {component_instances}
        ]

    def run(self):
        results = []
        for comp in self.components:
            results.append(comp.execute())
        return results

if __name__ == "__main__":
    os = LLMOS()
    print("LLM OS running...")
    results = os.run()
    print("Results:", results)
"""

    async def _llm_improve_code(self, code: str, issue: str) -> str:
        """Improve code based on issue"""
        return f"""
# Improved version of code
# Original issue: {issue}
{code}

# Additional improvements:
def enhanced_functionality():
    # Addresses: {issue}
    return "Improved implementation"
"""