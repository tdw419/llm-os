"""
Test for VectorMemory Component
"""
import pytest
import os
import sys
from pathlib import Path

# Add components directory to path
sys.path.insert(0, str(Path(__file__).parent.parent / "components"))

from comp_63b265be4940 import VectorMemory

class TestVectorMemory:
    """Test class for VectorMemory component"""

    @pytest.fixture
    def vector_memory(self):
        """Fixture to create a VectorMemory instance"""
        return VectorMemory()

    def test_initialization(self, vector_memory):
        """Test that vector memory initializes correctly."""
        assert vector_memory is not None
        assert isinstance(vector_memory, VectorMemory)
        assert vector_memory.initialized is True
        assert hasattr(vector_memory, 'memory')
        assert hasattr(vector_memory, 'vector_index')

    def test_process_valid_data(self, vector_memory):
        """Test processing valid input data."""
        result = vector_memory.process("This is a test message")

        # Check if process returned success status
        assert result['status'] == 'success'
        assert 'memory_id' in result
        assert 'vector' in result
        assert isinstance(result['vector'], list)
        assert len(result['vector']) > 0

        # Verify that the data was actually stored
        mem_id = result['memory_id']
        assert mem_id in vector_memory.memory
        assert mem_id in vector_memory.vector_index

    def test_process_invalid_data(self, vector_memory):
        """Test processing invalid input data."""
        result = vector_memory.process(None)
        assert result['status'] == 'error'
        assert 'error' in result

    def test_validate_valid_input(self, vector_memory):
        """Test validation of valid input data."""
        assert vector_memory.validate("This is a valid message") is True
        assert vector_memory.validate("") is False
        assert vector_memory.validate(None) is False

    def test_search_similar_vectors(self, vector_memory):
        """Test semantic search functionality with similar vectors."""
        # Store some sample vectors for testing
        result1 = vector_memory.process("The quick brown fox jumps over the lazy dog")
        result2 = vector_memory.process("A fast brown fox leaps over a sleepy dog")

        # Perform search query that should match both stored vectors
        query_vector = [hash("fast brown fox")[i % 10] % 1000 for i in range(20)]
        results = vector_memory.search_similar(query_vector, threshold=0.1)

        # Verify that we got results
        assert isinstance(results, list)

    def test_component_interface(self, vector_memory):
        """Test that the component has the required interface"""
        # Should have process and validate methods
        assert hasattr(vector_memory, 'process')
        assert hasattr(vector_memory, 'validate')
        assert callable(vector_memory.process)
        assert callable(vector_memory.validate)

if __name__ == "__main__":
    # Run tests directly
    pytest.main([__file__, "-v"])