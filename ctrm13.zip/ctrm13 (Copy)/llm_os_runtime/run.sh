#!/bin/bash
echo "🚀 Launching Substrate LLM OS"
echo "=============================="
cd "/home/jericho/zion/projects/ctrm/ctrm13/llm_os_runtime"
python3 main.py
