def test_initialization():
    comp = TestComponent()
    assert comp is not None
    assert comp.data == {}


def test_process_valid_data():
    comp = TestComponent()
    result = comp.process("test")
    assert result["processed"] is True
    assert result["input"] == "test"


def test_process_invalid_data():
    comp = TestComponent()
    with pytest.raises(ValueError):
        comp.process(None)


def test_validate():
    comp = TestComponent()
    assert comp.validate("test") is True
    assert comp.validate(None) is False
