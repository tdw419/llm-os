import json
from typing import Dict, Any, Optional

class TestComponent:
    """Test component for verification"""

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {"default": "value"}
        self.data = {}

    def process(self, data: Any) -> Dict[str, Any]:
        """Process input data"""
        if not self.validate(data):
            raise ValueError("Invalid input data")
        return {"processed": True, "input": data}

    def validate(self, data: Any) -> bool:
        """Validate input data"""
        return data is not None and len(str(data)) > 0

# Test the component directly
if __name__ == "__main__":
    print("Testing component execution...")
    comp = TestComponent()
    result = comp.process("Hello LLM OS!")
    print(f"Process result: {result}")
    print("Component execution successful!")
