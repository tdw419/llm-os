
# Integration code for 5 components
import sys
import os

# Import components
from components.comp_0 import Component0
from components.comp_1 import Component1
from components.comp_2 import Component2
from components.comp_3 import Component3
from components.comp_4 import Component4

class LLMOS:
    def __init__(self):
        self.components = [
            Component0(),
            Component1(),
            Component2(),
            Component3(),
            Component4(),
        ]

    def run(self):
        results = []
        for comp in self.components:
            results.append(comp.execute())
        return results

if __name__ == "__main__":
    llm_os = LLMOS()
    print("LLM OS running...")
    results = llm_os.run()
    print("Results:", results)
