class Component3:
    """Substrate Interface"""

    def __init__(self):
        self.name = "Substrate Interface"

    def execute(self):
        return f"{self.name} executed"
