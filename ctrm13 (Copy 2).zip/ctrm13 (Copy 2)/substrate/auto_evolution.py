import asyncio
import numpy as np
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
from substrate.vector_db import VectorSubstrate, VectorType
import json

class AutoEvolutionEngine:
    """
    Autonomous evolution system for the substrate
    Continuously improves components based on vector analysis
    """

    def __init__(self, substrate_db: str = "./llm_os_substrate.db"):
        self.substrate = VectorSubstrate(substrate_db)
        self.evolution_log = []
        self.running = False

    async def start_evolution_loop(self, interval_minutes: int = 5):
        """Start continuous evolution loop"""
        self.running = True
        print(f"🔄 Starting auto-evolution loop (interval: {interval_minutes} minutes)")

        while self.running:
            try:
                await self.run_evolution_cycle()
                print(f"✅ Evolution cycle complete at {datetime.now()}")
            except Exception as e:
                print(f"❌ Evolution cycle failed: {e}")

            # Wait for next cycle
            await asyncio.sleep(interval_minutes * 60)

    async def run_evolution_cycle(self):
        """Run one evolution cycle"""
        print(f"\n🔁 Running evolution cycle...")

        # 1. Analyze substrate state
        stats = await self.substrate.get_statistics()
        print(f"   Analyzing {stats['total_vectors']} vectors...")

        # 2. Find candidates for improvement
        candidates = await self._find_improvement_candidates()

        if not candidates:
            print("   No improvement candidates found.")
            return

        print(f"   Found {len(candidates)} improvement candidates")

        # 3. Evolve each candidate
        for i, candidate in enumerate(candidates, 1):
            print(f"   [{i}/{len(candidates)}] Evolving: {candidate['id'][:12]}...")

            try:
                result = await self._evolve_component(candidate)

                self.evolution_log.append({
                    'timestamp': datetime.now().isoformat(),
                    'original_id': candidate['id'],
                    'evolved_id': result.get('evolved_id'),
                    'improvement': result.get('improvement'),
                    'method': result.get('method')
                })

                print(f"      → Evolved to: {result.get('evolved_id', 'unknown')[:12]}")
                print(f"      Improvement: {result.get('improvement', 0):.3f}")

            except Exception as e:
                print(f"      ❌ Evolution failed: {e}")

        # 4. Clean up old versions
        await self._cleanup_old_versions()

        # 5. Update evolution statistics
        await self._update_evolution_stats()

        print(f"✅ Evolution cycle complete")

    async def _find_improvement_candidates(self) -> List[Dict[str, Any]]:
        """Find components that need improvement"""
        candidates = []

        # Get all components
        cursor = self.substrate.conn.execute(
            "SELECT id, vector_data, metadata_json FROM vectors WHERE vector_type = ?",
            ('component',)
        )

        for row in cursor:
            metadata = json.loads(row['metadata_json']) if row['metadata_json'] else {}

            # Check test success rate
            tests_passed = metadata.get('tests_passed', 0)
            tests_total = metadata.get('tests_total', 0)

            if tests_total > 0:
                success_rate = tests_passed / tests_total

                # Low test success is a candidate
                if success_rate < 0.7:
                    candidates.append({
                        'id': row['id'],
                        'success_rate': success_rate,
                        'reason': 'low_test_success',
                        'metadata': metadata
                    })

            # Check if component has no relations (isolated)
            relations = await self.substrate.get_related_vectors(row['id'])
            if len(relations) < 2:  # Few relations
                candidates.append({
                    'id': row['id'],
                    'relation_count': len(relations),
                    'reason': 'isolated_component',
                    'metadata': metadata
                })

            # Check confidence
            entry = await self.substrate.get_vector(row['id'])
            if entry and entry.confidence < 0.6:
                candidates.append({
                    'id': row['id'],
                    'confidence': entry.confidence,
                    'reason': 'low_confidence',
                    'metadata': metadata
                })

        # Remove duplicates
        unique_candidates = []
        seen_ids = set()
        for candidate in candidates:
            if candidate['id'] not in seen_ids:
                unique_candidates.append(candidate)
                seen_ids.add(candidate['id'])

        # Sort by priority (lowest success rate first)
        unique_candidates.sort(key=lambda x: x.get('success_rate', 1.0))

        return unique_candidates[:10]  # Limit to top 10

    async def _evolve_component(self, candidate: Dict[str, Any]) -> Dict[str, Any]:
        """Evolve a component based on its issues"""
        component_id = candidate['id']
        reason = candidate.get('reason', 'general_improvement')

        # Get component details
        component = await self.substrate.get_vector(component_id)
        if not component:
            return {'error': 'Component not found'}

        # Get related code
        code_relations = await self.substrate.get_related_vectors(
            component_id, relation_type='has_implementation'
        )

        if not code_relations:
            return {'error': 'No code implementation found'}

        code_entry = code_relations[0]['vector']
        code = code_entry.metadata.get('code', '')

        # Generate improvement based on reason
        if reason == 'low_test_success':
            issue = "Improve test coverage and success rate"
        elif reason == 'isolated_component':
            issue = "Add more integration points with other components"
        elif reason == 'low_confidence':
            issue = "Improve reliability and error handling"
        else:
            issue = "General performance and reliability improvements"

        # Use LLM to improve code (simplified - in reality call LLM)
        # For now, we'll create a new vector with slight variation
        original_vector = np.array(component.vector)

        # Create evolved vector (add small random variation)
        variation = np.random.normal(0, 0.1, len(original_vector))
        evolved_vector = (original_vector + variation).tolist()

        # Normalize
        evolved_norm = np.linalg.norm(evolved_vector)
        if evolved_norm > 0:
            evolved_vector = (evolved_vector / evolved_norm).tolist()

        # Store evolved component
        evolved_id = await self.substrate.store_vector(
            evolved_vector,
            VectorType.COMPONENT_VECTOR,
            metadata={
                'type': 'auto_evolved_component',
                'original_component_id': component_id,
                'evolution_reason': reason,
                'evolution_timestamp': datetime.now().isoformat(),
                'original_metadata': component.metadata,
                'improvement_description': issue
            }
        )

        # Create relation from old to new
        await self.substrate.create_relation(
            component_id, evolved_id,
            relation_type='evolved_to',
            strength=0.8,
            metadata={
                'reason': reason,
                'method': 'auto_evolution',
                'timestamp': datetime.now().isoformat()
            }
        )

        # Copy other relations
        all_relations = await self.substrate.get_related_vectors(component_id)
        for rel in all_relations:
            if rel['relation_type'] != 'has_implementation':
                await self.substrate.create_relation(
                    evolved_id, rel['vector'].id,
                    relation_type=rel['relation_type'],
                    strength=rel['strength'] * 0.9
                )

        # Calculate improvement (simplified)
        improvement = np.random.uniform(0.05, 0.2)  # Random improvement for now

        return {
            'evolved_id': evolved_id,
            'improvement': improvement,
            'method': 'vector_variation',
            'reason': reason
        }

    async def _cleanup_old_versions(self, keep_versions: int = 3):
        """Clean up old versions of components"""
        # Find components with evolution chains
        cursor = self.substrate.conn.execute("""
            SELECT v1.id as original, v2.id as evolved
            FROM vector_relations r
            JOIN vectors v1 ON r.source_id = v1.id
            JOIN vectors v2 ON r.target_id = v2.id
            WHERE r.relation_type = 'evolved_to'
        """)

        evolution_chains = {}
        for row in cursor:
            if row['original'] not in evolution_chains:
                evolution_chains[row['original']] = []
            evolution_chains[row['original']].append(row['evolved'])

        # For each chain, keep only latest N versions
        for original, evolved_list in evolution_chains.items():
            if len(evolved_list) > keep_versions:
                # Sort by timestamp (newest first)
                to_delete = evolved_list[keep_versions:]
                for evolved_id in to_delete:
                    await self.substrate.delete_vector(evolved_id)
                    print(f"      Deleted old version: {evolved_id[:12]}")

    async def _update_evolution_stats(self):
        """Update evolution statistics in substrate"""
        stats = {
            'total_evolutions': len(self.evolution_log),
            'last_evolution': datetime.now().isoformat(),
            'evolution_cycle_count': len([e for e in self.evolution_log
                                        if e.get('timestamp', '').startswith(
                                            datetime.now().strftime('%Y-%m-%d'))])
        }

        # Store stats as knowledge vector
        await self.substrate.store_vector(
            [1.0] * 100,  # Placeholder vector
            VectorType.KNOWLEDGE_VECTOR,
            metadata={
                'type': 'evolution_statistics',
                'statistics': stats,
                'log_summary': self.evolution_log[-10:] if self.evolution_log else []
            }
        )

    def stop(self):
        """Stop the evolution loop"""
        self.running = False
        print("🛑 Auto-evolution stopped")

async def run_auto_evolution():
    """Run the auto-evolution engine"""
    engine = AutoEvolutionEngine()

    try:
        # Run for 1 hour (12 cycles at 5-minute intervals)
        await asyncio.wait_for(
            engine.start_evolution_loop(interval_minutes=5),
            timeout=3600
        )
    except asyncio.TimeoutError:
        print("⏰ Auto-evolution completed 1-hour run")
    finally:
        engine.stop()

    # Print summary
    print(f"\n📊 Evolution Summary:")
    print(f"   Total evolutions: {len(engine.evolution_log)}")

    if engine.evolution_log:
        print(f"   Last evolution: {engine.evolution_log[-1]['timestamp']}")
        print(f"   Last method: {engine.evolution_log[-1]['method']}")

if __name__ == "__main__":
    asyncio.run(run_auto_evolution())