import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from fastapi import FastAPI, HTTPException, Query, Body
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
from typing import List, Dict, Any, Optional
import json

from vector_db import VectorSubstrate, VectorType, VectorEntry

app = FastAPI(title="Vector Substrate API", version="1.0.0")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global substrate instance
substrate = None

@app.on_event("startup")
async def startup_event():
    """Initialize substrate on startup"""
    global substrate
    substrate = VectorSubstrate("./substrate.db")
    print("🚀 Vector Substrate API started")

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown"""
    if substrate:
        substrate.close()
    print("🛑 Vector Substrate API stopped")

@app.get("/")
async def root():
    """API root"""
    return {
        "name": "Vector Substrate API",
        "version": "1.0.0",
        "description": "Unified vector computational medium",
        "endpoints": {
            "/vectors": "Store and retrieve vectors",
            "/similar": "Find similar vectors",
            "/relations": "Manage vector relations",
            "/search": "Full-text search",
            "/clusters": "Cluster vectors",
            "/stats": "Get statistics"
        }
    }

@app.post("/vectors")
async def store_vector(
    vector: List[float] = Body(...),
    vector_type: str = Body("code"),
    metadata: Dict[str, Any] = Body(None)
):
    """Store a vector in the substrate"""
    try:
        vec_type = VectorType(vector_type)
        vector_id = await substrate.store_vector(
            vector, vec_type, metadata
        )

        return {
            "status": "success",
            "vector_id": vector_id,
            "message": f"Vector stored as {vector_id}"
        }

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/vectors/{vector_id}")
async def get_vector(vector_id: str):
    """Retrieve a vector by ID"""
    entry = await substrate.get_vector(vector_id)

    if not entry:
        raise HTTPException(status_code=404, detail=f"Vector {vector_id} not found")

    return {
        "id": entry.id,
        "vector_type": entry.vector_type.value,
        "vector": entry.vector,
        "metadata": entry.metadata,
        "confidence": entry.confidence,
        "created_at": entry.created_at,
        "updated_at": entry.updated_at
    }

@app.post("/vectors/batch")
async def store_vectors_batch(
    vectors: List[Dict[str, Any]] = Body(...)
):
    """Store multiple vectors"""
    results = []

    for vec_data in vectors:
        try:
            vec_type = VectorType(vec_data.get("vector_type", "code"))
            vector_id = await substrate.store_vector(
                vec_data["vector"],
                vec_type,
                vec_data.get("metadata")
            )

            results.append({
                "status": "success",
                "vector_id": vector_id,
                "original_index": vectors.index(vec_data)
            })

        except Exception as e:
            results.append({
                "status": "error",
                "error": str(e),
                "original_index": vectors.index(vec_data)
            })

    return {"results": results}

@app.post("/similar")
async def find_similar(
    query_vector: List[float] = Body(...),
    vector_type: Optional[str] = Body(None),
    top_k: int = Body(10),
    threshold: float = Body(0.7)
):
    """Find similar vectors"""
    vec_type = VectorType(vector_type) if vector_type else None

    results = await substrate.find_similar_vectors(
        query_vector, vec_type, top_k, threshold
    )

    # Enrich with metadata
    enriched = []
    for result in results:
        entry = await substrate.get_vector(result["id"])
        if entry:
            enriched.append({
                **result,
                "metadata": entry.metadata,
                "vector_type": entry.vector_type.value,
                "confidence": entry.confidence
            })

    return {"results": enriched}

@app.post("/relations")
async def create_relation(
    source_id: str = Body(...),
    target_id: str = Body(...),
    relation_type: str = Body("related"),
    strength: float = Body(1.0),
    metadata: Dict[str, Any] = Body(None)
):
    """Create relation between vectors"""
    await substrate.create_relation(
        source_id, target_id, relation_type, strength, metadata
    )

    return {
        "status": "success",
        "message": f"Relation created: {source_id} -> {target_id}"
    }

@app.get("/relations/{vector_id}")
async def get_relations(
    vector_id: str,
    relation_type: Optional[str] = None,
    max_depth: int = 1
):
    """Get vectors related to a vector"""
    results = await substrate.get_related_vectors(
        vector_id, relation_type, max_depth
    )

    return {
        "vector_id": vector_id,
        "relations": [
            {
                "related_vector_id": rel["vector"].id,
                "relation_type": rel["relation_type"],
                "strength": rel["strength"],
                "metadata": rel["metadata"]
            }
            for rel in results
        ]
    }

@app.get("/search")
async def search_vectors(
    query: str,
    vector_type: Optional[str] = None,
    limit: int = 20
):
    """Search vectors by metadata"""
    vec_type = VectorType(vector_type) if vector_type else None

    results = await substrate.search_vectors(query, vec_type, limit)

    return {
        "query": query,
        "results": [
            {
                "vector_id": result["vector"].id,
                "vector_type": result["vector"].vector_type.value,
                "metadata": result["metadata"],
                "rank": result["rank"]
            }
            for result in results
        ]
    }

@app.get("/clusters")
async def compute_clusters(
    vector_type: Optional[str] = None,
    n_clusters: int = 10
):
    """Cluster vectors"""
    vec_type = VectorType(vector_type) if vector_type else None

    clusters = await substrate.compute_clusters(vec_type, n_clusters)

    return clusters

@app.get("/stats")
async def get_statistics():
    """Get substrate statistics"""
    stats = await substrate.get_statistics()
    return stats

@app.post("/import")
async def import_vectors(file_path: str = Body(...)):
    """Import vectors from file"""
    await substrate.import_vectors(file_path)

    return {
        "status": "success",
        "message": f"Vectors imported from {file_path}"
    }

@app.post("/export")
async def export_vectors(
    vector_ids: List[str] = Body(...),
    output_path: str = Body(...)
):
    """Export vectors to file"""
    await substrate.export_subset(vector_ids, output_path)

    return {
        "status": "success",
        "message": f"Exported {len(vector_ids)} vectors to {output_path}"
    }

# Run server
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8001)
    args = parser.parse_args()
    uvicorn.run(app, host="0.0.0.0", port=args.port)