#!/usr/bin/env python3
"""
Vector Agency Protocol
Enables autonomous action and decision-making for executable vectors
"""

import asyncio
import json
import sys
import os
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime
import hashlib
import numpy as np

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from substrate.vector_db import VectorSubstrate, VectorType, VectorEntry
from substrate.vector_executor import SubstratePythonExecutor
from src.lm_studio.integration import LMStudioIntegration

class VectorAgencyProtocol:
    """
    Vector Agency Protocol enables executable vectors to:
    1. Decide to call other vectors
    2. Request access to external resources
    3. Chain execution steps autonomously
    4. Maintain execution context and state
    """

    def __init__(self, substrate_db: str = "./llm_os_substrate.db"):
        self.substrate = VectorSubstrate(substrate_db)
        self.executor = SubstratePythonExecutor(self.substrate)
        self.lm_studio = LMStudioIntegration()
        self.agency_history = []
        self.active_agents = {}

        # Agency configuration
        self.agency_config = {
            'max_execution_depth': 5,
            'max_concurrent_agents': 10,
            'resource_access_policy': 'ask',
            'execution_timeout': 30.0,
            'context_retention': True
        }

    async def create_agency_vector(self, code: str, name: str,
                                 description: str = "", capabilities: list = None) -> str:
        """
        Create an executable vector with agency capabilities
        """
        # First create as regular executable
        vector_id = await self.executor.create_executable_vector(code, name, description)

        # Add agency metadata
        agency_metadata = {
            'agency_enabled': True,
            'capabilities': capabilities or ['execute', 'decide', 'chain'],
            'execution_history': [],
            'resource_access': [],
            'created_at': datetime.now().isoformat(),
            'last_execution': None
        }

        # Update vector with agency metadata
        await self.substrate.update_vector(vector_id, metadata=agency_metadata)

        return vector_id

    async def execute_with_agency(self, vector_id: str, context: Dict = None) -> Dict:
        """
        Execute a vector with full agency capabilities
        """
        # Get the vector
        vector = await self.substrate.get_vector(vector_id)
        if not vector or not vector.metadata.get('agency_enabled'):
            return {"error": f"Vector {vector_id} not found or agency not enabled"}

        # Create agency context
        agency_context = {
            'vector_id': vector_id,
            'execution_depth': 0,
            'context': context or {},
            'execution_history': [],
            'resource_requests': [],
            'start_time': datetime.now().isoformat()
        }

        # Execute with agency
        result = await self._execute_agency_cycle(vector, agency_context)

        # Store execution history
        self.agency_history.append({
            'vector_id': vector_id,
            'result': result,
            'timestamp': datetime.now().isoformat(),
            'context': agency_context
        })

        return result

    async def _execute_agency_cycle(self, vector: VectorEntry, context: Dict) -> Dict:
        """
        Execute a single agency cycle with decision-making
        """
        vector_id = vector.id
        code = vector.metadata.get('content', '')
        name = vector.metadata.get('name', 'unnamed')

        print(f"🤖 Agency executing: {name} (depth: {context['execution_depth']})")

        # Check execution depth limit
        if context['execution_depth'] >= self.agency_config['max_execution_depth']:
            return {
                'success': False,
                'error': 'Maximum execution depth reached',
                'vector_id': vector_id,
                'execution_depth': context['execution_depth']
            }

        # Execute the code
        execution_result = await self.executor.execute_code(code, name, context['context'])

        # Analyze execution result for agency decisions
        if execution_result.get('success'):
            # Check if the code requested additional actions
            decisions = await self._analyze_agency_decisions(execution_result, context)

            # Execute decisions recursively
            decision_results = []
            for decision in decisions:
                decision_result = await self._execute_agency_decision(decision, context)
                decision_results.append(decision_result)

            # Combine results
            combined_result = {
                'success': True,
                'original_execution': execution_result,
                'agency_decisions': decisions,
                'decision_results': decision_results,
                'vector_id': vector_id,
                'execution_depth': context['execution_depth'],
                'total_actions': len(decision_results) + 1
            }

            return combined_result

        return {
            'success': False,
            'error': execution_result.get('error', 'Execution failed'),
            'vector_id': vector_id,
            'execution_depth': context['execution_depth']
        }

    async def _analyze_agency_decisions(self, execution_result: Dict, context: Dict) -> List[Dict]:
        """
        Analyze execution results to determine agency decisions
        """
        decisions = []

        # Check for explicit decision requests in output
        stdout = execution_result.get('stdout', '')
        result = execution_result.get('result', {})

        # Look for decision patterns
        if 'AGENCY_DECISION:' in stdout:
            # Parse decision from output
            lines = stdout.split('\n')
            for line in lines:
                if line.startswith('AGENCY_DECISION:'):
                    try:
                        decision_data = json.loads(line.replace('AGENCY_DECISION:', '').strip())
                        decisions.append(decision_data)
                    except json.JSONDecodeError:
                        print(f"⚠️ Invalid agency decision format: {line}")

        # Check for function call patterns
        if isinstance(result, dict) and 'function_calls' in result:
            for call in result['function_calls']:
                decisions.append({
                    'type': 'function_call',
                    'function': call.get('function'),
                    'arguments': call.get('arguments', {}),
                    'reason': call.get('reason', 'Function call requested')
                })

        # Use LM Studio to analyze for implicit decisions
        analysis = await self._analyze_with_lm_studio(execution_result)
        if analysis and 'suggested_actions' in analysis:
            decisions.extend(analysis['suggested_actions'])

        return decisions

    async def _execute_agency_decision(self, decision: Dict, context: Dict) -> Dict:
        """
        Execute a single agency decision
        """
        decision_type = decision.get('type', 'unknown')
        print(f"  🔄 Executing decision: {decision_type}")

        # Increment execution depth
        new_context = {**context, 'execution_depth': context['execution_depth'] + 1}

        if decision_type == 'execute_vector':
            target_vector_id = decision.get('vector_id')
            if target_vector_id:
                return await self.execute_with_agency(target_vector_id, new_context)
            else:
                return {'success': False, 'error': 'No vector_id specified'}

        elif decision_type == 'function_call':
            function_name = decision.get('function')
            arguments = decision.get('arguments', {})

            # Find vectors that can handle this function
            search_results = await self.substrate.search_vectors(
                function_name,
                vector_type='code',
                limit=1
            )

            if search_results:
                target_vector = search_results[0]
                # Add function call context
                call_context = {
                    **new_context['context'],
                    'function_call': {
                        'name': function_name,
                        'arguments': arguments
                    }
                }
                return await self.execute_with_agency(target_vector['id'], call_context)

            return {'success': False, 'error': f'No vector found for function: {function_name}'}

        elif decision_type == 'resource_request':
            resource_type = decision.get('resource_type')
            resource_path = decision.get('resource_path')

            # Handle resource access
            if self.agency_config['resource_access_policy'] == 'ask':
                # For now, simulate resource access
                return {
                    'success': True,
                    'resource_type': resource_type,
                    'resource_path': resource_path,
                    'access_granted': True,
                    'message': f'Resource access simulated for {resource_type}: {resource_path}'
                }
            else:
                return {'success': False, 'error': 'Resource access not allowed'}

        elif decision_type == 'chain_execution':
            chain_steps = decision.get('steps', [])
            chain_results = []

            for step in chain_steps:
                step_result = await self._execute_agency_decision(step, new_context)
                chain_results.append(step_result)

                # Check if we should continue the chain
                if not step_result.get('success') and step.get('required', True):
                    return {
                        'success': False,
                        'error': f'Chain step failed: {step.get("description", "unknown")}',
                        'completed_steps': len(chain_results),
                        'total_steps': len(chain_steps)
                    }

            return {
                'success': True,
                'chain_results': chain_results,
                'completed_steps': len(chain_results),
                'total_steps': len(chain_steps)
            }

        else:
            return {'success': False, 'error': f'Unknown decision type: {decision_type}'}

    async def _analyze_with_lm_studio(self, execution_result: Dict) -> Optional[Dict]:
        """
        Use LM Studio to analyze execution results for agency decisions
        """
        try:
            # Prepare analysis prompt
            prompt = f"""
            Analyze this execution result and suggest autonomous actions:

            EXECUTION RESULT:
            {json.dumps(execution_result, indent=2, default=str)}

            SUGGEST ACTIONS:
            - Should this vector call other vectors?
            - Should it request external resources?
            - Should it chain multiple operations?
            - What parameters should be used?

            Return as JSON with suggested_actions array.
            """

            response = await self.lm_studio.analyze_code_quality(
                json.dumps(execution_result),
                "execution_analysis"
            )

            if response and isinstance(response, dict):
                return response

        except Exception as e:
            print(f"⚠️ LM Studio analysis failed: {e}")
            # Fallback: return empty analysis
            return {'suggested_actions': []}

        return None

    async def create_agency_pipeline(self, pipeline_name: str, vector_ids: List[str]) -> Dict:
        """
        Create an agency pipeline that can make autonomous decisions
        """
        # Create pipeline vector
        pipeline_vector = {
            'type': 'agency_pipeline',
            'content': {
                'name': pipeline_name,
                'vector_ids': vector_ids,
                'execution_strategy': 'sequential_with_agency',
                'created_at': datetime.now().isoformat()
            },
            'metadata': {
                'agency_enabled': True,
                'pipeline_type': 'agency',
                'capabilities': ['execute', 'decide', 'chain', 'pipeline'],
                'execution_history': []
            }
        }

        # Generate vector embedding
        vector_embedding = self._generate_pipeline_vector(pipeline_vector)

        # Store pipeline
        pipeline_id = await self.substrate.store_vector(
            vector_embedding,
            VectorType.COMPONENT_VECTOR,
            metadata=pipeline_vector['metadata']
        )

        # Create relations between pipeline and vectors
        for vector_id in vector_ids:
            await self.substrate.create_relation(
                pipeline_id, vector_id,
                'pipeline_step', 0.8
            )

        return {
            'pipeline_id': pipeline_id,
            'vector_ids': vector_ids,
            'pipeline_name': pipeline_name
        }

    def _generate_pipeline_vector(self, pipeline_data: Dict) -> List[float]:
        """Generate vector embedding for pipeline"""
        pipeline_str = json.dumps(pipeline_data, sort_keys=True)
        pipeline_hash = hashlib.sha256(pipeline_str.encode()).hexdigest()

        # Convert hash to vector
        vector = [0.0] * 1536
        for i in range(0, len(pipeline_hash), 6):
            hex_val = pipeline_hash[i:i+6]
            try:
                val = int(hex_val, 16) / 0xFFFFFF  # Normalize to 0-1
                dim = i // 6 % 1536
                vector[dim] = val
            except:
                pass

        return vector

    async def get_agency_status(self) -> Dict:
        """Get current agency system status"""
        stats = await self.substrate.get_statistics()

        # Count agency-enabled vectors
        cursor = self.substrate.conn.execute(
            "SELECT COUNT(*) as count FROM vectors WHERE json_extract(metadata_json, '$.agency_enabled') = 1"
        )
        agency_count = cursor.fetchone()['count']

        return {
            'total_vectors': stats['total_vectors'],
            'agency_vectors': agency_count,
            'active_agents': len(self.active_agents),
            'execution_history': len(self.agency_history),
            'agency_config': self.agency_config,
            'last_execution': self.agency_history[-1]['timestamp'] if self.agency_history else None
        }

    async def test_agency_capabilities(self):
        """Test the agency capabilities"""
        print("🧪 Testing Vector Agency Protocol...")

        # Create a simple agency vector
        simple_code = """
def make_decision(data):
    # Simple decision-making function
    value = data.get('value', 0)

    if value > 50:
        print('AGENCY_DECISION: {"type": "execute_vector", "vector_id": "high_value_handler", "reason": "High value detected"}')
        return {"decision": "high_value", "action": "process_high_value"}
    else:
        print('AGENCY_DECISION: {"type": "execute_vector", "vector_id": "low_value_handler", "reason": "Low value detected"}')
        return {"decision": "low_value", "action": "process_low_value"}

# Test with context data
result = make_decision(context.get('data', {'value': 30}))
"""

        # Create agency vector
        vector_id = await self.create_agency_vector(
            simple_code,
            "decision_maker",
            "Simple decision-making agent",
            capabilities=['execute', 'decide', 'chain']
        )

        print(f"✅ Created agency vector: {vector_id}")

        # Test execution with different contexts
        test_cases = [
            {'data': {'value': 60}},
            {'data': {'value': 25}}
        ]

        for i, context in enumerate(test_cases, 1):
            print(f"\n📋 Test case {i}: {context}")
            result = await self.execute_with_agency(vector_id, context)

            if result.get('success'):
                print(f"   ✅ Agency execution successful!")
                if 'agency_decisions' in result:
                    print(f"   🤖 Made {len(result['agency_decisions'])} decisions")
                    for decision in result['agency_decisions']:
                        print(f"     • {decision.get('type')}: {decision.get('reason', 'no reason')}")
            else:
                print(f"   ❌ Agency execution failed: {result.get('error', 'unknown')}")

        # Test agency status
        status = await self.get_agency_status()
        print(f"\n📊 Agency Status:")
        print(f"   Agency vectors: {status['agency_vectors']}")
        print(f"   Active agents: {status['active_agents']}")
        print(f"   Execution history: {status['execution_history']}")

        print("\n✅ Vector Agency Protocol test complete!")
        return True

async def main():
    """Main test function"""
    print("🚀 Vector Agency Protocol - Autonomous Action System")
    print("=" * 60)

    protocol = VectorAgencyProtocol()

    # Test agency capabilities
    await protocol.test_agency_capabilities()

    print("\n" + "=" * 60)
    print("🎉 Vector Agency Protocol is ready!")
    print("   Vectors can now make autonomous decisions and execute chains!")

if __name__ == "__main__":
    asyncio.run(main())