import time
import threading
from typing import Dict, List, Any
from .substrate_python_kernel import SubstratePythonKernel

class SubstrateExecutionAgent:
    """Agent that monitors and executes code from substrate."""

    def __init__(self, substrate, execution_interval: int = 30):
        self.substrate = substrate
        self.kernel = SubstratePythonKernel(substrate)
        self.execution_interval = execution_interval
        self.running = False
        self.execution_thread = None

        # Execution policies
        self.policies = {
            'auto_execute_new': True,
            'retry_failed': True,
            'max_retries': 3,
            'execute_on_similarity': 0.8
        }

    def start(self):
        """Start the execution agent."""
        if self.running:
            return

        self.running = True
        self.execution_thread = threading.Thread(target=self._execution_loop)
        self.execution_thread.daemon = True
        self.execution_thread.start()
        print(f"🚀 Execution agent started (interval: {self.execution_interval}s)")

    def stop(self):
        """Stop the execution agent."""
        self.running = False
        if self.execution_thread:
            self.execution_thread.join(timeout=5)
        print("🛑 Execution agent stopped")

    def _execution_loop(self):
        """Main execution loop."""
        while self.running:
            try:
                self._execute_scheduled()
                self._process_execution_queue()
            except Exception as e:
                print(f"⚠️ Execution loop error: {e}")

            time.sleep(self.execution_interval)

    def _execute_scheduled(self):
        """Execute scheduled/triggered code."""
        # Find vectors with execution triggers
        vectors = self.substrate.search_vectors(
            query="",
            vector_type='executable',
            filters={'metadata.execution_schedule': {'$exists': True}}
        )

        for vector in vectors:
            schedule = vector['metadata'].get('execution_schedule', {})
            if self._should_execute_now(schedule):
                print(f"⏰ Executing scheduled: {vector['metadata'].get('name')}")
                result = self.kernel.execute_vector(vector['id'])

                # Update vector with execution result
                self.substrate.update_vector(vector['id'], {
                    'last_execution': {
                        'time': time.time(),
                        'result': result
                    }
                })

    def _process_execution_queue(self):
        """Process execution queue from substrate."""
        queue_vectors = self.substrate.search_vectors(
            query="",
            vector_type='execution_queue',
            k=10
        )

        for vector in queue_vectors:
            # Execute the queued command
            command = vector.get('content', {})
            if command.get('type') == 'execute_vector':
                target_id = command.get('vector_id')
                print(f"🎯 Executing queued: {target_id}")
                result = self.kernel.execute_vector(target_id)

                # Create result vector
                self.substrate.store_vector({
                    'type': 'execution_result',
                    'content': result,
                    'metadata': {
                        'source_vector': target_id,
                        'execution_time': time.time()
                    }
                }, description=f"Execution result for {target_id}")

                # Remove from queue
                self.substrate.delete_vector(vector['id'])

    def execute_natural_language(self, command: str) -> Dict:
        """Execute natural language command."""
        print(f"🗣️  Executing: {command}")
        return self.kernel.find_and_execute(command)

    def create_execution_pipeline(self, vector_names: List[str]) -> Dict:
        """Create and execute a pipeline of vectors."""
        vector_ids = []
        for name in vector_names:
            vectors = self.substrate.search_vectors(
                name,
                vector_type='executable',
                k=1
            )
            if vectors:
                vector_ids.append(vectors[0]['id'])

        if vector_ids:
            return self.kernel.execute_pipeline(vector_ids)

        return {"error": "Could not find vectors for pipeline"}

    def _should_execute_now(self, schedule: Dict) -> bool:
        """Check if scheduled execution should run now."""
        if not schedule:
            return False

        now = time.time()
        last_executed = schedule.get('last_executed', 0)
        interval = schedule.get('interval_seconds', 3600)  # Default 1 hour

        # Check if enough time has passed
        if now - last_executed >= interval:
            return True

        # Check specific times
        if 'specific_times' in schedule:
            current_hour = time.localtime(now).tm_hour
            if current_hour in schedule['specific_times']:
                return True

        return False