from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Dict, Any, List, Optional
import asyncio

app = FastAPI(title="Substrate Execution API")

class ExecuteRequest(BaseModel):
    vector_id: Optional[str] = None
    code: Optional[str] = None
    context: Dict[str, Any] = {}

class NaturalLanguageRequest(BaseModel):
    command: str
    execute: bool = True

class PipelineRequest(BaseModel):
    vector_names: List[str]
    context: Dict[str, Any] = {}

# These would be initialized with substrate instance
substrate = None
execution_agent = None

@app.on_event("startup")
async def startup_event():
    global substrate, execution_agent
    # Initialize substrate and execution agent
    from .vector_db import VectorSubstrate
    from .execution_agent import SubstrateExecutionAgent

    substrate = VectorSubstrate()
    execution_agent = SubstrateExecutionAgent(substrate)
    execution_agent.start()

@app.post("/execute")
async def execute(request: ExecuteRequest):
    """Execute code from vector or direct code."""
    if request.vector_id:
        result = substrate.execute_vector(request.vector_id, request.context)
    elif request.code:
        from .vector_executor import SubstratePythonExecutor
        executor = SubstratePythonExecutor(substrate)
        result = executor.execute_code(request.code, "direct_execution", request.context)
    else:
        raise HTTPException(status_code=400, detail="Either vector_id or code must be provided")

    return result

@app.post("/execute/natural")
async def execute_natural(request: NaturalLanguageRequest):
    """Execute natural language command."""
    if not execution_agent:
        raise HTTPException(status_code=503, detail="Execution agent not ready")

    result = execution_agent.execute_natural_language(request.command)
    return result

@app.post("/execute/pipeline")
async def execute_pipeline(request: PipelineRequest):
    """Execute a pipeline of vectors."""
    if not execution_agent:
        raise HTTPException(status_code=503, detail="Execution agent not ready")

    result = execution_agent.create_execution_pipeline(request.vector_names)
    return result

@app.get("/executables")
async def list_executables():
    """List all executable vectors."""
    executables = substrate.get_executables()
    return {
        "count": len(executables),
        "executables": [
            {
                "id": e["id"],
                "name": e["metadata"].get("name", "unnamed"),
                "description": e["metadata"].get("description", ""),
                "tags": e["metadata"].get("tags", [])
            }
            for e in executables
        ]
    }

@app.post("/executables/create")
async def create_executable(code: str, name: str, description: str = ""):
    """Create new executable vector."""
    from .vector_executor import SubstratePythonExecutor
    executor = SubstratePythonExecutor(substrate)

    vector_id = executor.create_executable_vector(code, name, description)
    return {
        "vector_id": vector_id,
        "name": name,
        "message": "Executable created"
    }

@app.get("/execution/history")
async def get_execution_history(limit: int = 20):
    """Get execution history."""
    from .vector_executor import SubstratePythonExecutor
    executor = SubstratePythonExecutor(substrate)
    return {
        "history": executor.execution_history[-limit:] if executor.execution_history else []
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8002)