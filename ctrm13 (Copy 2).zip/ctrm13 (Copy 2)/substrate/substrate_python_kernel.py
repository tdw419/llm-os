import asyncio
import json
from typing import Dict, Any, List
from .vector_executor import SubstratePythonExecutor

class SubstratePythonKernel:
    """Advanced kernel for executing Python in substrate."""

    def __init__(self, substrate):
        self.substrate = substrate
        self.executor = SubstratePythonExecutor(substrate)
        self.runtime_context = {}
        self.active_processes = {}

    async def execute_interactive(self, code: str) -> Dict:
        """Execute code interactively with persistent context."""
        # Update context with previous results
        exec_globals = {
            **self.runtime_context,
            'kernel': self,
            'substrate': self.substrate,
            'print': lambda *args: self._capture_print(args)
        }

        # Execute in separate thread to avoid blocking
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(
            None,
            lambda: self.executor.execute_code_with_context(code, "interactive", exec_globals)
        )

        # Update context with new variables (except special ones)
        for key, value in exec_globals.items():
            if not key.startswith('__') and key not in ['kernel', 'substrate', 'print']:
                self.runtime_context[key] = value

        return result

    def execute_pipeline(self, vector_ids: List[str]) -> Dict:
        """Execute a pipeline of vectors sequentially."""
        results = []
        context = {}

        for vector_id in vector_ids:
            vector = self.substrate.get_vector(vector_id)
            if vector and vector.get('type') == 'executable':
                # Pass previous results as context
                result = self.executor.execute_vector(vector_id, {
                    'previous_results': results,
                    'pipeline_context': context
                })

                results.append({
                    'vector': vector_id,
                    'name': vector['metadata'].get('name', 'unnamed'),
                    'result': result
                })

                # Update context for next execution
                if result.get('success') and result.get('result'):
                    context[f'result_{len(results)}'] = result['result']

        return {
            'pipeline_results': results,
            'final_context': context,
            'success': all(r['result'].get('success', False) for r in results)
        }

    def find_and_execute(self, natural_language: str) -> Dict:
        """Find executable vectors based on natural language description."""
        # Search for relevant vectors
        search_results = self.substrate.search_vectors(
            natural_language,
            k=5,
            vector_type='executable'
        )

        if not search_results:
            # Try to generate code from description
            generated_code = self._generate_code_from_description(natural_language)
            if generated_code:
                vector_id = self.executor.create_executable_vector(
                    generated_code,
                    f"generated_{hashlib.md5(natural_language.encode()).hexdigest()[:8]}",
                    f"Generated from: {natural_language}"
                )
                return self.executor.execute_vector(vector_id)

        # Execute the most relevant
        most_relevant = search_results[0] if search_results else None
        if most_relevant:
            return self.executor.execute_vector(most_relevant['id'])

        return {"error": "No executable code found for description"}

    def _generate_code_from_description(self, description: str) -> str:
        """Generate Python code from natural language description."""
        # This could integrate with LM Studio or other LLM
        # For now, simple template-based generation
        description_lower = description.lower()

        if "calculate" in description_lower or "math" in description_lower:
            return """
# Math calculation
def calculate():
    result = 0
    # Add your calculation logic here
    print("Calculation placeholder")
    return result

result = calculate()
"""
        elif "process" in description_lower or "data" in description_lower:
            return """
# Data processing
def process_data(data=None):
    if data is None:
        data = [1, 2, 3, 4, 5]

    result = {
        'sum': sum(data),
        'avg': sum(data) / len(data),
        'min': min(data),
        'max': max(data)
    }
    print(f"Processed data: {result}")
    return result

result = process_data()
"""
        return ""

    def _capture_print(self, args):
        """Capture print output for interactive execution."""
        output = " ".join(str(arg) for arg in args)
        print(output)  # Still print to console
        return output