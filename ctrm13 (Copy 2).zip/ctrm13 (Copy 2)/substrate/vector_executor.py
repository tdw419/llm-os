import ast
import sys
import traceback
import time
import hashlib
from io import StringIO
from typing import Dict, Any, Optional, Tuple, List
import json
import numpy as np
from .vector_db import VectorType, VectorEntry

class SubstratePythonExecutor:
    """Execute Python code stored in substrate vectors."""

    def __init__(self, substrate):
        self.substrate = substrate
        self.execution_history = []

    async def execute_vector(self, vector_id: str, context: Dict = None) -> Dict:
        """Execute Python code from a vector."""
        vector = await self.substrate.get_vector(vector_id)
        if not vector or vector.metadata.get('executable') != True:
            return {"error": f"Vector {vector_id} not found or not executable"}

        code = vector.metadata.get('content', '')
        metadata = vector.metadata

        return await self.execute_code(code, metadata.get('name', vector_id), context)

    async def execute_code(self, code: str, name: str, context: Dict = None) -> Dict:
        """Execute Python code with proper isolation and capture."""
        context = context or {}

        # Create execution namespace
        exec_globals = {
            '__name__': f'__substrate_exec__{name}',
            '__builtins__': __builtins__,
            'context': context,
            'substrate': self.substrate,
        }

        # Add custom imports
        exec_globals.update({
            'math': __import__('math'),
            'json': __import__('json'),
            'os': __import__('os'),
            'sys': sys,
            'time': __import__('time'),
            'numpy': np,
        })

        # Capture output
        stdout_capture = StringIO()
        stderr_capture = StringIO()

        old_stdout = sys.stdout
        old_stderr = sys.stderr

        try:
            sys.stdout = stdout_capture
            sys.stderr = stderr_capture

            # Execute the code
            exec(compile(code, f'<substrate:{name}>', 'exec'), exec_globals)

            # Get any return value
            result = exec_globals.get('result', None)

            execution_result = {
                'success': True,
                'result': result,
                'stdout': stdout_capture.getvalue(),
                'stderr': stderr_capture.getvalue(),
                'execution_id': hashlib.md5(f"{name}{code}".encode()).hexdigest()[:16]
            }

        except Exception as e:
            execution_result = {
                'success': False,
                'error': str(e),
                'traceback': traceback.format_exc(),
                'stdout': stdout_capture.getvalue(),
                'stderr': stderr_capture.getvalue(),
                'execution_id': hashlib.md5(f"{name}{code}".encode()).hexdigest()[:16]
            }
        finally:
            sys.stdout = old_stdout
            sys.stderr = old_stderr

        # Store in history
        self.execution_history.append({
            'name': name,
            'result': execution_result,
            'timestamp': time.time()
        })

        return execution_result

    def execute_code_with_context(self, code: str, name: str, context: Dict = None) -> Dict:
        """Execute Python code with custom execution context."""
        context = context or {}

        # Create execution namespace with provided context
        exec_globals = {
            '__name__': f'__substrate_exec__{name}',
            '__builtins__': __builtins__,
            'context': context,
            'substrate': self.substrate,
        }

        # Add custom imports
        exec_globals.update({
            'math': __import__('math'),
            'json': __import__('json'),
            'os': __import__('os'),
            'sys': sys,
            'time': __import__('time'),
            'numpy': np,
        })

        # Add context variables to execution namespace
        for key, value in context.items():
            if not key.startswith('__'):
                exec_globals[key] = value

        # Capture output
        stdout_capture = StringIO()
        stderr_capture = StringIO()

        old_stdout = sys.stdout
        old_stderr = sys.stderr

        try:
            sys.stdout = stdout_capture
            sys.stderr = stderr_capture

            # Execute the code
            exec(compile(code, f'<substrate:{name}>', 'exec'), exec_globals)

            # Get any return value
            result = exec_globals.get('result', None)

            execution_result = {
                'success': True,
                'result': result,
                'stdout': stdout_capture.getvalue(),
                'stderr': stderr_capture.getvalue(),
                'execution_id': hashlib.md5(f"{name}{code}".encode()).hexdigest()[:16]
            }

        except Exception as e:
            execution_result = {
                'success': False,
                'error': str(e),
                'traceback': traceback.format_exc(),
                'stdout': stdout_capture.getvalue(),
                'stderr': stderr_capture.getvalue(),
                'execution_id': hashlib.md5(f"{name}{code}".encode()).hexdigest()[:16]
            }
        finally:
            sys.stdout = old_stdout
            sys.stderr = old_stderr

        return execution_result

    async def execute_similar(self, query: str, k: int = 3, context: Dict = None) -> Dict:
        """Find and execute similar code vectors."""
        similar = await self.substrate.search_vectors(query, limit=k)

        results = []
        for vector in similar:
            exec_result = await self.execute_vector(vector['id'], context)
            results.append({
                'vector': vector['id'],
                'name': vector['metadata'].get('name', 'unnamed'),
                'result': exec_result
            })

        return {
            'query': query,
            'results': results,
            'total_executed': len(results)
        }

    async def create_executable_vector(self, code: str, name: str,
                                  description: str = "", tags: list = None) -> str:
        """Create an executable vector in substrate."""
        # First execute to validate
        validation = await self.execute_code(code, f"validate_{name}")

        # Generate vector embedding from code
        vector_embedding = self._generate_code_vector(code, name)

        vector_data = {
            'type': 'executable',
            'content': code,
            'metadata': {
                'name': name,
                'description': description,
                'content': code,  # Ensure content is stored in metadata
                'tags': tags or [],
                'executable': True,
                'validation': {
                    'success': validation['success'],
                    'timestamp': time.time()
                }
            }
        }

        if validation['success']:
            vector_data['metadata']['execution_example'] = validation

        # Store in substrate
        vector_id = await self.substrate.store_vector(
            vector_embedding,
            VectorType.CODE_VECTOR,
            metadata=vector_data['metadata']
        )

        return vector_id

    def _generate_code_vector(self, code: str, name: str) -> List[float]:
        """Generate vector embedding for Python code."""
        # Simple hash-based vector generation for now
        # In production, would use proper code embedding model
        code_hash = hashlib.sha256(f"{code}{name}".encode()).hexdigest()

        # Convert hash to vector
        vector = [0.0] * 1536
        for i in range(0, len(code_hash), 6):
            hex_val = code_hash[i:i+6]
            try:
                val = int(hex_val, 16) / 0xFFFFFF  # Normalize to 0-1
                dim = i // 6 % 1536
                vector[dim] = val
            except:
                pass

        return vector

    def get_executables(self) -> List[Dict[str, Any]]:
        """Get all executable vectors from substrate."""
        executables = []
        cursor = self.substrate.conn.execute(
            "SELECT id, vector_data FROM vectors WHERE vector_type = 'code' AND json_extract(metadata_json, '$.executable') = 1"
        )

        for row in cursor:
            entry = VectorEntry.from_bytes(row['vector_data'])
            executables.append({
                'id': entry.id,
                'name': entry.metadata.get('name', 'unnamed'),
                'description': entry.metadata.get('description', ''),
                'tags': entry.metadata.get('tags', []),
                'created_at': entry.created_at
            })

        return executables

    async def evolve_executable_vectors(self):
        """Specialized evolution for executable Python vectors."""
        print("🧠 Evolving executable vectors...")

        # Get all executables
        executables = self.get_executables()

        for exe in executables:
            vector_id = exe['id']
            vector = await self.substrate.get_vector(vector_id)

            if vector:
                current_code = vector.metadata.get('content', '')

                # Analyze the code with LM Studio
                analysis_prompt = f"""
                Analyze this Python code from substrate vector {vector_id}:

                ```python
                {current_code}
                ```

                Suggest specific improvements to:
                1. Make it more efficient
                2. Add better error handling
                3. Improve documentation
                4. Add tests

                Return as JSON with specific code improvements.
                """

                # For now, use simple analysis since we don't have LM Studio connection here
                # In real implementation, this would call LM Studio
                analysis_result = {
                    'suggestions': [
                        'Add docstring to functions',
                        'Add error handling for edge cases',
                        'Improve variable naming',
                        'Add type hints'
                    ]
                }

                if 'suggestions' in analysis_result:
                    # Apply improvements (simplified)
                    improved_code = self._apply_code_improvements(current_code, analysis_result['suggestions'])

                    # Create improved version
                    improved_id = await self.substrate.store_vector(
                        self._generate_code_vector(improved_code, f"{exe['name']}_v2"),
                        VectorType.CODE_VECTOR,
                        metadata={
                            **vector.metadata,
                            'name': f"{exe['name']}_v2",
                            'description': f"Improved version of {vector_id}",
                            'tags': ['evolved', 'improved'],
                            'executable': True
                        }
                    )

                    # Create relation between versions
                    await self.substrate.create_relation(
                        improved_id, vector_id,
                        'evolved_from', 0.9
                    )

                    print(f"  🔄 Improved: {vector_id} → {improved_id}")

    def _apply_code_improvements(self, code: str, suggestions: List[str]) -> str:
        """Apply code improvements based on suggestions."""
        # Simple improvement logic
        improved_code = code

        # Add basic docstring if missing
        if 'def ' in code and '"""' not in code:
            improved_code = code.replace('def ', 'def ')

        # Add basic error handling for division
        if '/' in code and 'try:' not in code:
            improved_code = improved_code.replace('result = ', 'try:\n    result = \n    except ZeroDivisionError:\n        result = 0\n        ')

        return improved_code