import numpy as np
import json
import hashlib
import pickle
import sqlite3
import msgpack
from typing import Dict, List, Any, Optional, Tuple, Union
from datetime import datetime
import asyncio
from dataclasses import dataclass, asdict, field
from pathlib import Path
from enum import Enum
import zlib
import struct

class VectorType(Enum):
    """Types of vectors in the substrate"""
    CODE_VECTOR = "code"           # From Script2Vec
    OS_VECTOR = "os"               # From OS2Vec
    TRUTH_VECTOR = "truth"         # From CTRM
    COMPONENT_VECTOR = "component" # LLM OS Components
    AGENT_VECTOR = "agent"         # AI Agents
    KNOWLEDGE_VECTOR = "knowledge" # General knowledge
    EXECUTION_VECTOR = "execution" # Execution traces
    EVOLUTION_VECTOR = "evolution" # Evolution paths

@dataclass
class VectorEntry:
    """A vector entry in the substrate"""
    id: str
    vector: List[float]
    vector_type: VectorType
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())
    confidence: float = 1.0
    relations: List[str] = field(default_factory=list)  # IDs of related vectors
    embeddings: Dict[str, List[float]] = field(default_factory=dict)  # Multiple embeddings

    def to_bytes(self) -> bytes:
        """Serialize to bytes"""
        data = {
            'id': self.id,
            'vector': self.vector,
            'vector_type': self.vector_type.value,
            'metadata': self.metadata,
            'created_at': self.created_at,
            'updated_at': self.updated_at,
            'confidence': self.confidence,
            'relations': self.relations,
            'embeddings': self.embeddings
        }
        return msgpack.packb(data, use_bin_type=True)

    @classmethod
    def from_bytes(cls, data: bytes) -> 'VectorEntry':
        """Deserialize from bytes"""
        unpacked = msgpack.unpackb(data, raw=False)
        unpacked['vector_type'] = VectorType(unpacked['vector_type'])
        return cls(**unpacked)

class VectorSubstrate:
    """
    Unified vector substrate computational medium
    All vectors (code, OS, truth, components) in one database
    """

    def __init__(self, db_path: str = "./substrate.db"):
        self.db_path = db_path
        self.conn = None
        self.faiss_index = None
        self.vector_cache = {}

        # Initialize databases
        self._init_databases()

    def _init_databases(self):
        """Initialize all database components"""
        # SQLite for metadata and relations
        self.conn = sqlite3.connect(self.db_path)
        self.conn.row_factory = sqlite3.Row

        # Create tables
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS vectors (
                id TEXT PRIMARY KEY,
                vector_type TEXT NOT NULL,
                vector_data BLOB NOT NULL,
                metadata_json TEXT,
                confidence REAL DEFAULT 1.0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS vector_relations (
                source_id TEXT,
                target_id TEXT,
                relation_type TEXT,
                strength REAL DEFAULT 1.0,
                metadata_json TEXT,
                PRIMARY KEY (source_id, target_id, relation_type),
                FOREIGN KEY (source_id) REFERENCES vectors(id),
                FOREIGN KEY (target_id) REFERENCES vectors(id)
            )
        """)

        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS vector_embeddings (
                vector_id TEXT,
                embedding_type TEXT,
                embedding_data BLOB NOT NULL,
                PRIMARY KEY (vector_id, embedding_type),
                FOREIGN KEY (vector_id) REFERENCES vectors(id)
            )
        """)

        self.conn.execute("""
            CREATE VIRTUAL TABLE IF NOT EXISTS vectors_fts USING fts5(
                id, vector_type, metadata_json
            )
        """)

        # Initialize FAISS if available
        self._init_faiss()

        self.conn.commit()

    def _init_faiss(self, dimension: int = 1536):
        """Initialize FAISS index"""
        try:
            import faiss
            self.faiss_index = faiss.IndexFlatIP(dimension)  # Inner product (cosine similarity)
            self.faiss_dimension = dimension
            self.faiss_id_map = []  # Initialize ID map

            # Load existing vectors into FAISS
            cursor = self.conn.execute("SELECT id, vector_data FROM vectors")
            ids = []
            vectors = []

            for row in cursor:
                entry = VectorEntry.from_bytes(row['vector_data'])
                if len(entry.vector) == dimension:
                    ids.append(row['id'])
                    vectors.append(entry.vector)

            if vectors:
                vectors_np = np.array(vectors, dtype=np.float32)
                self.faiss_index.add(vectors_np)
                # Store mapping from FAISS index to vector IDs
                self.faiss_id_map = ids

        except ImportError:
            print("FAISS not available, using fallback similarity")
            self.faiss_index = None
            self.faiss_id_map = None

    async def store_vector(self,
                         vector: List[float],
                         vector_type: VectorType,
                         metadata: Dict[str, Any] = None,
                         generate_id: bool = True,
                         vector_id: str = None) -> str:
        """
        Store a vector in the substrate

        Returns:
            Vector ID in the substrate
        """
        # Generate ID if not provided
        if not vector_id and generate_id:
            # Create ID from vector hash + type
            vector_hash = hashlib.sha256(
                json.dumps(vector, sort_keys=True).encode()
            ).hexdigest()[:16]
            vector_id = f"{vector_type.value}_{vector_hash}"

        # Create vector entry
        entry = VectorEntry(
            id=vector_id,
            vector=vector,
            vector_type=vector_type,
            metadata=metadata or {},
            confidence=1.0
        )

        # Store in SQLite
        self.conn.execute("""
            INSERT OR REPLACE INTO vectors
            (id, vector_type, vector_data, metadata_json, updated_at)
            VALUES (?, ?, ?, ?, ?)
        """, (
            vector_id,
            vector_type.value,
            entry.to_bytes(),
            json.dumps(metadata or {}),
            datetime.now().isoformat()
        ))

        # Store in FAISS if available
        if self.faiss_index and len(vector) == self.faiss_dimension:
            vector_np = np.array([vector], dtype=np.float32)
            self.faiss_index.add(vector_np)
            self.faiss_id_map.append(vector_id)

        self.conn.commit()

        # Cache
        self.vector_cache[vector_id] = entry

        return vector_id

    async def store_multiple_vectors(self,
                                   vectors: List[List[float]],
                                   vector_type: VectorType,
                                   metadatas: List[Dict] = None) -> List[str]:
        """Store multiple vectors efficiently"""
        ids = []

        for i, vector in enumerate(vectors):
            metadata = metadatas[i] if metadatas and i < len(metadatas) else None
            vector_id = await self.store_vector(
                vector, vector_type, metadata, generate_id=True
            )
            ids.append(vector_id)

        return ids

    async def get_vector(self, vector_id: str) -> Optional[VectorEntry]:
        """Retrieve a vector by ID"""
        # Check cache first
        if vector_id in self.vector_cache:
            return self.vector_cache[vector_id]

        # Fallback to SQLite
        cursor = self.conn.execute(
            "SELECT vector_data FROM vectors WHERE id = ?",
            (vector_id,)
        )
        row = cursor.fetchone()

        if row:
            entry = VectorEntry.from_bytes(row['vector_data'])
            self.vector_cache[vector_id] = entry
            return entry

        return None

    async def find_similar_vectors(self,
                                 query_vector: List[float],
                                 vector_type: Optional[VectorType] = None,
                                 top_k: int = 10,
                                 threshold: float = 0.7) -> List[Dict[str, Any]]:
        """
        Find similar vectors in the substrate

        Returns:
            List of similar vectors with IDs and similarity scores
        """
        results = []

        # Use FAISS if available
        if self.faiss_index and len(query_vector) == self.faiss_dimension:
            query_np = np.array([query_vector], dtype=np.float32)

            # Search
            distances, indices = self.faiss_index.search(query_np, top_k * 2)

            for i, (distance, idx) in enumerate(zip(distances[0], indices[0])):
                if idx < 0 or idx >= len(self.faiss_id_map):
                    continue

                vector_id = self.faiss_id_map[idx]

                # Filter by type if specified
                if vector_type:
                    entry = await self.get_vector(vector_id)
                    if entry and entry.vector_type != vector_type:
                        continue

                if distance >= threshold:
                    results.append({
                        'id': vector_id,
                        'similarity': float(distance),
                        'distance': float(1 - distance),
                        'rank': i + 1
                    })

        else:
            # Fallback: brute-force search (slow for large databases)
            cursor = self.conn.execute("SELECT id, vector_data FROM vectors")

            query_np = np.array(query_vector)
            query_norm = np.linalg.norm(query_np)

            for row in cursor:
                entry = VectorEntry.from_bytes(row['vector_data'])

                # Filter by type
                if vector_type and entry.vector_type != vector_type:
                    continue

                # Calculate cosine similarity
                target_np = np.array(entry.vector)
                target_norm = np.linalg.norm(target_np)

                if query_norm > 0 and target_norm > 0:
                    similarity = np.dot(query_np, target_np) / (query_norm * target_norm)

                    if similarity >= threshold:
                        results.append({
                            'id': entry.id,
                            'similarity': float(similarity),
                            'distance': float(1 - similarity),
                            'rank': len(results) + 1
                        })

            # Sort by similarity
            results.sort(key=lambda x: x['similarity'], reverse=True)

        return results[:top_k]

    async def create_relation(self,
                            source_id: str,
                            target_id: str,
                            relation_type: str = "related",
                            strength: float = 1.0,
                            metadata: Dict[str, Any] = None):
        """Create a relation between two vectors"""
        self.conn.execute("""
            INSERT OR REPLACE INTO vector_relations
            (source_id, target_id, relation_type, strength, metadata_json)
            VALUES (?, ?, ?, ?, ?)
        """, (
            source_id,
            target_id,
            relation_type,
            strength,
            json.dumps(metadata or {})
        ))

        # Update vector entries
        source = await self.get_vector(source_id)
        target = await self.get_vector(target_id)

        if source and target:
            if target_id not in source.relations:
                source.relations.append(target_id)
                await self.update_vector(source_id, relations=source.relations)

            if source_id not in target.relations:
                target.relations.append(source_id)
                await self.update_vector(target_id, relations=target.relations)

        self.conn.commit()

    async def get_related_vectors(self,
                                vector_id: str,
                                relation_type: Optional[str] = None,
                                max_depth: int = 1) -> List[Dict[str, Any]]:
        """Get vectors related to a given vector"""
        query = """
            SELECT target_id, relation_type, strength, metadata_json
            FROM vector_relations
            WHERE source_id = ?
        """

        params = [vector_id]
        if relation_type:
            query += " AND relation_type = ?"
            params.append(relation_type)

        cursor = self.conn.execute(query, params)
        results = []

        for row in cursor:
            target_entry = await self.get_vector(row['target_id'])
            if target_entry:
                results.append({
                    'vector': target_entry,
                    'relation_type': row['relation_type'],
                    'strength': row['strength'],
                    'metadata': json.loads(row['metadata_json']) if row['metadata_json'] else {}
                })

        # Recursive if depth > 1
        if max_depth > 1:
            for result in results[:]:  # Copy list to avoid modification during iteration
                deeper = await self.get_related_vectors(
                    result['vector'].id,
                    relation_type,
                    max_depth - 1
                )
                results.extend(deeper)

        return results

    async def update_vector(self,
                          vector_id: str,
                          vector: Optional[List[float]] = None,
                          metadata: Optional[Dict[str, Any]] = None,
                          confidence: Optional[float] = None,
                          relations: Optional[List[str]] = None,
                          embeddings: Optional[Dict[str, List[float]]] = None):
        """Update an existing vector"""
        entry = await self.get_vector(vector_id)
        if not entry:
            raise ValueError(f"Vector {vector_id} not found")

        # Update fields
        if vector is not None:
            entry.vector = vector

        if metadata is not None:
            entry.metadata.update(metadata)

        if confidence is not None:
            entry.confidence = confidence

        if relations is not None:
            entry.relations = relations

        if embeddings is not None:
            entry.embeddings.update(embeddings)

        entry.updated_at = datetime.now().isoformat()

        # Save updates
        self.conn.execute("""
            UPDATE vectors
            SET vector_data = ?, metadata_json = ?, updated_at = ?
            WHERE id = ?
        """, (
            entry.to_bytes(),
            json.dumps(entry.metadata),
            entry.updated_at,
            vector_id
        ))

        # Update cache
        self.vector_cache[vector_id] = entry

        # Update FAISS if vector changed
        if vector is not None and self.faiss_index:
            # FAISS doesn't support updates well, we'd need to rebuild
            # For now, mark for rebuild
            self.faiss_needs_rebuild = True

        self.conn.commit()

    async def delete_vector(self, vector_id: str):
        """Delete a vector and its relations"""
        # Delete from SQLite
        self.conn.execute("DELETE FROM vectors WHERE id = ?", (vector_id,))
        self.conn.execute("DELETE FROM vector_relations WHERE source_id = ? OR target_id = ?",
                         (vector_id, vector_id))

        # Delete from cache
        if vector_id in self.vector_cache:
            del self.vector_cache[vector_id]

        # Mark FAISS for rebuild
        if self.faiss_index:
            self.faiss_needs_rebuild = True

        self.conn.commit()

    async def search_vectors(self,
                           query: str,
                           vector_type: Optional[VectorType] = None,
                           limit: int = 20) -> List[Dict[str, Any]]:
        """Search vectors by metadata (full-text search)"""
        sql_query = """
            SELECT v.id, v.vector_type, v.metadata_json
            FROM vectors v
            JOIN vectors_fts fts ON v.id = fts.id
            WHERE vectors_fts MATCH ?
        """

        params = [query]

        if vector_type:
            sql_query += " AND v.vector_type = ?"
            params.append(vector_type.value)

        sql_query += " ORDER BY rank LIMIT ?"
        params.append(limit)

        cursor = self.conn.execute(sql_query, params)
        results = []

        for row in cursor:
            entry = await self.get_vector(row['id'])
            if entry:
                results.append({
                    'vector': entry,
                    'metadata': json.loads(row['metadata_json']) if row['metadata_json'] else {},
                    'rank': len(results) + 1
                })

        return results

    async def compute_clusters(self,
                             vector_type: Optional[VectorType] = None,
                             n_clusters: int = 10) -> Dict[str, Any]:
        """Cluster vectors in the substrate"""
        try:
            from sklearn.cluster import KMeans
            import numpy as np

            # Get all vectors of specified type
            query = "SELECT id, vector_data FROM vectors"
            params = []

            if vector_type:
                query += " WHERE vector_type = ?"
                params.append(vector_type.value)

            cursor = self.conn.execute(query, params)

            vectors = []
            ids = []

            for row in cursor:
                entry = VectorEntry.from_bytes(row['vector_data'])
                vectors.append(entry.vector)
                ids.append(entry.id)

            if not vectors:
                return {'clusters': {}, 'statistics': {}}

            vectors_np = np.array(vectors)

            # Perform clustering
            kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
            labels = kmeans.fit_predict(vectors_np)

            # Group by cluster
            clusters = {}
            for vector_id, label in zip(ids, labels):
                cluster_name = f"cluster_{label}"
                if cluster_name not in clusters:
                    clusters[cluster_name] = []
                clusters[cluster_name].append(vector_id)

            # Calculate statistics
            statistics = {}
            for cluster_name, members in clusters.items():
                cluster_vectors = [vectors[ids.index(mid)] for mid in members]
                centroid = kmeans.cluster_centers_[int(cluster_name.split('_')[1])]

                # Calculate average distance to centroid
                distances = []
                for vec in cluster_vectors:
                    dist = np.linalg.norm(np.array(vec) - centroid)
                    distances.append(dist)

                statistics[cluster_name] = {
                    'size': len(members),
                    'avg_distance': np.mean(distances) if distances else 0,
                    'centroid': centroid.tolist()
                }

            return {
                'clusters': clusters,
                'statistics': statistics,
                'model': 'kmeans',
                'n_clusters': n_clusters
            }

        except ImportError:
            return {'error': 'scikit-learn required for clustering'}

    async def export_subset(self,
                          vector_ids: List[str],
                          output_path: str):
        """Export a subset of vectors to a file"""
        export_data = []

        for vector_id in vector_ids:
            entry = await self.get_vector(vector_id)
            if entry:
                export_data.append(entry.to_bytes())

        with open(output_path, 'wb') as f:
            pickle.dump(export_data, f)

    async def import_vectors(self, import_path: str):
        """Import vectors from a file"""
        with open(import_path, 'rb') as f:
            import_data = pickle.load(f)

        for data in import_data:
            entry = VectorEntry.from_bytes(data)
            await self.store_vector(
                entry.vector,
                entry.vector_type,
                entry.metadata,
                generate_id=False,
                vector_id=entry.id
            )

    async def get_statistics(self) -> Dict[str, Any]:
        """Get substrate statistics"""
        cursor = self.conn.execute("""
            SELECT
                vector_type,
                COUNT(*) as count,
                AVG(confidence) as avg_confidence
            FROM vectors
            GROUP BY vector_type
        """)

        type_stats = {}
        for row in cursor:
            type_stats[row['vector_type']] = {
                'count': row['count'],
                'avg_confidence': row['avg_confidence']
            }

        # Total count
        total = sum(stats['count'] for stats in type_stats.values())

        # Relation count
        cursor = self.conn.execute("SELECT COUNT(*) as count FROM vector_relations")
        relation_count = cursor.fetchone()['count']

        return {
            'total_vectors': total,
            'by_type': type_stats,
            'relation_count': relation_count,
            'database_size': Path(self.db_path).stat().st_size if Path(self.db_path).exists() else 0
        }

    def get_executables(self) -> List[Dict[str, Any]]:
        """Get all executable vectors from substrate."""
        executables = []
        cursor = self.conn.execute(
            "SELECT id, vector_data FROM vectors WHERE vector_type = 'code' AND json_extract(metadata_json, '$.executable') = 1"
        )

        for row in cursor:
            entry = VectorEntry.from_bytes(row['vector_data'])
            executables.append({
                'id': entry.id,
                'name': entry.metadata.get('name', 'unnamed'),
                'description': entry.metadata.get('description', ''),
                'tags': entry.metadata.get('tags', []),
                'created_at': entry.created_at
            })

        return executables

    def close(self):
        """Close database connections"""
        if self.conn:
            self.conn.close()

    def list_vectors(self) -> List[str]:
        """List all vector IDs"""
        cursor = self.conn.execute("SELECT id FROM vectors")
        return [row['id'] for row in cursor]