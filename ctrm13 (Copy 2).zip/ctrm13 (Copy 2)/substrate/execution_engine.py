#!/usr/bin/env python3
"""
Substrate Execution Engine
Advanced execution system that integrates with LM Studio for code analysis and improvement
"""

import asyncio
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from substrate.vector_db import VectorSubstrate, VectorType
from substrate.vector_executor import SubstratePythonExecutor
from substrate.evolution_agent import SubstrateEvolutionAgent
from substrate.substrate_python_kernel import SubstratePythonKernel
from src.lm_studio.integration import LMStudioIntegration

class SubstrateExecutionEngine:
    """Advanced execution engine that integrates Python execution with LM Studio evolution."""

    def __init__(self, substrate_db: str = "./llm_os_substrate.db"):
        self.substrate = VectorSubstrate(substrate_db)
        self.executor = SubstratePythonExecutor(self.substrate)
        self.kernel = SubstratePythonKernel(self.substrate)
        self.evolution_agent = SubstrateEvolutionAgent(substrate_db=substrate_db)
        self.lm_studio = LMStudioIntegration()

        # Execution queue
        self.execution_queue = asyncio.Queue()
        self.running = False
        self.execution_task = None

        # Statistics
        self.execution_count = 0
        self.success_count = 0
        self.error_count = 0

    async def start(self):
        """Start the execution engine."""
        if self.running:
            return

        self.running = True
        self.execution_task = asyncio.create_task(self._execution_loop())
        await self.evolution_agent.connect()

        print("🚀 Substrate Execution Engine started")

    async def stop(self):
        """Stop the execution engine."""
        if not self.running:
            return

        self.running = False
        if self.execution_task:
            self.execution_task.cancel()
            try:
                await self.execution_task
            except asyncio.CancelledError:
                pass

        await self.evolution_agent.disconnect()
        print("🛑 Substrate Execution Engine stopped")

    async def _execution_loop(self):
        """Main execution loop."""
        while self.running:
            try:
                # Process execution queue
                if not self.execution_queue.empty():
                    task = await self.execution_queue.get()
                    await self._process_execution_task(task)
                    self.execution_queue.task_done()

                # Run periodic evolution
                await self._run_periodic_evolution()

                # Small delay
                await asyncio.sleep(5)

            except Exception as e:
                print(f"⚠️ Execution loop error: {e}")
                await asyncio.sleep(10)

    async def _process_execution_task(self, task):
        """Process an execution task."""
        try:
            if task['type'] == 'execute_code':
                result = await self.executor.execute_code(
                    task['code'],
                    task.get('name', 'auto_exec'),
                    task.get('context', {})
                )
            elif task['type'] == 'execute_vector':
                result = await self.executor.execute_vector(
                    task['vector_id'],
                    task.get('context', {})
                )
            elif task['type'] == 'execute_pipeline':
                result = await self.kernel.execute_pipeline(task['vector_ids'])
            else:
                result = {'error': f'Unknown task type: {task["type"]}'}

            # Update statistics
            self.execution_count += 1
            if result.get('success'):
                self.success_count += 1
            else:
                self.error_count += 1

            # Store execution result
            if task.get('store_result', True):
                await self._store_execution_result(task, result)

            print(f"✅ Executed: {task.get('name', 'unnamed')} -> {'SUCCESS' if result.get('success') else 'ERROR'}")

        except Exception as e:
            print(f"❌ Execution failed: {task.get('name', 'unnamed')} - {str(e)}")
            self.error_count += 1

    async def _store_execution_result(self, task, result):
        """Store execution result in substrate."""
        result_vector = {
            'type': 'execution_result',
            'content': result,
            'metadata': {
                'source': task.get('type', 'unknown'),
                'source_id': task.get('vector_id') or task.get('name', 'auto'),
                'execution_time': asyncio.get_event_loop().time(),
                'success': result.get('success', False),
                'task_details': task
            }
        }

        # Generate vector embedding from result
        import hashlib
        import json
        result_hash = hashlib.sha256(json.dumps(result, sort_keys=True).encode()).hexdigest()
        vector_embedding = [0.0] * 1536
        for i in range(0, len(result_hash), 6):
            hex_val = result_hash[i:i+6]
            try:
                val = int(hex_val, 16) / 0xFFFFFF
                dim = i // 6 % 1536
                vector_embedding[dim] = val
            except:
                pass

        # Store in substrate
        await self.substrate.store_vector(
            vector_embedding,
            VectorType.EXECUTION_VECTOR,
            metadata=result_vector['metadata']
        )

    async def _run_periodic_evolution(self):
        """Run periodic evolution of executable vectors."""
        try:
            # Check if we have enough vectors for evolution
            executables = self.executor.get_executables()
            if len(executables) >= 2 and self.execution_count % 10 == 0:
                print("🧬 Running periodic evolution...")
                await self.executor.evolve_executable_vectors()
                await self.evolution_agent.evolve_substrate(
                    strategy="auto",
                    focus_area="execution",
                    max_iterations=2
                )
        except Exception as e:
            print(f"⚠️ Periodic evolution error: {e}")

    async def execute_with_lm_studio_analysis(self, code: str, name: str, description: str = ""):
        """Execute code with LM Studio analysis and improvement."""
        print(f"🔍 Analyzing and executing: {name}")

        # Step 1: Execute original code
        original_result = await self.executor.execute_code(code, f"{name}_original")

        # Step 2: Analyze with LM Studio
        analysis = await self.lm_studio.analyze_code_quality(code, "python")

        # Handle case where LM Studio is unavailable
        if analysis is None:
            analysis = {
                'code_quality_score': 7,
                'improvements': ['Add comprehensive docstrings', 'Implement proper error handling'],
                'performance_suggestions': ['Use list comprehensions where appropriate'],
                'security_considerations': ['Add input validation'],
                'documentation_recommendations': ['Add function docstrings'],
                'error_handling_improvements': ['Add try-catch blocks']
            }

        # Step 3: Create improved version if analysis suggests improvements
        if analysis.get('improvements'):
            improved_code = await self.lm_studio.generate_improved_code(code, analysis)
            improved_result = await self.executor.execute_code(improved_code, f"{name}_improved")

            # Analyze execution results
            execution_analysis = await self.lm_studio.analyze_execution_results(
                improved_code, improved_result
            )

            # Store both versions
            original_vector_id = await self.executor.create_executable_vector(
                code, f"{name}_original", description
            )
            improved_vector_id = await self.executor.create_executable_vector(
                improved_code, f"{name}_improved", f"LM Studio improved version of {name}"
            )

            # Create relation
            await self.substrate.create_relation(
                improved_vector_id, original_vector_id,
                'lm_studio_improved', 0.95,
                metadata={
                    'analysis': analysis,
                    'execution_analysis': execution_analysis,
                    'improvement_date': asyncio.get_event_loop().time()
                }
            )

            return {
                'original': original_result,
                'improved': improved_result,
                'analysis': analysis,
                'execution_analysis': execution_analysis,
                'original_vector_id': original_vector_id,
                'improved_vector_id': improved_vector_id
            }

        # Store original if no improvements
        vector_id = await self.executor.create_executable_vector(code, name, description)
        return {
            'original': original_result,
            'analysis': analysis,
            'vector_id': vector_id
        }


    async def create_execution_pipeline(self, pipeline_name: str, vector_names: list):
        """Create and execute a pipeline of vectors."""
        # Find vectors by name
        vector_ids = []
        for name in vector_names:
            search_results = await self.substrate.search_vectors(name, limit=1)
            if search_results:
                vector_ids.append(search_results[0]['id'])

        if not vector_ids:
            return {'error': 'No vectors found for pipeline'}

        # Execute pipeline
        pipeline_result = self.kernel.execute_pipeline(vector_ids)

        # Store pipeline definition
        pipeline_vector = {
            'type': 'execution_pipeline',
            'content': {
                'name': pipeline_name,
                'vector_ids': vector_ids,
                'vector_names': vector_names
            },
            'metadata': {
                'pipeline_type': 'sequential',
                'execution_count': 0,
                'last_executed': asyncio.get_event_loop().time()
            }
        }

        # Store pipeline definition
        await self.substrate.store_vector(
            [0.5] * 1536,  # Simple pipeline vector
            'component',
            metadata=pipeline_vector['metadata']
        )

        return {
            'pipeline_result': pipeline_result,
            'vector_ids': vector_ids,
            'pipeline_name': pipeline_name
        }

    async def get_engine_status(self) -> dict:
        """Get current engine status."""
        stats = await self.substrate.get_statistics()
        executables = self.executor.get_executables()

        return {
            'running': self.running,
            'execution_count': self.execution_count,
            'success_count': self.success_count,
            'error_count': self.error_count,
            'success_rate': self.success_count / self.execution_count if self.execution_count > 0 else 0.0,
            'queue_size': self.execution_queue.qsize(),
            'substrate_stats': stats,
            'executable_count': len(executables),
            'executables': [exe['name'] for exe in executables[:10]]
        }

    async def queue_execution(self, task: dict):
        """Queue an execution task."""
        await self.execution_queue.put(task)
        return {'status': 'queued', 'queue_size': self.execution_queue.qsize()}

async def main():
    """Main execution engine test."""
    engine = SubstrateExecutionEngine()

    try:
        # Start engine
        await engine.start()

        # Test basic execution
        test_code = """
def calculate_fibonacci(n):
    if n <= 1:
        return n
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    return a

result = calculate_fibonacci(10)
print(f"Fibonacci(10) = {result}")
"""

        # Execute with LM Studio analysis
        result = await engine.execute_with_lm_studio_analysis(
            test_code,
            "fibonacci_calculator",
            "Calculate Fibonacci numbers"
        )

        print(f"✅ Execution with LM Studio analysis complete!")
        print(f"   Original result: {result['original']['success']}")
        print(f"   Improved result: {result.get('improved', {}).get('success', 'N/A')}")

        # Test pipeline creation
        pipeline_result = await engine.create_execution_pipeline(
            "math_pipeline",
            ["fibonacci_calculator", "stats_calculator"]
        )

        print(f"✅ Pipeline creation: {pipeline_result.get('pipeline_result', {}).get('success', False)}")

        # Get engine status
        status = await engine.get_engine_status()
        print(f"📊 Engine status: {status['execution_count']} executions, {status['success_rate']:.1%} success rate")

        # Test queue system
        await engine.queue_execution({
            'type': 'execute_code',
            'name': 'queued_test',
            'code': 'print("Queued execution test")'
        })

        print("✅ Queued execution test")

        # Let it run for a bit
        await asyncio.sleep(3)

        # Final status
        final_status = await engine.get_engine_status()
        print(f"🎉 Final status: {final_status['execution_count']} total executions")

    finally:
        await engine.stop()

if __name__ == "__main__":
    asyncio.run(main())