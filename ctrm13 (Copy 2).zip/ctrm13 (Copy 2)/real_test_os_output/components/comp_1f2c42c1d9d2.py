I need to create a vector_memory component that handles vector-based memory with semantic search and persistence.

Let me break down the requirements:
1. Complete runnable Python 3.10+ code
2. Proper imports
3. Docstrings for all functions/classes
4. Error handling
5. Modular and testable
6. PEP 8 style
7. Main class/function representing component
8. No placeholder comments like "TODO"
9. No planning text - only actual Python code
10. Start with imports, then implement the design

I'll create a vector_memory component that:
1. Stores vectors in memory
2. Provides semantic search capabilities
3. Persists data to disk
4. Handles errors gracefully

Let me write the complete implementation: