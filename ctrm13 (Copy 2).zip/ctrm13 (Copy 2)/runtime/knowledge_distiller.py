"""
Knowledge Distiller - Holographic Transfer Protocol with SQL-Native LLM Integration
Bridges LLM knowledge into the substrate via vector crystallization and SQL UDFs
"""

import asyncio
import json
import hashlib
import time
import numpy as np
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
import pickle
import zlib
import sqlite3

# Mock LLM client for when real LM Studio is not available
class MockLLM:
    """Mock LLM client for testing and fallback"""

    def __init__(self):
        self.knowledge_base = {
            "Basic Math": {
                "concepts": ["Addition", "Subtraction", "Multiplication", "Division", "Fractions"],
                "explanations": {
                    "Addition": "Addition is the process of combining two or more numbers to find their total. For example, 2 + 3 = 5. It's commutative (a + b = b + a) and associative ((a + b) + c = a + (b + c)).",
                    "Subtraction": "Subtraction is the operation of finding the difference between two numbers. For example, 5 - 3 = 2. It's the inverse of addition.",
                    "Multiplication": "Multiplication is repeated addition. For example, 3 × 4 = 12 means adding 3 four times. It's commutative and associative like addition.",
                    "Division": "Division is the process of splitting a number into equal parts. For example, 12 ÷ 3 = 4. It's the inverse of multiplication.",
                    "Fractions": "Fractions represent parts of a whole. They consist of a numerator (top) and denominator (bottom). For example, 1/2 represents one half."
                }
            },
            "Advanced Mathematics": {
                "concepts": ["Calculus", "Linear Algebra", "Probability", "Statistics", "Discrete Mathematics"],
                "explanations": {
                    "Calculus": "Calculus studies rates of change (differential calculus) and accumulation (integral calculus). It's fundamental for physics, engineering, and economics.",
                    "Linear Algebra": "Linear algebra deals with vectors, matrices, and linear transformations. It's essential for computer graphics, machine learning, and quantum mechanics.",
                    "Probability": "Probability quantifies the likelihood of events occurring. It's the foundation of statistics and data science.",
                    "Statistics": "Statistics involves collecting, analyzing, and interpreting data. It includes descriptive statistics and inferential statistics.",
                    "Discrete Mathematics": "Discrete mathematics studies mathematical structures that are fundamentally discrete rather than continuous. It's crucial for computer science."
                }
            }
        }

    async def generate_probes(self, domain: str, num_probes: int = 5) -> List[str]:
        """Generate conceptual probes (questions) for a domain"""
        if domain in self.knowledge_base:
            concepts = self.knowledge_base[domain]["concepts"]
            return [f"Explain the concept of {concept} in {domain}" for concept in concepts[:num_probes]]
        else:
            # Generate generic probes for unknown domains
            return [
                f"What are the fundamental concepts in {domain}?",
                f"Explain the basic principles of {domain}",
                f"What are the key theories in {domain}?",
                f"Describe the main applications of {domain}",
                f"What are the foundational elements of {domain}?"
            ]

    async def interrogate_oracle(self, probe: str) -> str:
        """Query the LLM oracle for knowledge about a specific concept"""
        # Try to extract domain and concept from probe
        if "Explain the concept of" in probe:
            parts = probe.replace("Explain the concept of ", "").split(" in ")
            if len(parts) == 2:
                concept, domain = parts
                if domain in self.knowledge_base and concept in self.knowledge_base[domain]["explanations"]:
                    return self.knowledge_base[domain]["explanations"][concept]

        # Fallback for unknown concepts
        return f"This is a detailed explanation of {probe}. It covers the fundamental principles, key applications, and theoretical foundations of the concept."

    def interrogate_oracle_sync(self, probe: str) -> str:
        """Synchronous version for SQL UDFs"""
        # MockLLM methods are actually synchronous, so we can call them directly
        # For real async LLM clients, this would need proper async handling
        if domain in self.knowledge_base:
            concepts = self.knowledge_base[domain]["concepts"]
            for concept in concepts:
                if f"Explain the concept of {concept} in {domain}" == probe:
                    return self.knowledge_base[domain]["explanations"][concept]

        # Fallback for unknown concepts
        return f"This is a detailed explanation of {probe}. It covers the fundamental principles, key applications, and theoretical foundations of the concept."

    def generate_probes_sync(self, domain: str, num_probes: int = 5) -> List[str]:
        """Synchronous version for SQL UDFs"""
        # MockLLM methods are actually synchronous, so we can call them directly
        if domain in self.knowledge_base:
            concepts = self.knowledge_base[domain]["concepts"]
            return [f"Explain the concept of {concept} in {domain}" for concept in concepts[:num_probes]]
        else:
            # Generate generic probes for unknown domains
            return [
                f"What are the fundamental concepts in {domain}?",
                f"Explain the basic principles of {domain}",
                f"What are the key theories in {domain}?",
                f"Describe the main applications of {domain}",
                f"What are the foundational elements of {domain}?"
            ][:num_probes]

@dataclass
class KnowledgeVector:
    """Structured knowledge vector with metadata"""
    id: str
    domain: str
    concept: str
    explanation: str
    vector_embedding: np.ndarray
    metadata: Dict[str, Any]
    created_at: float

class KnowledgeDistiller:
    """Holographic Transfer Protocol Implementation"""

    def __init__(self, db_path: str = "knowledge_substrate.db", llm_client: Optional[Any] = None):
        """
        Initialize Knowledge Distiller

        Args:
            db_path: Path to SQLite database for storing crystallized knowledge
            llm_client: LLM client (MockLLM or real LM Studio client)
        """
        self.db_path = db_path
        self.llm_client = llm_client or MockLLM()

        # Initialize database connection
        import sqlite3
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row

        # Enable WAL mode for better concurrency (multiple readers, one writer)
        self.conn.execute("PRAGMA journal_mode=WAL;")
        self.conn.execute("PRAGMA synchronous=NORMAL;")
        self.conn.execute("PRAGMA busy_timeout=5000;")

        # Initialize database schema
        self._init_database()

        # In-memory knowledge index
        self.knowledge_index = {}  # concept_id -> KnowledgeVector
        self._load_knowledge_index()

    def _mock_llm_sync_response(self, prompt: str) -> str:
        """Helper for SQL UDFs to get synchronous LLM responses"""
        # Extract domain and concept from prompt
        if "Explain the concept of" in prompt:
            parts = prompt.replace("Explain the concept of ", "").split(" in ")
            if len(parts) == 2:
                concept, domain = parts
                if hasattr(self.llm_client, 'knowledge_base') and domain in self.llm_client.knowledge_base:
                    if concept in self.llm_client.knowledge_base[domain]["explanations"]:
                        return self.llm_client.knowledge_base[domain]["explanations"][concept]

        # Fallback response
        return f"This is a detailed explanation of {prompt}. It covers the fundamental principles, key applications, and theoretical foundations of the concept."

    def _mock_generate_probes_sync(self, domain: str, num_probes: int = 5) -> List[str]:
        """Helper for SQL UDFs to generate probes synchronously"""
        if hasattr(self.llm_client, 'knowledge_base') and domain in self.llm_client.knowledge_base:
            concepts = self.llm_client.knowledge_base[domain]["concepts"]
            return [f"Explain the concept of {concept} in {domain}" for concept in concepts[:num_probes]]
        else:
            # Generate generic probes for unknown domains
            return [
                f"What are the fundamental concepts in {domain}?",
                f"Explain the basic principles of {domain}",
                f"What are the key theories in {domain}?",
                f"Describe the main applications of {domain}",
                f"What are the foundational elements of {domain}?"
            ][:num_probes]
    def _register_sql_udfs(self):
        """Register SQLite User Defined Functions for direct LLM integration"""

        def sql_llm_generate(prompt):
            """SQL UDF that calls LLM directly from SQLite queries"""
            try:
                # For MockLLM, we can call directly since it has sync fallback
                if hasattr(self.llm_client, 'interrogate_oracle'):
                    # Check if we're in an async context
                    try:
                        loop = asyncio.get_running_loop()
                        # If we're in a running event loop, we need to create a new task
                        # For SQLite UDFs, we'll use a synchronous fallback
                        if hasattr(self.llm_client, 'interrogate_oracle_sync'):
                            return self.llm_client.interrogate_oracle_sync(prompt)
                        else:
                            # Use the mock knowledge base directly
                            return self._mock_llm_sync_response(prompt)
                    except RuntimeError:
                        # No running event loop, we can use asyncio.run
                        result = asyncio.run(self.llm_client.interrogate_oracle(prompt))
                        return result
                else:
                    return f"LLM response for: {prompt}"
            except Exception as e:
                return f"Error generating LLM response: {str(e)}"

        def sql_llm_generate_probes(domain, num_probes=5):
            """SQL UDF that generates probes for a domain"""
            try:
                # Check if we're in an async context
                try:
                    loop = asyncio.get_running_loop()
                    # Use synchronous fallback for SQLite UDFs
                    if hasattr(self.llm_client, 'generate_probes_sync'):
                        probes = self.llm_client.generate_probes_sync(domain, int(num_probes))
                        return json.dumps(probes)
                    else:
                        # Use mock knowledge base directly
                        return json.dumps(self._mock_generate_probes_sync(domain, int(num_probes)))
                except RuntimeError:
                    # No running event loop, we can use asyncio.run
                    probes = asyncio.run(self.llm_client.generate_probes(domain, int(num_probes)))
                    return json.dumps(probes)
            except Exception as e:
                return json.dumps([])

        def sql_create_embedding(text):
            """SQL UDF that creates embeddings directly in SQL"""
            try:
                embedding = self._create_embedding(text)
                return self._serialize_embedding(embedding)
            except Exception as e:
                return b""

        def sql_cosine_similarity(a_blob, b_blob):
            """SQL UDF that calculates cosine similarity between embeddings"""
            try:
                a = self._deserialize_embedding(a_blob)
                b = self._deserialize_embedding(b_blob)
                return self._cosine_similarity(a, b)
            except Exception as e:
                return 0.0

        # Register the UDFs with SQLite
        self.conn.create_function("LLM_GENERATE", 1, sql_llm_generate)
        self.conn.create_function("LLM_GENERATE_PROBES", 2, sql_llm_generate_probes)
        self.conn.create_function("CREATE_EMBEDDING", 1, sql_create_embedding)
        self.conn.create_function("COSINE_SIMILARITY", 2, sql_cosine_similarity)

        print("🔌 Registered SQL UDFs for LLM integration")

    def enable_sql_driven_distillation(self):
        """
        Enable SQL-driven distillation process
        This creates SQL functions that allow distillation to be driven by SQL queries
        """
        self._register_sql_udfs()

        # Create SQL functions for knowledge distillation steps
        def sql_distill_knowledge(domain, concept, explanation):
            """SQL UDF that performs complete knowledge distillation"""
            try:
                # This would normally be async, but for SQL UDF we make it synchronous
                knowledge_id = asyncio.run(self._crystallize_knowledge(domain, concept, explanation))
                return knowledge_id
            except Exception as e:
                return f"Error: {str(e)}"

        self.conn.create_function("DISTILL_KNOWLEDGE", 3, sql_distill_knowledge)

        print("🚀 SQL-driven distillation enabled")

    async def distill_domain_sql_driven(self, domain: str, num_concepts: int = 5) -> List[str]:
        """
        SQL-driven distillation process
        Uses SQLite to orchestrate the entire distillation workflow
        """
        print(f"🔮 Beginning SQL-driven holographic transfer for domain: {domain}")

        # Enable SQL-driven distillation
        self.enable_sql_driven_distillation()

        # Use SQL to generate probes
        cursor = self.conn.cursor()

        # Step 1: Generate probes using SQL UDF
        cursor.execute("SELECT LLM_GENERATE_PROBES(?, ?) as probes", (domain, num_concepts))
        result = cursor.fetchone()
        probes = json.loads(result['probes']) if result and result['probes'] else []

        print(f"🎯 SQL generated {len(probes)} conceptual probes")

        knowledge_ids = []

        # Step 2: Process each probe using SQL-driven workflow
        for i, probe in enumerate(probes):
            print(f"🔍 SQL processing probe {i+1}/{len(probes)}: {probe}")

            # Extract concept from probe
            concept = self._extract_concept_from_probe(probe, domain)

            # Step 2a: Query LLM using SQL UDF
            cursor.execute("SELECT LLM_GENERATE(?) as explanation", (probe,))
            result = cursor.fetchone()
            explanation = result['explanation'] if result and result['explanation'] else "No explanation generated"

            print(f"📚 SQL received explanation: {explanation[:100]}...")

            # Step 2b: Crystallize knowledge using SQL UDF
            cursor.execute("SELECT DISTILL_KNOWLEDGE(?, ?, ?) as knowledge_id",
                          (domain, concept, explanation))
            result = cursor.fetchone()
            knowledge_id = result['knowledge_id'] if result and result['knowledge_id'] else None

            if knowledge_id and knowledge_id.startswith('know_'):
                knowledge_ids.append(knowledge_id)
                print(f"💎 SQL crystallized knowledge vector {knowledge_id} for {concept}")
            else:
                print(f"⚠️  SQL crystallization failed for {concept}: {knowledge_id}")

        print(f"✅ Completed SQL-driven holographic transfer for {domain}. Created {len(knowledge_ids)} knowledge vectors.")
        return knowledge_ids

    def execute_sql_distillation_query(self, query: str) -> List[Dict[str, Any]]:
        """
        Execute a custom SQL query for knowledge distillation
        Allows complex distillation workflows to be expressed in SQL
        """
        try:
            cursor = self.conn.cursor()
            cursor.execute(query)

            # Try to fetch results if it's a SELECT query
            try:
                columns = [column[0] for column in cursor.description]
                results = []
                for row in cursor.fetchall():
                    results.append(dict(zip(columns, row)))
                return results
            except:
                # For non-SELECT queries, commit and return success
                self.conn.commit()
                return [{"status": "success", "rows_affected": cursor.rowcount}]
        except Exception as e:
            return [{"status": "error", "error": str(e)}]

    def create_sql_distillation_workflow(self, workflow_name: str, sql_template: str):
        """
        Store a named SQL distillation workflow for reuse
        """
        cursor = self.conn.cursor()

        # Create workflow table if it doesn't exist
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS distillation_workflows (
            name TEXT PRIMARY KEY,
            sql_template TEXT,
            created_at REAL,
            last_used REAL,
            usage_count INTEGER DEFAULT 0
        )
        """)

        # Store the workflow
        cursor.execute("""
        INSERT OR REPLACE INTO distillation_workflows
        (name, sql_template, created_at, last_used, usage_count)
        VALUES (?, ?, ?, ?, COALESCE((SELECT usage_count FROM distillation_workflows WHERE name = ?), 0) + 1)
        """, (workflow_name, sql_template, time.time(), time.time(), workflow_name))

        self.conn.commit()
        print(f"📋 Created SQL distillation workflow: {workflow_name}")

    def execute_named_workflow(self, workflow_name: str, **parameters) -> List[Dict[str, Any]]:
        """
        Execute a named distillation workflow with parameters
        """
        cursor = self.conn.cursor()

        # Get the workflow template
        cursor.execute("SELECT sql_template FROM distillation_workflows WHERE name = ?", (workflow_name,))
        result = cursor.fetchone()

        if not result:
            return [{"status": "error", "error": f"Workflow {workflow_name} not found"}]

        sql_template = result['sql_template']

        # Replace parameters in the template
        sql_query = sql_template.format(**parameters)

        # Execute the workflow
        return self.execute_sql_distillation_query(sql_query)

    def _init_database(self):
        """Initialize database schema for knowledge storage"""
        cursor = self.conn.cursor()

        # Knowledge vectors table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS knowledge_vectors (
            id TEXT PRIMARY KEY,
            domain TEXT NOT NULL,
            concept TEXT NOT NULL,
            explanation TEXT NOT NULL,
            vector_embedding BLOB NOT NULL,
            metadata TEXT,
            created_at REAL,
            source_type TEXT DEFAULT 'distilled',
            quality_score REAL DEFAULT 0.8,
            usage_count INTEGER DEFAULT 0
        )
        """)

        # Knowledge relationships table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS knowledge_relationships (
            source_id TEXT,
            target_id TEXT,
            relationship_type TEXT,
            strength REAL,
            created_at REAL,
            PRIMARY KEY (source_id, target_id, relationship_type),
            FOREIGN KEY (source_id) REFERENCES knowledge_vectors(id),
            FOREIGN KEY (target_id) REFERENCES knowledge_vectors(id)
        )
        """)

        # Domain index table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS domain_index (
            domain TEXT PRIMARY KEY,
            concept_count INTEGER DEFAULT 0,
            last_updated REAL,
            metadata TEXT
        )
        """)

        # Create indices for fast search
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_domain ON knowledge_vectors(domain)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_concept ON knowledge_vectors(concept)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_quality ON knowledge_vectors(quality_score)")

        self.conn.commit()

    def _load_knowledge_index(self):
        """Load knowledge vectors into memory index"""
        cursor = self.conn.cursor()
        cursor.execute("SELECT id, domain, concept, explanation, vector_embedding, metadata, created_at FROM knowledge_vectors")

        for row in cursor.fetchall():
            vector_embedding = self._deserialize_embedding(row['vector_embedding'])
            metadata = json.loads(row['metadata']) if row['metadata'] else {}

            knowledge_vector = KnowledgeVector(
                id=row['id'],
                domain=row['domain'],
                concept=row['concept'],
                explanation=row['explanation'],
                vector_embedding=vector_embedding,
                metadata=metadata,
                created_at=row['created_at']
            )

            self.knowledge_index[row['id']] = knowledge_vector

        print(f"🧠 Loaded {len(self.knowledge_index)} knowledge vectors into memory")

    def _create_embedding(self, text: str) -> np.ndarray:
        """Create deterministic embedding from text using hash-based approach"""
        # Create a deterministic embedding based on text content
        text_hash = hashlib.md5(text.encode()).hexdigest()

        # Use hash to seed random generator for reproducibility
        rng = np.random.RandomState(int(text_hash[:8], 16))

        # Create 128-dimensional embedding
        embedding = rng.uniform(-1, 1, 128)

        # Normalize to unit vector
        embedding = embedding / np.linalg.norm(embedding)

        return embedding.astype(np.float32)

    def _serialize_embedding(self, embedding: np.ndarray) -> bytes:
        """Serialize numpy array to bytes for SQLite storage"""
        return pickle.dumps(embedding)

    def _deserialize_embedding(self, blob: bytes) -> np.ndarray:
        """Deserialize bytes back to numpy array"""
        return pickle.loads(blob)

    async def distill_domain(self, domain: str, num_concepts: int = 5, specific_concept: Optional[str] = None) -> List[str]:
        """
        Main distillation loop for a domain

        Args:
            domain: Domain to distill (e.g., "Basic Math", "Physics")
            num_concepts: Number of concepts to extract
            specific_concept: Optional specific concept to distill

        Returns:
            List of created knowledge vector IDs
        """
        print(f"🔮 Beginning holographic transfer for domain: {domain}")

        probes = []
        if specific_concept:
            # If a specific concept is provided, create a single probe for it
            probes.append(f"Explain the concept of {specific_concept} in {domain}")
            print(f"🎯 Generated single probe for specific concept: {specific_concept}")
        else:
            # Step 1: Generate probes (questions) for the broader domain
            probes = await self._generate_probes(domain, num_concepts)
            print(f"🎯 Generated {len(probes)} conceptual probes")

        knowledge_ids = []

        # Step 2: Interrogate oracle and crystallize knowledge
        for i, probe in enumerate(probes):
            print(f"🔍 Processing probe {i+1}/{len(probes)}: {probe}")

            # Extract concept from probe
            concept = self._extract_concept_from_probe(probe, domain)

            # Step 2a: Query LLM for explanation
            explanation = await self._interrogate_oracle(probe)
            print(f"📚 Received explanation: {explanation[:100]}...")

            # Step 2b: Crystallize knowledge (vectorize and store)
            knowledge_id = await self._crystallize_knowledge(domain, concept, explanation)
            knowledge_ids.append(knowledge_id)

        print(f"✅ Completed holographic transfer for {domain}. Created {len(knowledge_ids)} knowledge vectors.")
        return knowledge_ids

    async def _generate_probes(self, domain: str, num_probes: int = 5) -> List[str]:
        """Generate conceptual probes (questions) for a domain"""
        return await self.llm_client.generate_probes(domain, num_probes)

    async def _interrogate_oracle(self, probe: str) -> str:
        """Query the LLM oracle for knowledge about a specific concept"""
        return await self.llm_client.interrogate_oracle(probe)

    def _extract_concept_from_probe(self, probe: str, domain: str) -> str:
        """Extract concept name from probe text"""
        if "Explain the concept of" in probe:
            # Format: "Explain the concept of [Concept] in [Domain]"
            parts = probe.replace("Explain the concept of ", "").split(" in ")
            if len(parts) == 2:
                return parts[0].strip()

        # Fallback: use first few words as concept
        words = probe.split()
        return " ".join(words[:3]) if len(words) >= 3 else probe[:50]

    async def _crystallize_knowledge(self, domain: str, concept: str, explanation: str) -> str:
        """
        Vectorize and store knowledge in the substrate

        Args:
            domain: Knowledge domain
            concept: Specific concept
            explanation: Detailed explanation from LLM

        Returns:
            Knowledge vector ID
        """
        # Create unique ID for this knowledge vector
        content_hash = hashlib.md5(f"{domain}:{concept}:{explanation}".encode()).hexdigest()
        knowledge_id = f"know_{content_hash[:8]}"

        # Check if already exists
        cursor = self.conn.cursor()
        cursor.execute("SELECT id FROM knowledge_vectors WHERE id = ?", (knowledge_id,))
        if cursor.fetchone():
            print(f"🔄 Knowledge vector {knowledge_id} already exists")
            return knowledge_id

        # Create embedding from the knowledge content
        knowledge_text = f"{domain} - {concept}: {explanation}"
        vector_embedding = self._create_embedding(knowledge_text)

        # Create metadata
        metadata = {
            "source": "distilled",
            "distillation_method": "holographic_transfer",
            "original_probe": f"Explain {concept} in {domain}",
            "vector_dimensions": vector_embedding.shape[0],
            "domain_specificity": self._calculate_domain_specificity(domain, explanation)
        }

        # Store in database
        cursor.execute("""
        INSERT INTO knowledge_vectors
        (id, domain, concept, explanation, vector_embedding, metadata, created_at, source_type)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            knowledge_id,
            domain,
            concept,
            explanation,
            self._serialize_embedding(vector_embedding),
            json.dumps(metadata),
            time.time(),
            "distilled"
        ))

        # Update domain index
        cursor.execute("""
        INSERT OR IGNORE INTO domain_index (domain, concept_count, last_updated, metadata)
        VALUES (?, 0, ?, ?)
        """, (domain, time.time(), json.dumps({"description": f"Auto-created for {domain}"})))

        cursor.execute("""
        UPDATE domain_index
        SET concept_count = concept_count + 1, last_updated = ?
        WHERE domain = ?
        """, (time.time(), domain))

        # Update in-memory index
        knowledge_vector = KnowledgeVector(
            id=knowledge_id,
            domain=domain,
            concept=concept,
            explanation=explanation,
            vector_embedding=vector_embedding,
            metadata=metadata,
            created_at=time.time()
        )

        self.knowledge_index[knowledge_id] = knowledge_vector

        self.conn.commit()
        print(f"💎 Crystallized knowledge vector {knowledge_id} for {concept} in {domain}")

        return knowledge_id

    def _calculate_domain_specificity(self, domain: str, explanation: str) -> float:
        """Calculate how specific this knowledge is to the domain (0-1 scale)"""
        # Simple heuristic: count domain-related terms in explanation
        domain_terms = domain.lower().split()
        explanation_lower = explanation.lower()

        term_count = sum(1 for term in domain_terms if term in explanation_lower)
        total_words = len(explanation.split())

        return min(1.0, term_count / max(1, total_words * 0.1))  # Normalized score

    def search_knowledge(self,
                        query: str,
                        domain: Optional[str] = None,
                        limit: int = 5) -> List[Dict[str, Any]]:
        """
        Search for knowledge vectors using semantic similarity

        Args:
            query: Search query text
            domain: Optional domain filter
            limit: Maximum number of results

        Returns:
            List of matching knowledge vectors with similarity scores
        """
        # Create query embedding
        query_embedding = self._create_embedding(query)

        # Calculate similarities
        similarities = []
        for know_id, knowledge_vector in self.knowledge_index.items():
            # Apply domain filter if specified
            if domain and knowledge_vector.domain != domain:
                continue

            # Calculate cosine similarity
            similarity = self._cosine_similarity(query_embedding, knowledge_vector.vector_embedding)
            similarities.append((know_id, similarity))

        # Sort by similarity
        similarities.sort(key=lambda x: x[1], reverse=True)

        # Get top results with details
        results = []
        for know_id, similarity in similarities[:limit]:
            cursor = self.conn.cursor()
            cursor.execute("""
            SELECT id, domain, concept, explanation, quality_score, usage_count
            FROM knowledge_vectors WHERE id = ?
            """, (know_id,))

            row = cursor.fetchone()
            if row:
                results.append({
                    'id': row['id'],
                    'domain': row['domain'],
                    'concept': row['concept'],
                    'explanation': row['explanation'][:200] + "..." if len(row['explanation']) > 200 else row['explanation'],
                    'similarity': float(similarity),
                    'quality_score': row['quality_score'],
                    'usage_count': row['usage_count']
                })

        return results

    def _cosine_similarity(self, a: np.ndarray, b: np.ndarray) -> float:
        """Calculate cosine similarity between two vectors"""
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)

        if norm_a == 0 or norm_b == 0:
            return 0.0

        return float(np.dot(a, b) / (norm_a * norm_b))

    def get_knowledge_vector(self, knowledge_id: str) -> Optional[KnowledgeVector]:
        """Retrieve a specific knowledge vector"""
        return self.knowledge_index.get(knowledge_id)

    def get_domain_statistics(self, domain: str) -> Dict[str, Any]:
        """Get statistics for a specific domain"""
        cursor = self.conn.cursor()

        # Get domain info
        cursor.execute("SELECT * FROM domain_index WHERE domain = ?", (domain,))
        domain_row = cursor.fetchone()

        # Get knowledge vectors in domain
        cursor.execute("""
        SELECT COUNT(*) as count, AVG(quality_score) as avg_quality, SUM(usage_count) as total_usage
        FROM knowledge_vectors WHERE domain = ?
        """, (domain,))

        stats_row = cursor.fetchone()

        return {
            'domain': domain,
            'concept_count': domain_row['concept_count'] if domain_row else 0,
            'last_updated': domain_row['last_updated'] if domain_row else None,
            'avg_quality_score': stats_row['avg_quality'] if stats_row['avg_quality'] else 0.0,
            'total_usage': stats_row['total_usage'] if stats_row['total_usage'] else 0,
            'metadata': json.loads(domain_row['metadata']) if domain_row and domain_row['metadata'] else {}
        }

    def update_quality_score(self, knowledge_id: str, score: float):
        """Update quality score based on usage and feedback"""
        cursor = self.conn.cursor()

        # Get current score and usage
        cursor.execute(
            "SELECT quality_score, usage_count FROM knowledge_vectors WHERE id = ?",
            (knowledge_id,)
        )
        row = cursor.fetchone()

        if row:
            current_score = row['quality_score']
            usage_count = row['usage_count'] + 1

            # Update with exponential moving average
            new_score = current_score * 0.8 + score * 0.2

            cursor.execute("""
            UPDATE knowledge_vectors
            SET quality_score = ?, usage_count = ?
            WHERE id = ?
            """, (new_score, usage_count, knowledge_id))

            self.conn.commit()

    def create_knowledge_relationship(self,
                                    source_id: str,
                                    target_id: str,
                                    relationship_type: str,
                                    strength: float = 1.0):
        """Create a relationship between two knowledge vectors"""
        cursor = self.conn.cursor()

        cursor.execute("""
        INSERT OR REPLACE INTO knowledge_relationships
        (source_id, target_id, relationship_type, strength, created_at)
        VALUES (?, ?, ?, ?, ?)
        """, (source_id, target_id, relationship_type, strength, time.time()))

        self.conn.commit()

    def get_related_knowledge(self, knowledge_id: str, limit: int = 3) -> List[Dict[str, Any]]:
        """Get knowledge vectors related to a specific vector"""
        cursor = self.conn.cursor()

        cursor.execute("""
        SELECT target_id, relationship_type, strength
        FROM knowledge_relationships
        WHERE source_id = ?
        ORDER BY strength DESC
        LIMIT ?
        """, (knowledge_id, limit))

        results = []
        for row in cursor.fetchall():
            target_vector = self.get_knowledge_vector(row['target_id'])
            if target_vector:
                results.append({
                    'id': row['target_id'],
                    'domain': target_vector.domain,
                    'concept': target_vector.concept,
                    'relationship_type': row['relationship_type'],
                    'strength': row['strength']
                })

        return results

    def export_knowledge_domain(self, domain: str, filepath: str):
        """Export all knowledge for a domain to JSON file"""
        cursor = self.conn.cursor()

        cursor.execute("""
        SELECT id, domain, concept, explanation, metadata, created_at, quality_score, usage_count
        FROM knowledge_vectors
        WHERE domain = ?
        """, (domain,))

        knowledge_items = []
        for row in cursor.fetchall():
            knowledge_items.append({
                'id': row['id'],
                'domain': row['domain'],
                'concept': row['concept'],
                'explanation': row['explanation'],
                'metadata': json.loads(row['metadata']) if row['metadata'] else {},
                'created_at': row['created_at'],
                'quality_score': row['quality_score'],
                'usage_count': row['usage_count']
            })

        with open(filepath, 'w') as f:
            json.dump({
                'export_date': time.time(),
                'domain': domain,
                'knowledge_count': len(knowledge_items),
                'knowledge_vectors': knowledge_items
            }, f, indent=2)

        print(f"✅ Exported {len(knowledge_items)} knowledge vectors for {domain} to {filepath}")

    def close(self):
        """Close database connection"""
        self.conn.close()

# Integration with existing SQLiteVectorBlueprintDB
class KnowledgeEnhancedBlueprintDB:
    """Enhanced blueprint database with knowledge integration"""

    def __init__(self, blueprint_db, knowledge_distiller):
        self.blueprint_db = blueprint_db
        self.knowledge_distiller = knowledge_distiller

    def create_knowledge_enhanced_blueprint(self,
                                          blueprint_data: List[int],
                                          pattern_type: int,
                                          name: str = "",
                                          description: str = "",
                                          domain: str = "General",
                                          concept: str = "Pattern"):
        """Create a blueprint enhanced with domain knowledge"""
        # First create the regular blueprint
        blueprint_id = self.blueprint_db.create_blueprint(
            blueprint_data, pattern_type, name, description
        )

        # Create knowledge vector for this pattern
        knowledge_text = f"{domain} pattern: {concept} - {description}"
        explanation = f"This {concept} pattern represents {description} in the {domain} domain."

        # Use the distiller's embedding method for consistency
        vector_embedding = self.knowledge_distiller._create_embedding(knowledge_text)

        # Store knowledge about this pattern
        knowledge_id = self._store_pattern_knowledge(domain, concept, explanation, vector_embedding)

        # Create relationship between blueprint and knowledge
        self.knowledge_distiller.create_knowledge_relationship(
            knowledge_id, blueprint_id, "represents", 0.9
        )

        return blueprint_id, knowledge_id

    def _store_pattern_knowledge(self, domain: str, concept: str, explanation: str, vector_embedding: np.ndarray) -> str:
        """Store pattern knowledge in the knowledge distiller"""
        # Create knowledge ID
        content_hash = hashlib.md5(f"{domain}:{concept}:{explanation}".encode()).hexdigest()
        knowledge_id = f"pat_{content_hash[:8]}"

        # Store in knowledge database
        cursor = self.knowledge_distiller.conn.cursor()

        metadata = {
            "source": "blueprint_integration",
            "pattern_type": "visual_representation",
            "related_to_blueprint": True
        }

        cursor.execute("""
        INSERT INTO knowledge_vectors
        (id, domain, concept, explanation, vector_embedding, metadata, created_at, source_type)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            knowledge_id,
            domain,
            concept,
            explanation,
            self.knowledge_distiller._serialize_embedding(vector_embedding),
            json.dumps(metadata),
            time.time(),
            "blueprint_knowledge"
        ))

        # Update knowledge index
        knowledge_vector = KnowledgeVector(
            id=knowledge_id,
            domain=domain,
            concept=concept,
            explanation=explanation,
            vector_embedding=vector_embedding,
            metadata=metadata,
            created_at=time.time()
        )

        self.knowledge_distiller.knowledge_index[knowledge_id] = knowledge_vector
        self.knowledge_distiller.conn.commit()

        return knowledge_id

    def search_knowledge_enhanced_blueprints(self, query: str, limit: int = 5) -> List[Dict]:
        """Search blueprints using knowledge-based semantic search"""
        # First search knowledge
        knowledge_results = self.knowledge_distiller.search_knowledge(query, limit=limit)

        # Get related blueprints
        results = []
        for knowledge_result in knowledge_results:
            related_blueprints = self.knowledge_distiller.get_related_knowledge(
                knowledge_result['id']
            )

            for bp_rel in related_blueprints:
                if bp_rel['relationship_type'] == 'represents':
                    # Get blueprint details
                    try:
                        blueprint_data = self.blueprint_db.get_blueprint_data(bp_rel['id'])
                        pattern_type = self.blueprint_db.get_pattern_type(bp_rel['id'])

                        results.append({
                            'blueprint_id': bp_rel['id'],
                            'knowledge_id': knowledge_result['id'],
                            'domain': knowledge_result['domain'],
                            'concept': knowledge_result['concept'],
                            'pattern_type': pattern_type,
                            'rule_count': len(blueprint_data),
                            'similarity': knowledge_result['similarity'],
                            'explanation': knowledge_result['explanation']
                        })
                    except:
                        continue

        return results

# Example usage and testing
async def example_usage():
    """Example of using the KnowledgeDistiller"""
    print("🚀 Starting Knowledge Distiller Example")

    # Initialize distiller
    distiller = KnowledgeDistiller("test_knowledge_substrate.db")

    try:
        # Distill knowledge for Basic Math domain
        knowledge_ids = await distiller.distill_domain("Basic Math", num_concepts=3)

        print(f"📚 Created knowledge vectors: {knowledge_ids}")

        # Search for knowledge
        results = distiller.search_knowledge("What is addition?", domain="Basic Math")
        print(f"🔍 Search results for 'addition': {len(results)} found")

        for result in results:
            print(f"   - {result['concept']}: {result['explanation'][:50]}... (similarity: {result['similarity']:.3f})")

        # Get domain statistics
        stats = distiller.get_domain_statistics("Basic Math")
        print(f"📊 Domain stats: {stats}")

        # Test knowledge relationships
        if len(knowledge_ids) >= 2:
            distiller.create_knowledge_relationship(
                knowledge_ids[0], knowledge_ids[1], "related_concept", 0.7
            )

            related = distiller.get_related_knowledge(knowledge_ids[0])
            print(f"🔗 Related knowledge: {len(related)} relationships")

    finally:
        distiller.close()

if __name__ == "__main__":
    # Run example
    asyncio.run(example_usage())