#!/usr/bin/env python3
"""
Dreamer Agent - Autonomous background process for generating new patterns and tools
"""

import asyncio
import time
import random
import json
import threading
import queue
import sys
import os
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
import uuid
import numpy as np

# Add runtime directory to path for imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from neural_transpiler import NeuralPatternTranspiler
from sqlite_vector_blueprint import SQLiteVectorBlueprintDB

class DreamerAgent:
    """
    Autonomous Dreamer Agent that generates new patterns and tools during idle cycles.

    The Dreamer Agent runs in the background, monitoring system activity and
    creating new capabilities when the system is idle. It implements the
    "Daydream Protocol" for autonomous creativity and evolution.
    """

    def __init__(self,
                 blueprint_db: SQLiteVectorBlueprintDB,
                 neural_transpiler: NeuralPatternTranspiler,
                 activity_threshold: float = 0.3,
                 idle_check_interval: float = 60.0,
                 dream_frequency: float = 300.0):
        """
        Initialize the Dreamer Agent.

        Args:
            blueprint_db: SQLiteVectorBlueprintDB instance
            neural_transpiler: NeuralPatternTranspiler instance
            activity_threshold: System activity level below which dreaming is allowed (0-1)
            idle_check_interval: How often to check for idle state (seconds)
            dream_frequency: Minimum time between dreams (seconds)
        """
        self.blueprint_db = blueprint_db
        self.neural_transpiler = neural_transpiler
        self.activity_threshold = activity_threshold
        self.idle_check_interval = idle_check_interval
        self.dream_frequency = dream_frequency

        # State tracking
        self.last_dream_time = 0
        self.dream_count = 0
        self.running = False
        self.activity_log = []
        self.dream_history = []

        # Dream configuration
        self.dream_topics = [
            "fractal patterns",
            "noise textures",
            "geometric grids",
            "organic shapes",
            "abstract art",
            "mathematical patterns",
            "nature-inspired designs",
            "futuristic interfaces",
            "vintage aesthetics",
            "minimalist designs"
        ]

        # CTRM integration
        self.ctrm = None  # Would be set if CTRM integration is available

        print("🌙 Dreamer Agent initialized - ready to daydream!")

    def start(self):
        """Start the Dreamer Agent background process"""
        if self.running:
            print("⚠️  Dreamer Agent is already running")
            return

        self.running = True
        self.last_dream_time = time.time()

        # Start background thread
        self.thread = threading.Thread(
            target=self._background_loop,
            daemon=True,
            name="DreamerAgent"
        )
        self.thread.start()

        print("🌙 Dreamer Agent started - entering daydream mode")

    def stop(self):
        """Stop the Dreamer Agent"""
        self.running = False
        if hasattr(self, 'thread') and self.thread.is_alive():
            self.thread.join(timeout=5.0)
        print("🌙 Dreamer Agent stopped")

    def _background_loop(self):
        """Main background loop for the Dreamer Agent"""
        print("🌙 Dreamer Agent background loop started")

        while self.running:
            try:
                # Check if system is idle and ready for dreaming
                if self._should_dream():
                    # Run dream cycle in asyncio event loop
                    asyncio.run(self._dream_cycle())

                # Sleep until next check
                time.sleep(self.idle_check_interval)

            except Exception as e:
                print(f"⚠️  Dreamer Agent error: {e}")
                # Wait longer after errors
                time.sleep(max(60.0, self.idle_check_interval * 2))

        print("🌙 Dreamer Agent background loop stopped")

    def _should_dream(self) -> bool:
        """
        Determine if the system is idle and ready for dreaming.

        Returns:
            True if dreaming should occur, False otherwise
        """
        current_time = time.time()

        # Check minimum time between dreams
        time_since_last_dream = current_time - self.last_dream_time
        if time_since_last_dream < self.dream_frequency:
            return False

        # Check system activity (simulated for now)
        system_activity = self._get_system_activity()
        is_idle = system_activity < self.activity_threshold

        if is_idle:
            print(f"🌙 System is idle (activity: {system_activity:.2f}) - ready to dream")
            return True
        else:
            print(f"🌙 System is active (activity: {system_activity:.2f}) - waiting")
            return False

    def _get_system_activity(self) -> float:
        """
        Get current system activity level (0-1).

        In a real implementation, this would monitor:
        - CPU usage
        - Memory usage
        - Network activity
        - User interaction
        - Task queue length

        For now, we simulate it.
        """
        # Simulate activity based on time of day and random factors
        hour = datetime.now().hour
        base_activity = 0.5

        # Lower activity at night (simulate off-hours)
        if 22 <= hour < 6:
            base_activity = 0.2

        # Add some randomness
        activity = base_activity + random.uniform(-0.1, 0.1)
        activity = max(0.0, min(1.0, activity))

        # Log activity for analysis
        self.activity_log.append({
            'timestamp': datetime.now().isoformat(),
            'activity': activity
        })

        # Keep log size manageable
        if len(self.activity_log) > 100:
            self.activity_log = self.activity_log[-100:]

        return activity

    async def _dream_cycle(self):
        """
        Execute a complete dream cycle:
        1. Identify what to dream about
        2. Generate the dream
        3. Store the dream
        4. Update system knowledge
        """
        print("🌙 Starting dream cycle...")

        try:
            # 1. Identify dream topic
            dream_topic = self._identify_dream_topic()
            print(f"🌙 Dreaming about: {dream_topic}")

            # 2. Generate the dream
            dream_result = await self._generate_dream(dream_topic)

            # 3. Store the dream
            storage_result = self._store_dream(dream_result)

            # 4. Update system knowledge
            self._update_knowledge(dream_result, storage_result)

            # Update state
            self.last_dream_time = time.time()
            self.dream_count += 1

            print(f"🌙 Dream cycle completed! Created: {storage_result['blueprint_id']}")

        except Exception as e:
            print(f"⚠️  Dream cycle failed: {e}")

    def _identify_dream_topic(self) -> str:
        """
        Identify what the system should dream about.

        This would analyze:
        - Current system capabilities
        - Missing functionality
        - Usage patterns
        - User preferences
        - System goals

        For now, we select from predefined topics.
        """
        # In a real system, this would be more sophisticated
        # For now, select a random topic or identify gaps

        # Check if we need specific types of patterns
        existing_patterns = self._analyze_existing_patterns()

        # Simple gap analysis
        if existing_patterns.get('fractal', 0) < 2:
            return "complex fractal patterns"
        elif existing_patterns.get('noise', 0) < 2:
            return "smooth gradient noise patterns"
        elif existing_patterns.get('grid', 0) < 2:
            return "geometric grid patterns"
        else:
            # Select a random topic
            return random.choice(self.dream_topics)

    def _analyze_existing_patterns(self) -> Dict[str, int]:
        """
        Analyze existing patterns to identify gaps.

        Returns:
            Dictionary of pattern type counts
        """
        # In a real system, this would query the database and analyze patterns
        # For now, we'll simulate it

        # Get all dream blueprints
        dreams = self.blueprint_db.list_dream_blueprints()

        pattern_counts = {
            'fractal': 0,
            'noise': 0,
            'grid': 0,
            'organic': 0,
            'abstract': 0
        }

        for dream in dreams:
            description = dream['description'].lower()
            if 'fractal' in description:
                pattern_counts['fractal'] += 1
            elif 'noise' in description:
                pattern_counts['noise'] += 1
            elif 'grid' in description:
                pattern_counts['grid'] += 1
            elif 'organic' in description:
                pattern_counts['organic'] += 1
            else:
                pattern_counts['abstract'] += 1

        return pattern_counts

    async def _generate_dream(self, topic: str) -> Dict[str, Any]:
        """
        Generate a dream based on the identified topic.

        Args:
            topic: What to dream about

        Returns:
            Dictionary containing dream information
        """
        # Create a specific description based on the topic
        description = self._create_dream_description(topic)

        print(f"🌙 Generating dream: {description}")

        # Use neural transpiler to generate code
        generated_code = await self.neural_transpiler.transpile(description)

        # Create dream metadata
        dream_result = {
            'topic': topic,
            'description': description,
            'generated_code': generated_code,
            'timestamp': datetime.now().isoformat(),
            'dream_id': f"dream_{uuid.uuid4().hex[:8]}",
            'status': 'generated'
        }

        return dream_result

    def _create_dream_description(self, topic: str) -> str:
        """
        Create a specific description based on the dream topic.

        Args:
            topic: Dream topic

        Returns:
            Detailed description for the neural transpiler
        """
        adjectives = ['chaotic', 'smooth', 'geometric', 'organic', 'abstract',
                     'vibrant', 'minimalist', 'complex', 'elegant', 'futuristic']
        colors = ['neon', 'blue', 'red', 'green', 'purple', 'golden', 'pastel']
        styles = ['fractal', 'noise', 'grid', 'wave', 'particle', 'cellular']

        # Create description based on topic
        if 'fractal' in topic.lower():
            adj = random.choice(adjectives)
            color = random.choice(colors)
            return f"a {adj} {color} fractal pattern"
        elif 'noise' in topic.lower():
            adj = random.choice(adjectives)
            color = random.choice(colors)
            return f"{adj} gradient noise with {color} tones"
        elif 'grid' in topic.lower():
            adj = random.choice(adjectives)
            color = random.choice(colors)
            return f"{adj} geometric grid with {color} lines"
        elif 'organic' in topic.lower():
            adj = random.choice(adjectives)
            return f"{adj} organic shapes with flowing forms"
        else:
            adj1 = random.choice(adjectives)
            adj2 = random.choice(adjectives)
            style = random.choice(styles)
            return f"{adj1} {adj2} {style} pattern"

    async def _store_dream(self, dream_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Store the generated dream in the blueprint database.

        Args:
            dream_result: Dream generation result

        Returns:
            Storage result information
        """
        try:
            # Create blueprint from the dream (async operation)
            blueprint_id, generated_code = await self.blueprint_db.dream_blueprint(
                dream_result['description']
            )

            # Create storage metadata
            storage_result = {
                'blueprint_id': blueprint_id,
                'dream_id': dream_result['dream_id'],
                'description': dream_result['description'],
                'code_length': len(dream_result['generated_code']),
                'timestamp': datetime.now().isoformat(),
                'status': 'stored'
            }

            return storage_result

        except Exception as e:
            print(f"⚠️  Failed to store dream: {e}")
            return {
                'status': 'failed',
                'error': str(e),
                'dream_id': dream_result['dream_id']
            }

    def _update_knowledge(self, dream_result: Dict[str, Any], storage_result: Dict[str, Any]):
        """
        Update system knowledge with the new dream.

        In a real system, this would:
        - Update CTRM with new knowledge
        - Add to system capabilities
        - Notify other agents
        - Log for evolution tracking

        For now, we track in dream history.
        """
        # Add to dream history
        dream_record = {
            'dream_id': dream_result['dream_id'],
            'blueprint_id': storage_result.get('blueprint_id'),
            'topic': dream_result['topic'],
            'description': dream_result['description'],
            'timestamp': datetime.now().isoformat(),
            'status': storage_result['status'],
            'code_length': len(dream_result['generated_code']),
            'system_activity': self._get_system_activity()
        }

        self.dream_history.append(dream_record)

        # Keep history size manageable
        if len(self.dream_history) > 100:
            self.dream_history = self.dream_history[-100:]

        print(f"🌙 Updated knowledge with new dream: {dream_result['description']}")

    def get_dream_stats(self) -> Dict[str, Any]:
        """
        Get statistics about dream activity.

        Returns:
            Dictionary of dream statistics
        """
        if not self.dream_history:
            return {
                'total_dreams': 0,
                'successful_dreams': 0,
                'failed_dreams': 0,
                'avg_code_length': 0,
                'last_dream_time': None
            }

        successful = sum(1 for d in self.dream_history if d['status'] == 'stored')
        failed = sum(1 for d in self.dream_history if d['status'] == 'failed')
        code_lengths = [d['code_length'] for d in self.dream_history if 'code_length' in d]

        return {
            'total_dreams': len(self.dream_history),
            'successful_dreams': successful,
            'failed_dreams': failed,
            'success_rate': successful / len(self.dream_history) if self.dream_history else 0,
            'avg_code_length': sum(code_lengths) / len(code_lengths) if code_lengths else 0,
            'last_dream_time': self.dream_history[-1]['timestamp'] if self.dream_history else None,
            'dream_frequency': self.dream_frequency,
            'idle_threshold': self.activity_threshold
        }

    def get_recent_dreams(self, limit: int = 10) -> List[Dict]:
        """
        Get recent dreams.

        Args:
            limit: Maximum number of dreams to return

        Returns:
            List of recent dream records
        """
        return self.dream_history[-limit:]

    def set_dream_parameters(self,
                           activity_threshold: Optional[float] = None,
                           idle_check_interval: Optional[float] = None,
                           dream_frequency: Optional[float] = None):
        """
        Update dream parameters.

        Args:
            activity_threshold: New activity threshold
            idle_check_interval: New idle check interval
            dream_frequency: New dream frequency
        """
        if activity_threshold is not None:
            self.activity_threshold = activity_threshold
        if idle_check_interval is not None:
            self.idle_check_interval = idle_check_interval
        if dream_frequency is not None:
            self.dream_frequency = dream_frequency

        print(f"🌙 Updated dream parameters: "
              f"activity={self.activity_threshold:.2f}, "
              f"check_interval={self.idle_check_interval:.1f}s, "
              f"frequency={self.dream_frequency:.1f}s")

    async def manual_dream(self, description: str) -> Dict[str, Any]:
        """
        Manually trigger a dream with a specific description.

        Args:
            description: Specific description to dream about

        Returns:
            Dream result information
        """
        print(f"🌙 Manual dream requested: {description}")

        # Generate the dream
        dream_result = {
            'topic': 'manual',
            'description': description,
            'generated_code': await self.neural_transpiler.transpile(description),
            'timestamp': datetime.now().isoformat(),
            'dream_id': f"manual_{uuid.uuid4().hex[:8]}",
            'status': 'generated'
        }

        # Store the dream (async operation)
        storage_result = await self._store_dream(dream_result)

        # Update knowledge
        self._update_knowledge(dream_result, storage_result)

        return {
            'dream_result': dream_result,
            'storage_result': storage_result,
            'status': 'completed'
        }

# Example usage and testing
if __name__ == "__main__":
    import asyncio
    import tempfile
    import os

    async def test_dreamer_agent():
        print("🧪 Testing Dreamer Agent")
        print("=" * 50)

        # Create temporary database
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp_file:
            db_path = tmp_file.name

        try:
            # Initialize components
            neural_transpiler = NeuralPatternTranspiler()
            blueprint_db = SQLiteVectorBlueprintDB(db_path=db_path, neural_transpiler=neural_transpiler)

            # Create Dreamer Agent
            dreamer = DreamerAgent(
                blueprint_db=blueprint_db,
                neural_transpiler=neural_transpiler,
                activity_threshold=0.5,
                idle_check_interval=10.0,
                dream_frequency=15.0
            )

            # Test manual dream
            print("\n🌙 Testing manual dream...")
            result = await dreamer.manual_dream("a vibrant fractal pattern")
            print(f"✅ Manual dream completed: {result['storage_result']['blueprint_id']}")

            # Test another manual dream
            print("\n🌙 Testing another manual dream...")
            result2 = await dreamer.manual_dream("smooth blue gradient noise")
            print(f"✅ Manual dream completed: {result2['storage_result']['blueprint_id']}")

            # Get dream stats
            print("\n📊 Dream statistics:")
            stats = dreamer.get_dream_stats()
            for key, value in stats.items():
                print(f"  {key}: {value}")

            # Get recent dreams
            print("\n📋 Recent dreams:")
            recent = dreamer.get_recent_dreams(5)
            for dream in recent:
                print(f"  - {dream['dream_id']}: {dream['description']}")

            # Test background operation (short duration)
            print("\n🌙 Testing background operation...")
            dreamer.start()
            time.sleep(20)  # Let it run for a short time
            dreamer.stop()

            # Final stats
            print("\n📊 Final dream statistics:")
            final_stats = dreamer.get_dream_stats()
            for key, value in final_stats.items():
                print(f"  {key}: {value}")

            print("\n🎉 Dreamer Agent test completed successfully!")

        except Exception as e:
            print(f"❌ Test failed: {e}")
            import traceback
            traceback.print_exc()

        finally:
            # Cleanup
            blueprint_db.close()
            if os.path.exists(db_path):
                os.unlink(db_path)

    # Run test
    asyncio.run(test_dreamer_agent())