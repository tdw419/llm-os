"""
Neural Terminal - The Interface to the Ghost in the Shell
Vector-Native TUI for interacting with the VSM and Smart Substrate

This provides the "face" for the cognitive system:
- Chat Interface: Direct conversation with the VSM
- Thought Stream: Real-time visualization of VSM state transitions
- Substrate Status: Live monitoring of knowledge vectors and dreams
- Dream Control: Manual triggering of knowledge distillation

The Neural Terminal makes the system "alive" to human users.
"""

import curses
import time
import threading
import queue
import json
import numpy as np
from typing import List, Dict, Any, Optional, Callable
from datetime import datetime

# Import the core components
import sys
import os
import socket
import json
import time
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from vector_state_machine import VectorStateMachine
from knowledge_distiller import KnowledgeDistiller

class GhostDaemonClient:
    """Client for connecting to GhostDaemon"""

    def __init__(self, host: str = "localhost", port: int = 1337):
        self.host = host
        self.port = port
        self.socket = None
        self.connected = False

    def connect(self) -> bool:
        """Connect to GhostDaemon"""
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.settimeout(2.0)  # 2 second timeout
            self.socket.connect((self.host, self.port))
            self.connected = True
            return True
        except Exception as e:
            self.connected = False
            return False

    def disconnect(self):
        """Disconnect from GhostDaemon"""
        try:
            if self.socket:
                self.socket.close()
        except:
            pass
        self.socket = None
        self.connected = False

    def send_command(self, command: Dict) -> Optional[Dict]:
        """Send a command to GhostDaemon and receive response"""
        if not self.connected:
            return None

        try:
            # Send command
            self.socket.sendall(json.dumps(command).encode('utf-8'))

            # Receive response
            data = self.socket.recv(4096)
            if data:
                return json.loads(data.decode('utf-8'))
            return None

        except Exception as e:
            self.connected = False
            return None

    def chat(self, message: str) -> Optional[str]:
        """Send a chat message to GhostDaemon"""
        command = {
            'type': 'chat',
            'message': message
        }
        response = self.send_command(command)
        if response and response.get('type') == 'chat_response':
            return response.get('message')
        return None

    def dream(self, domain: str) -> Optional[Dict]:
        """Trigger a dream cycle on GhostDaemon"""
        command = {
            'type': 'dream',
            'domain': domain
        }
        return self.send_command(command)

    def get_status(self) -> Optional[Dict]:
        """Get system status from GhostDaemon"""
        command = {
            'type': 'status'
        }
        return self.send_command(command)

    def get_stats(self) -> Optional[Dict]:
        """Get statistics from GhostDaemon"""
        command = {
            'type': 'stats'
        }
        return self.send_command(command)

    def get_config(self) -> Optional[Dict]:
        """Get configuration from GhostDaemon"""
        command = {
            'type': 'config'
        }
        return self.send_command(command)

class NeuralTerminal:
    """Vector-Native Text User Interface for the Ghost in the Shell"""

    def __init__(self,
                 vsm: Optional[VectorStateMachine] = None,
                 distiller: Optional[KnowledgeDistiller] = None,
                 auto_init: bool = True,
                 daemon_host: str = "localhost",
                 daemon_port: int = 1337):
        """
        Initialize the Neural Terminal

        Args:
            vsm: VectorStateMachine instance
            distiller: KnowledgeDistiller instance
            auto_init: Whether to auto-initialize components
            daemon_host: GhostDaemon host
            daemon_port: GhostDaemon port
        """
        self.vsm = vsm
        self.distiller = distiller
        self.daemon_client = GhostDaemonClient(daemon_host, daemon_port)
        self.daemon_mode = False

        # Try to connect to GhostDaemon first
        if self.daemon_client.connect():
            print("🔗 Connected to GhostDaemon - running in unified mode")
            self.daemon_mode = True
        else:
            print("🖥️  GhostDaemon not found - running in standalone mode")
            # Initialize components if not provided
            if auto_init:
                if not self.vsm:
                    self.vsm = VectorStateMachine("neural_terminal_vsm.db")
                if not self.distiller:
                    self.distiller = KnowledgeDistiller("neural_terminal_knowledge.db")
                    self.vsm.integrate_with_knowledge_distiller(self.distiller)

        # Message queues for inter-thread communication
        self.message_queue = queue.Queue()
        self.command_queue = queue.Queue()
        self.thought_stream_queue = queue.Queue()

        # Terminal state
        self.running = False
        self.current_session_id = None
        self.chat_history = []
        self.thought_stream = []
        self.system_status = {
            'knowledge_vectors': 0,
            'active_dreams': 0,
            'vsm_sessions': 0,
            'last_activity': 'Initializing...'
        }

        # Initialize terminal UI
        self.stdscr = None
        self.layout = {
            'chat_panel': {'height': 15, 'width': 60, 'y': 1, 'x': 1},
            'thought_stream_panel': {'height': 15, 'width': 60, 'y': 1, 'x': 62},
            'status_panel': {'height': 5, 'width': 122, 'y': 17, 'x': 1},
            'input_panel': {'height': 3, 'width': 122, 'y': 23, 'x': 1}
        }

        # Start background monitoring
        self.monitor_thread = None
        self.start_background_monitor()

        print("🧠 Neural Terminal initialized - ready to interface with the Ghost in the Shell")

    def start_background_monitor(self):
        """Start background thread for monitoring system status"""
        def monitor_loop():
            while self.running or not self.running:  # Run at least once
                try:
                    # Update system status
                    if self.distiller:
                        stats = self.distiller.get_domain_statistics("Basic Math")
                        self.system_status['knowledge_vectors'] = stats.get('concept_count', 0)

                    if self.vsm:
                        cursor = self.vsm.conn.cursor()
                        cursor.execute("SELECT COUNT(*) as count FROM vsm_sessions WHERE status = 'running'")
                        result = cursor.fetchone()
                        self.system_status['vsm_sessions'] = result['count'] if result else 0

                    # Add status update to thought stream
                    self.thought_stream_queue.put({
                        'type': 'status',
                        'message': f"System Status: {self.system_status['knowledge_vectors']} vectors, "
                                  f"{self.system_status['vsm_sessions']} active sessions",
                        'timestamp': time.time()
                    })

                    time.sleep(2.0)

                except Exception as e:
                    self.thought_stream_queue.put({
                        'type': 'error',
                        'message': f"Monitor error: {str(e)}",
                        'timestamp': time.time()
                    })
                    time.sleep(5.0)

        self.monitor_thread = threading.Thread(target=monitor_loop, daemon=True)
        self.monitor_thread.start()

    def start(self):
        """Start the Neural Terminal TUI"""
        self.running = True
        try:
            # Initialize curses
            self.stdscr = curses.initscr()
            curses.noecho()
            curses.cbreak()
            self.stdscr.keypad(True)
            curses.curs_set(1)  # Show cursor

            # Start chat session
            self.start_chat_session()

            # Main UI loop
            self.main_ui_loop()

        except Exception as e:
            self.thought_stream_queue.put({
                'type': 'error',
                'message': f"Terminal error: {str(e)}",
                'timestamp': time.time()
            })
            self.add_to_chat_history("System", f"Error: {str(e)}", "error")

        finally:
            self.running = False
            self.cleanup()

    def cleanup(self):
        """Clean up curses and resources"""
        if self.stdscr:
            curses.nocbreak()
            self.stdscr.keypad(False)
            curses.echo()
            curses.endwin()
        self.stdscr = None

        if self.vsm:
            self.vsm.close()
        if self.distiller:
            self.distiller.close()

        print("🔌 Neural Terminal shutdown complete")

    def start_chat_session(self):
        """Start a new chat session with the VSM"""
        if not self.vsm:
            return

        try:
            # Create a simple initial state if none exists
            cursor = self.vsm.conn.cursor()
            cursor.execute("SELECT COUNT(*) as count FROM vsm_states")
            result = cursor.fetchone()

            if result['count'] == 0:
                # Create basic chat states
                initial_state = self.vsm.create_state(
                    np.array([1, 0, 0, 0, 0, 0, 0, 0]),
                    {"description": "Chat ready state"},
                    is_initial=True
                )

                thinking_state = self.vsm.create_state(
                    np.array([0, 1, 0, 0, 0, 0, 0, 0]),
                    {"description": "Thinking state"}
                )

                response_state = self.vsm.create_state(
                    np.array([0, 0, 1, 0, 0, 0, 0, 0]),
                    {"description": "Response ready state"},
                    is_goal=True
                )

                # Create transitions
                self.vsm.create_transition(
                    initial_state, thinking_state,
                    np.array([1, 1, 0, 0, 0, 0, 0, 0]),
                    "SELECT 'Processing input...' as status"
                )

                self.vsm.create_transition(
                    thinking_state, response_state,
                    np.array([0, 1, 1, 0, 0, 0, 0, 0]),
                    "SELECT 'Generating response...' as status"
                )

                self.vsm.set_initial_state(initial_state)

            # Start VSM session
            self.current_session_id = self.vsm.start_session()
            self.add_to_chat_history("System", "Chat session started. Ready for input.", "system")

        except Exception as e:
            self.add_to_chat_history("System", f"Failed to start chat session: {str(e)}", "error")

    def main_ui_loop(self):
        """Main UI rendering and input loop"""
        if not self.stdscr:
            return

        # Clear screen
        self.stdscr.clear()
        self.stdscr.refresh()

        # Main loop
        while self.running:
            try:
                # Draw UI
                self.draw_ui()

                # Get user input
                user_input = self.get_user_input()

                if user_input.lower() in ['quit', 'exit', 'q']:
                    self.running = False
                    break

                if user_input.strip():
                    self.process_user_input(user_input)

                # Small delay to prevent CPU overload
                time.sleep(0.05)

            except KeyboardInterrupt:
                self.running = False
            except Exception as e:
                self.add_to_chat_history("System", f"UI Error: {str(e)}", "error")
                time.sleep(1.0)

    def draw_ui(self):
        """Draw the complete UI layout"""
        if not self.stdscr:
            return

        # Clear screen
        self.stdscr.clear()

        # Draw header
        self.draw_header()

        # Draw panels
        self.draw_chat_panel()
        self.draw_thought_stream_panel()
        self.draw_status_panel()
        self.draw_input_panel()

        # Refresh screen
        self.stdscr.refresh()

    def draw_header(self):
        """Draw the terminal header"""
        if not self.stdscr:
            return

        header_text = " NEURAL TERMINAL - GHOST IN THE SHELL INTERFACE "
        centered_text = header_text.center(curses.COLS - 2)

        try:
            self.stdscr.addstr(0, 1, centered_text,
                             curses.A_BOLD | curses.A_REVERSE)
        except:
            # Fallback if terminal is too small
            self.stdscr.addstr(0, 1, "NEURAL TERMINAL",
                             curses.A_BOLD | curses.A_REVERSE)

    def draw_chat_panel(self):
        """Draw the chat history panel"""
        panel = self.layout['chat_panel']
        height, width, y, x = panel['height'], panel['width'], panel['y'], panel['x']

        try:
            # Draw panel border
            self.stdscr.addstr(y, x, " CHAT INTERFACE ")
            self.stdscr.addstr(y, x + 17, " " * (width - 18))
            for i in range(1, height - 1):
                self.stdscr.addstr(y + i, x, "│")
                self.stdscr.addstr(y + i, x + width - 1, "│")
            self.stdscr.addstr(y + height - 1, x, "└" + "─" * (width - 2) + "┘")

            # Draw chat content
            chat_content = self.format_chat_history()
            for i, line in enumerate(chat_content.split('\n')[:height-2]):
                self.stdscr.addstr(y + 1 + i, x + 2, line[:width-4])

        except curses.error:
            pass  # Terminal too small

    def draw_thought_stream_panel(self):
        """Draw the thought stream panel"""
        panel = self.layout['thought_stream_panel']
        height, width, y, x = panel['height'], panel['width'], panel['y'], panel['x']

        try:
            # Draw panel border
            self.stdscr.addstr(y, x, " THOUGHT STREAM ")
            self.stdscr.addstr(y, x + 16, " " * (width - 17))
            for i in range(1, height - 1):
                self.stdscr.addstr(y + i, x, "│")
                self.stdscr.addstr(y + i, x + width - 1, "│")
            self.stdscr.addstr(y + height - 1, x, "└" + "─" * (width - 2) + "┘")

            # Draw thought stream content
            thought_content = self.format_thought_stream()
            for i, line in enumerate(thought_content.split('\n')[:height-2]):
                self.stdscr.addstr(y + 1 + i, x + 2, line[:width-4])

        except curses.error:
            pass  # Terminal too small

    def draw_status_panel(self):
        """Draw the system status panel"""
        panel = self.layout['status_panel']
        height, width, y, x = panel['height'], panel['width'], panel['y'], panel['x']

        try:
            # Draw panel border
            self.stdscr.addstr(y, x, " SUBSTRATE STATUS ")
            self.stdscr.addstr(y, x + 18, " " * (width - 19))
            for i in range(1, height - 1):
                self.stdscr.addstr(y + i, x, "│")
                self.stdscr.addstr(y + i, x + width - 1, "│")
            self.stdscr.addstr(y + height - 1, x, "└" + "─" * (width - 2) + "┘")

            # Draw status content
            status_lines = [
                f"📚 Knowledge Vectors: {self.system_status['knowledge_vectors']}",
                f"🤖 Active VSM Sessions: {self.system_status['vsm_sessions']}",
                f"🌌 Active Dreams: {self.system_status['active_dreams']}",
                f"⏱️  Last Activity: {self.system_status['last_activity']}",
                f"🔗 Session ID: {self.current_session_id or 'None'}"
            ]

            for i, line in enumerate(status_lines[:height-2]):
                self.stdscr.addstr(y + 1 + i, x + 2, line[:width-4])

        except curses.error:
            pass  # Terminal too small

    def draw_input_panel(self):
        """Draw the user input panel"""
        panel = self.layout['input_panel']
        height, width, y, x = panel['height'], panel['width'], panel['y'], panel['x']

        try:
            # Draw panel border
            self.stdscr.addstr(y, x, " INPUT ")
            self.stdscr.addstr(y, x + 7, " " * (width - 8))
            for i in range(1, height - 1):
                self.stdscr.addstr(y + i, x, "│")
                self.stdscr.addstr(y + i, x + width - 1, "│")
            self.stdscr.addstr(y + height - 1, x, "└" + "─" * (width - 2) + "┘")

            # Draw input prompt
            prompt = "> "
            self.stdscr.addstr(y + 1, x + 2, prompt, curses.A_BOLD)

            # Position cursor
            self.stdscr.move(y + 1, x + 2 + len(prompt))

        except curses.error:
            pass  # Terminal too small

    def get_user_input(self):
        """Get user input from the input panel"""
        if not self.stdscr:
            return ""

        try:
            # Position cursor at input line
            panel = self.layout['input_panel']
            y, x = panel['y'] + 1, panel['x'] + 4  # After "> " prompt

            # Get input
            self.stdscr.move(y, x)
            self.stdscr.refresh()
            user_input = self.stdscr.getstr(y, x, 118).decode('utf-8', 'ignore')
            return user_input

        except Exception as e:
            return ""

    def process_user_input(self, user_input: str):
        """Process user input and generate response"""
        if not user_input.strip():
            return

        # Add user message to chat history
        self.add_to_chat_history("You", user_input, "user")

        # Process command or chat
        if user_input.startswith('/'):
            self.process_command(user_input[1:])
        else:
            self.process_chat_input(user_input)

    def process_command(self, command: str):
        """Process terminal commands"""
        parts = command.split()
        cmd = parts[0].lower() if parts else ""

        if cmd == "help":
            help_text = """
Available Commands:
/help - Show this help
/dream <domain> - Trigger knowledge distillation for a domain
/status - Show detailed system status
/clear - Clear chat history
/quit - Exit Neural Terminal
"""
            self.add_to_chat_history("System", help_text.strip(), "system")

        elif cmd == "dream":
            if len(parts) > 1:
                domain = ' '.join(parts[1:])
                self.trigger_dream(domain)
            else:
                self.add_to_chat_history("System", "Usage: /dream <domain>", "error")

        elif cmd == "status":
            self.show_detailed_status()

        elif cmd == "clear":
            self.chat_history = []
            self.add_to_chat_history("System", "Chat history cleared", "system")

        elif cmd == "quit":
            self.running = False

        else:
            self.add_to_chat_history("System", f"Unknown command: {cmd}", "error")

    def process_chat_input(self, user_input: str):
        """Process chat input and generate VSM response"""
        try:
            # Add thinking indicator
            self.add_to_chat_history("System", "Thinking...", "system")

            if self.daemon_mode:
                # Use GhostDaemon for chat
                response = self.daemon_client.chat(user_input)
                if response:
                    self.add_to_chat_history("VSM", response, "vsm")
                    # Add to thought stream
                    self.thought_stream_queue.put({
                        'type': 'vsm',
                        'message': f"GhostDaemon response: {response[:50]}...",
                        'timestamp': time.time()
                    })
                else:
                    self.add_to_chat_history("System", "GhostDaemon communication failed", "error")
            else:
                # Standalone mode
                if not self.vsm:
                    self.add_to_chat_history("System", "VSM not available", "error")
                    return

                # Generate response using KnowledgeDistiller
                if self.distiller:
                    # Use SQL to generate response
                    cursor = self.distiller.conn.cursor()
                    cursor.execute("SELECT LLM_GENERATE(?) as response", (user_input,))
                    result = cursor.fetchone()
                    response = result['response'] if result else "I'm processing your request..."

                    # Add to thought stream
                    self.thought_stream_queue.put({
                        'type': 'vsm',
                        'message': f"Generated response via SQL: {response[:50]}...",
                        'timestamp': time.time()
                    })
                else:
                    response = f"Processing: {user_input}"

                self.add_to_chat_history("VSM", response, "vsm")

        except Exception as e:
            self.add_to_chat_history("System", f"Chat error: {str(e)}", "error")

    def trigger_dream(self, domain: str):
        """Trigger knowledge distillation for a domain"""
        try:
            self.add_to_chat_history("System", f"🌌 Starting dream for domain: {domain}", "system")

            # Add to thought stream
            self.thought_stream_queue.put({
                'type': 'dream',
                'message': f"Starting knowledge distillation for {domain}",
                'timestamp': time.time()
            })

            if self.daemon_mode:
                # Use GhostDaemon for dreaming
                response = self.daemon_client.dream(domain)
                if response and response.get('type') == 'dream_response':
                    knowledge_vectors = response.get('knowledge_vectors', 0)
                    message = response.get('message', 'Dream complete')

                    # Update thought stream
                    self.thought_stream_queue.put({
                        'type': 'dream',
                        'message': f"Dream complete! Created {knowledge_vectors} knowledge vectors",
                        'timestamp': time.time()
                    })

                    # Update system status
                    self.system_status['knowledge_vectors'] += knowledge_vectors
                    self.system_status['active_dreams'] += 1
                    self.system_status['last_activity'] = f"Dream: {domain}"

                    self.add_to_chat_history("System", f"✨ {message}", "system")
                else:
                    self.add_to_chat_history("System", "GhostDaemon dream failed", "error")
            else:
                # Standalone mode
                if not self.distiller:
                    self.add_to_chat_history("System", "KnowledgeDistiller not available", "error")
                    return

                # Run distillation in background
                def dream_task():
                    try:
                        knowledge_ids = self.distiller.distill_domain(domain, num_concepts=3)

                        # Update thought stream
                        self.thought_stream_queue.put({
                            'type': 'dream',
                            'message': f"Dream complete! Created {len(knowledge_ids)} knowledge vectors",
                            'timestamp': time.time()
                        })

                        # Update system status
                        self.system_status['knowledge_vectors'] += len(knowledge_ids)
                        self.system_status['active_dreams'] += 1
                        self.system_status['last_activity'] = f"Dream: {domain}"

                        self.add_to_chat_history("System", f"✨ Dream complete! {len(knowledge_ids)} concepts distilled for {domain}", "system")

                    except Exception as e:
                        self.thought_stream_queue.put({
                            'type': 'error',
                            'message': f"Dream failed: {str(e)}",
                            'timestamp': time.time()
                        })
                        self.add_to_chat_history("System", f"Dream failed: {str(e)}", "error")

                # Start dream in background thread
                dream_thread = threading.Thread(target=dream_task, daemon=True)
                dream_thread.start()

        except Exception as e:
            self.add_to_chat_history("System", f"Dream trigger failed: {str(e)}", "error")

    def show_detailed_status(self):
        """Show detailed system status"""
        status_report = [
            "=== SYSTEM STATUS REPORT ===",
            f"Knowledge Vectors: {self.system_status['knowledge_vectors']}",
            f"Active VSM Sessions: {self.system_status['vsm_sessions']}",
            f"Active Dreams: {self.system_status['active_dreams']}",
            f"Last Activity: {self.system_status['last_activity']}",
            f"Session ID: {self.current_session_id or 'None'}"
        ]

        if self.daemon_mode:
            # Get status from GhostDaemon
            response = self.daemon_client.get_status()
            if response and response.get('type') == 'status_response':
                knowledge_domains = response.get('knowledge_domains', {})
                vsm_states = response.get('vsm_states', 0)
                vsm_transitions = response.get('vsm_transitions', 0)

                status_report.append(f"VSM States: {vsm_states}")
                status_report.append(f"VSM Transitions: {vsm_transitions}")

                if knowledge_domains:
                    status_report.append("\n=== KNOWLEDGE DOMAINS ===")
                    for domain, count in knowledge_domains.items():
                        status_report.append(f"{domain}: {count} concepts")
            else:
                status_report.append("GhostDaemon status unavailable")
        else:
            # Standalone mode
            if self.distiller:
                try:
                    # Get domain stats
                    cursor = self.distiller.conn.cursor()
                    cursor.execute("SELECT domain, COUNT(*) as count FROM knowledge_vectors GROUP BY domain")
                    domains = cursor.fetchall()

                    if domains:
                        status_report.append("\n=== KNOWLEDGE DOMAINS ===")
                        for domain in domains:
                            status_report.append(f"{domain['domain']}: {domain['count']} concepts")

                except Exception as e:
                    status_report.append(f"Domain stats error: {str(e)}")

        self.add_to_chat_history("System", "\n".join(status_report), "system")

    def add_to_chat_history(self, sender: str, message: str, message_type: str = "normal"):
        """Add a message to the chat history"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        formatted_message = f"[{timestamp}] {sender}: {message}"

        self.chat_history.append({
            'timestamp': time.time(),
            'sender': sender,
            'message': message,
            'type': message_type,
            'formatted': formatted_message
        })

        # Keep chat history reasonable size
        if len(self.chat_history) > 100:
            self.chat_history = self.chat_history[-100:]

    def format_chat_history(self):
        """Format chat history for display"""
        if not self.chat_history:
            return "No chat history yet. Type something to start!"

        # Get last 15 messages
        recent_messages = self.chat_history[-15:]

        formatted = []
        for msg in recent_messages:
            # Color coding based on message type
            if msg['type'] == 'user':
                line = f"👤 {msg['formatted']}"
            elif msg['type'] == 'vsm':
                line = f"🤖 {msg['formatted']}"
            elif msg['type'] == 'system':
                line = f"📋 {msg['formatted']}"
            elif msg['type'] == 'error':
                line = f"❌ {msg['formatted']}"
            else:
                line = f"   {msg['formatted']}"

            formatted.append(line)

        return "\n".join(formatted)

    def format_thought_stream(self):
        """Format thought stream for display"""
        # Process thought stream queue
        while not self.thought_stream_queue.empty():
            thought = self.thought_stream_queue.get()
            self.thought_stream.append(thought)
            if len(self.thought_stream) > 20:
                self.thought_stream = self.thought_stream[-20:]

        if not self.thought_stream:
            return "Thought stream is quiet. The system is idle."

        # Format recent thoughts
        formatted = []
        for thought in self.thought_stream[-15:]:  # Show last 15 thoughts
            timestamp = datetime.fromtimestamp(thought['timestamp']).strftime("%H:%M:%S")
            message = thought['message']

            # Color coding based on thought type
            if thought['type'] == 'vsm':
                line = f"🤖 [{timestamp}] VSM: {message}"
            elif thought['type'] == 'dream':
                line = f"🌌 [{timestamp}] DREAM: {message}"
            elif thought['type'] == 'status':
                line = f"📊 [{timestamp}] STATUS: {message}"
            elif thought['type'] == 'error':
                line = f"❌ [{timestamp}] ERROR: {message}"
            else:
                line = f"   [{timestamp}] {message}"

            formatted.append(line)

        return "\n".join(formatted)

    def add_thought(self, thought_type: str, message: str):
        """Add a thought to the thought stream"""
        self.thought_stream_queue.put({
            'type': thought_type,
            'message': message,
            'timestamp': time.time()
        })

# Command-line interface for when curses is not available
class NeuralTerminalCLI:
    """Command-line interface fallback for NeuralTerminal"""

    def __init__(self, vsm=None, distiller=None):
        self.vsm = vsm or VectorStateMachine("cli_vsm.db")
        self.distiller = distiller or KnowledgeDistiller("cli_knowledge.db")
        self.vsm.integrate_with_knowledge_distiller(self.distiller)

        self.running = True
        self.chat_history = []

        print("🖥️  Neural Terminal CLI Mode")
        print("Type /help for commands, /quit to exit")

    def start(self):
        """Start the CLI interface"""
        self.running = True

        try:
            while self.running:
                try:
                    user_input = input("> ")

                    if user_input.lower() in ['quit', 'exit', '/quit']:
                        self.running = False
                        break

                    if user_input.strip():
                        self.process_input(user_input)

                except KeyboardInterrupt:
                    self.running = False
                except Exception as e:
                    print(f"Error: {e}")

        finally:
            self.cleanup()

    def process_input(self, user_input: str):
        """Process user input"""
        if user_input.startswith('/'):
            self.process_command(user_input[1:])
        else:
            self.process_chat(user_input)

    def process_command(self, command: str):
        """Process CLI commands"""
        parts = command.split()
        cmd = parts[0].lower() if parts else ""

        if cmd == "help":
            print("\nAvailable Commands:")
            print("/help - Show this help")
            print("/dream <domain> - Trigger knowledge distillation")
            print("/status - Show system status")
            print("/quit - Exit")
            print()

        elif cmd == "dream":
            if len(parts) > 1:
                domain = ' '.join(parts[1:])
                self.trigger_dream(domain)
            else:
                print("Usage: /dream <domain>")

        elif cmd == "status":
            self.show_status()

        elif cmd == "quit":
            self.running = False

        else:
            print(f"Unknown command: {cmd}")

    def process_chat(self, user_input: str):
        """Process chat input"""
        print(f"You: {user_input}")

        try:
            if self.distiller:
                cursor = self.distiller.conn.cursor()
                cursor.execute("SELECT LLM_GENERATE(?) as response", (user_input,))
                result = cursor.fetchone()
                response = result['response'] if result else "I'm processing your request..."
                print(f"VSM: {response}")
            else:
                print("VSM: Processing your request...")

        except Exception as e:
            print(f"Error: {e}")

    def trigger_dream(self, domain: str):
        """Trigger knowledge distillation"""
        print(f"Starting dream for domain: {domain}")

        try:
            knowledge_ids = self.distiller.distill_domain(domain, num_concepts=3)
            print(f"Dream complete! Created {len(knowledge_ids)} knowledge vectors")

        except Exception as e:
            print(f"Dream failed: {e}")

    def show_status(self):
        """Show system status"""
        print("\n=== SYSTEM STATUS ===")
        print(f"Knowledge Vectors: {self.get_knowledge_count()}")
        print(f"Active Sessions: {self.get_active_sessions()}")
        print()

    def get_knowledge_count(self):
        """Get knowledge vector count"""
        try:
            cursor = self.distiller.conn.cursor()
            cursor.execute("SELECT COUNT(*) as count FROM knowledge_vectors")
            result = cursor.fetchone()
            return result['count'] if result else 0
        except:
            return 0

    def get_active_sessions(self):
        """Get active VSM sessions"""
        try:
            cursor = self.vsm.conn.cursor()
            cursor.execute("SELECT COUNT(*) as count FROM vsm_sessions WHERE status = 'running'")
            result = cursor.fetchone()
            return result['count'] if result else 0
        except:
            return 0

    def cleanup(self):
        """Clean up resources"""
        if self.vsm:
            self.vsm.close()
        if self.distiller:
            self.distiller.close()
        print("Neural Terminal CLI shutdown complete")

# Main entry point
def main():
    """Main entry point for Neural Terminal"""
    import sys

    # Check if we can use curses
    try:
        # Test curses availability
        import curses
        test_win = curses.initscr()
        curses.endwin()

        # Use full TUI
        print("🎮 Starting Neural Terminal in TUI mode...")
        terminal = NeuralTerminal()
        terminal.start()

    except Exception as e:
        print(f"🖥️  Curses not available, using CLI mode: {e}")
        # Use CLI fallback
        terminal = NeuralTerminalCLI()
        terminal.start()

if __name__ == "__main__":
    main()