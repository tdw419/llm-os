"""
Vector State Machine - The Engine Room
SQL-driven cogitation loops for the Smart Substrate

This implements the "Ghost in the Shell" trifecta:
1. KnowledgeDistiller (Holographic Transfer)
2. Smart Substrate (SQL-native LLM integration)
3. VectorStateMachine (Cognitive engine)

The VSM runs loops of SQL queries to drive problem-solving:
SELECT next_state FROM transitions WHERE COSINE_SIMILARITY(from_vector, ?) > 0.8
"""

import sqlite3
import json
import numpy as np
import pickle
import time
from typing import List, Dict, Any, Optional, Tuple, Callable
from dataclasses import dataclass
import hashlib
import asyncio

@dataclass
class VectorState:
    """Represents a state in the vector state machine"""
    state_id: str
    state_vector: np.ndarray
    metadata: Dict[str, Any]
    created_at: float
    confidence: float = 1.0

@dataclass
class VectorTransition:
    """Represents a transition between states"""
    transition_id: str
    from_state: str
    to_state: str
    condition_vector: np.ndarray
    action_sql: str
    probability: float
    metadata: Dict[str, Any]

class VectorStateMachine:
    """SQL-driven cognitive engine for the Smart Substrate"""

    def __init__(self, db_path: str = "vsm_substrate.db", knowledge_distiller=None):
        """
        Initialize Vector State Machine

        Args:
            db_path: Path to SQLite database for VSM state management
            knowledge_distiller: Optional KnowledgeDistiller for integration
        """
        self.db_path = db_path
        self.knowledge_distiller = knowledge_distiller

        # Initialize database connection
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row

        # Enable WAL mode for better concurrency (multiple readers, one writer)
        self.conn.execute("PRAGMA journal_mode=WAL;")
        self.conn.execute("PRAGMA synchronous=NORMAL;")
        self.conn.execute("PRAGMA busy_timeout=5000;")

        # Initialize database schema
        self._init_database()

        # Register SQL UDFs for vector operations
        self._register_vsm_udfs()

        # State management
        self.current_state = None
        self.state_history = []
        self.transition_log = []

        print(f"🤖 Vector State Machine initialized with database: {db_path}")

    def _init_database(self):
        """Initialize VSM database schema"""
        cursor = self.conn.cursor()

        # States table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS vsm_states (
            state_id TEXT PRIMARY KEY,
            state_vector BLOB NOT NULL,
            metadata TEXT,
            created_at REAL,
            confidence REAL DEFAULT 1.0,
            is_initial BOOLEAN DEFAULT 0,
            is_goal BOOLEAN DEFAULT 0
        )
        """)

        # Transitions table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS vsm_transitions (
            transition_id TEXT PRIMARY KEY,
            from_state TEXT NOT NULL,
            to_state TEXT NOT NULL,
            condition_vector BLOB,
            action_sql TEXT,
            probability REAL DEFAULT 1.0,
            metadata TEXT,
            created_at REAL,
            FOREIGN KEY (from_state) REFERENCES vsm_states(state_id),
            FOREIGN KEY (to_state) REFERENCES vsm_states(state_id)
        )
        """)

        # Execution history
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS vsm_execution_history (
            execution_id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT,
            step_number INTEGER,
            from_state TEXT,
            to_state TEXT,
            transition_id TEXT,
            timestamp REAL,
            metadata TEXT,
            FOREIGN KEY (from_state) REFERENCES vsm_states(state_id),
            FOREIGN KEY (to_state) REFERENCES vsm_states(state_id),
            FOREIGN KEY (transition_id) REFERENCES vsm_transitions(transition_id)
        )
        """)

        # Sessions table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS vsm_sessions (
            session_id TEXT PRIMARY KEY,
            initial_state TEXT,
            current_state TEXT,
            start_time REAL,
            end_time REAL,
            status TEXT,
            metadata TEXT,
            FOREIGN KEY (initial_state) REFERENCES vsm_states(state_id),
            FOREIGN KEY (current_state) REFERENCES vsm_states(state_id)
        )
        """)

        # Create indices
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_vsm_from_state ON vsm_transitions(from_state)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_vsm_to_state ON vsm_transitions(to_state)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_vsm_session_status ON vsm_sessions(status)")

        self.conn.commit()
        print("📊 Vector State Machine database schema initialized")

    def _register_vsm_udfs(self):
        """Register SQLite UDFs for vector state machine operations"""

        def vsm_cosine_similarity(a_blob, b_blob):
            """Calculate cosine similarity between two vector blobs"""
            try:
                a = pickle.loads(a_blob)
                b = pickle.loads(b_blob)
                norm_a = np.linalg.norm(a)
                norm_b = np.linalg.norm(b)
                if norm_a == 0 or norm_b == 0:
                    return 0.0
                return float(np.dot(a, b) / (norm_a * norm_b))
            except Exception as e:
                return 0.0

        def vsm_vector_distance(a_blob, b_blob):
            """Calculate Euclidean distance between two vectors"""
            try:
                a = pickle.loads(a_blob)
                b = pickle.loads(b_blob)
                return float(np.linalg.norm(a - b))
            except Exception as e:
                return 1.0

        def vsm_vector_magnitude(vector_blob):
            """Calculate magnitude of a vector"""
            try:
                vector = pickle.loads(vector_blob)
                return float(np.linalg.norm(vector))
            except Exception as e:
                return 0.0

        def vsm_state_achieved(state_id):
            """Check if a state has been achieved (UDF for SQL conditions)"""
            cursor = self.conn.cursor()
            cursor.execute("SELECT 1 FROM vsm_execution_history WHERE to_state = ? LIMIT 1", (state_id,))
            return 1 if cursor.fetchone() else 0

        def vsm_llm_evaluate(condition, context):
            """Evaluate a condition using LLM (if KnowledgeDistiller available)"""
            if self.knowledge_distiller:
                try:
                    # Use SQL UDF if available
                    result = self.knowledge_distiller.execute_sql_distillation_query(
                        f"SELECT LLM_GENERATE('Evaluate: {condition} given context: {context}') as evaluation"
                    )
                    evaluation = result[0]['evaluation'] if result and 'evaluation' in result[0] else "true"
                    return 1 if "true" in evaluation.lower() else 0
                except:
                    return 1  # Default to true if evaluation fails
            return 1

        # Register UDFs
        self.conn.create_function("VSM_COSINE_SIMILARITY", 2, vsm_cosine_similarity)
        self.conn.create_function("VSM_VECTOR_DISTANCE", 2, vsm_vector_distance)
        self.conn.create_function("VSM_VECTOR_MAGNITUDE", 1, vsm_vector_magnitude)
        self.conn.create_function("VSM_STATE_ACHIEVED", 1, vsm_state_achieved)
        self.conn.create_function("VSM_LLM_EVALUATE", 2, vsm_llm_evaluate)

        print("🔌 Registered VSM SQLite UDFs")

    def _serialize_vector(self, vector: np.ndarray) -> bytes:
        """Serialize numpy vector for SQLite storage"""
        return pickle.dumps(vector)

    def _deserialize_vector(self, blob: bytes) -> np.ndarray:
        """Deserialize vector from SQLite storage"""
        return pickle.loads(blob)

    def _create_state_id(self, base_name: str = "state") -> str:
        """Create a unique state ID"""
        timestamp = str(time.time()).replace('.', '')
        random_part = hashlib.md5(str(np.random.rand()).encode()).hexdigest()[:4]
        return f"{base_name}_{timestamp}_{random_part}"

    def _create_transition_id(self, from_state: str, to_state: str) -> str:
        """Create a unique transition ID"""
        combined = f"{from_state}_to_{to_state}"
        return f"trans_{hashlib.md5(combined.encode()).hexdigest()[:8]}"

    def create_state(self,
                    state_vector: np.ndarray,
                    metadata: Dict[str, Any] = None,
                    is_initial: bool = False,
                    is_goal: bool = False) -> str:
        """
        Create a new state in the state machine

        Args:
            state_vector: Vector representation of the state
            metadata: Additional state metadata
            is_initial: Whether this is an initial state
            is_goal: Whether this is a goal state

        Returns:
            state_id: Unique identifier for the created state
        """
        state_id = self._create_state_id()

        cursor = self.conn.cursor()
        cursor.execute("""
        INSERT INTO vsm_states
        (state_id, state_vector, metadata, created_at, confidence, is_initial, is_goal)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            state_id,
            self._serialize_vector(state_vector),
            json.dumps(metadata or {}),
            time.time(),
            1.0,
            1 if is_initial else 0,
            1 if is_goal else 0
        ))

        self.conn.commit()
        print(f"✅ Created state {state_id} (initial: {is_initial}, goal: {is_goal})")
        return state_id

    def create_transition(self,
                         from_state: str,
                         to_state: str,
                         condition_vector: np.ndarray = None,
                         action_sql: str = None,
                         probability: float = 1.0,
                         metadata: Dict[str, Any] = None) -> str:
        """
        Create a transition between states

        Args:
            from_state: Source state ID
            to_state: Destination state ID
            condition_vector: Vector representing transition condition
            action_sql: SQL to execute during transition
            probability: Transition probability (0-1)
            metadata: Additional transition metadata

        Returns:
            transition_id: Unique identifier for the created transition
        """
        transition_id = self._create_transition_id(from_state, to_state)

        cursor = self.conn.cursor()
        cursor.execute("""
        INSERT INTO vsm_transitions
        (transition_id, from_state, to_state, condition_vector, action_sql, probability, metadata, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            transition_id,
            from_state,
            to_state,
            self._serialize_vector(condition_vector) if condition_vector is not None else None,
            action_sql,
            probability,
            json.dumps(metadata or {}),
            time.time()
        ))

        self.conn.commit()
        print(f"🔄 Created transition {transition_id}: {from_state} → {to_state}")
        return transition_id

    def set_initial_state(self, state_id: str):
        """Set the initial state for the state machine"""
        cursor = self.conn.cursor()

        # Clear any existing initial states
        cursor.execute("UPDATE vsm_states SET is_initial = 0")

        # Set new initial state
        cursor.execute("UPDATE vsm_states SET is_initial = 1 WHERE state_id = ?", (state_id,))

        self.current_state = state_id
        self.state_history = [state_id]
        self.transition_log = []

        self.conn.commit()
        print(f"🎯 Initial state set to: {state_id}")

    def start_session(self, session_id: str = None, initial_state: str = None) -> str:
        """
        Start a new VSM session

        Args:
            session_id: Optional session ID (auto-generated if None)
            initial_state: Optional initial state (uses default if None)

        Returns:
            session_id: The session identifier
        """
        if not session_id:
            session_id = f"session_{hashlib.md5(str(time.time()).encode()).hexdigest()[:8]}"

        if not initial_state:
            # Find default initial state
            cursor = self.conn.cursor()
            cursor.execute("SELECT state_id FROM vsm_states WHERE is_initial = 1 LIMIT 1")
            result = cursor.fetchone()
            if result:
                initial_state = result['state_id']
            else:
                raise ValueError("No initial state defined")

        # Start session
        cursor = self.conn.cursor()
        cursor.execute("""
        INSERT INTO vsm_sessions
        (session_id, initial_state, current_state, start_time, status, metadata)
        VALUES (?, ?, ?, ?, ?, ?)
        """, (
            session_id,
            initial_state,
            initial_state,
            time.time(),
            "running",
            json.dumps({"started": True})
        ))

        self.current_state = initial_state
        self.state_history = [initial_state]
        self.transition_log = []

        self.conn.commit()
        print(f"🚀 Started VSM session {session_id} with initial state {initial_state}")
        return session_id

    def end_session(self, session_id: str, status: str = "completed"):
        """End a VSM session"""
        cursor = self.conn.cursor()
        cursor.execute("""
        UPDATE vsm_sessions
        SET end_time = ?, status = ?, metadata = json_set(metadata, '$.ended', true)
        WHERE session_id = ?
        """, (time.time(), status, session_id))

        self.conn.commit()
        print(f"🏁 Ended VSM session {session_id} with status: {status}")

    def find_valid_transitions(self, current_state: str, similarity_threshold: float = 0.7) -> List[Dict]:
        """
        Find valid transitions from current state using SQL-driven similarity search

        Args:
            current_state: Current state ID
            similarity_threshold: Minimum cosine similarity for valid transitions

        Returns:
            List of valid transitions with similarity scores
        """
        cursor = self.conn.cursor()

        # Get current state vector
        cursor.execute("SELECT state_vector FROM vsm_states WHERE state_id = ?", (current_state,))
        current_state_row = cursor.fetchone()

        if not current_state_row:
            return []

        current_vector_blob = current_state_row['state_vector']

        # SQL query to find valid transitions using cosine similarity
        query = """
        SELECT
            t.transition_id,
            t.from_state,
            t.to_state,
            t.action_sql,
            t.probability,
            VSM_COSINE_SIMILARITY(t.condition_vector, ?) as similarity,
            t.metadata
        FROM vsm_transitions t
        WHERE t.from_state = ?
        AND (t.condition_vector IS NULL OR VSM_COSINE_SIMILARITY(t.condition_vector, ?) > ?)
        ORDER BY similarity DESC, t.probability DESC
        """

        cursor.execute(query, (current_vector_blob, current_state, current_vector_blob, similarity_threshold))

        transitions = []
        for row in cursor.fetchall():
            transitions.append({
                'transition_id': row['transition_id'],
                'from_state': row['from_state'],
                'to_state': row['to_state'],
                'action_sql': row['action_sql'],
                'probability': row['probability'],
                'similarity': row['similarity'],
                'metadata': json.loads(row['metadata']) if row['metadata'] else {}
            })

        return transitions

    def execute_transition(self, transition_id: str, session_id: str = None) -> Dict:
        """
        Execute a state transition

        Args:
            transition_id: ID of transition to execute
            session_id: Optional session ID

        Returns:
            Dictionary with execution results
        """
        cursor = self.conn.cursor()

        # Get transition details
        cursor.execute("""
        SELECT t.transition_id, t.from_state, t.to_state, t.action_sql,
               s1.state_vector as from_vector, s2.state_vector as to_vector
        FROM vsm_transitions t
        JOIN vsm_states s1 ON t.from_state = s1.state_id
        JOIN vsm_states s2 ON t.to_state = s2.state_id
        WHERE t.transition_id = ?
        """, (transition_id,))

        transition_row = cursor.fetchone()
        if not transition_row:
            raise ValueError(f"Transition {transition_id} not found")

        # Execute action SQL if provided
        action_results = []
        if transition_row['action_sql']:
            try:
                # Execute the SQL action
                cursor.execute(transition_row['action_sql'])
                if cursor.description:  # It's a SELECT query
                    columns = [col[0] for col in cursor.description]
                    for row in cursor.fetchall():
                        action_results.append(dict(zip(columns, row)))
                else:  # It's an INSERT/UPDATE/DELETE
                    action_results.append({"rows_affected": cursor.rowcount})
                self.conn.commit()
            except Exception as e:
                action_results.append({"error": str(e)})

        # Record transition in history
        step_number = len(self.transition_log) + 1
        cursor.execute("""
        INSERT INTO vsm_execution_history
        (session_id, step_number, from_state, to_state, transition_id, timestamp, metadata)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            session_id or "default",
            step_number,
            transition_row['from_state'],
            transition_row['to_state'],
            transition_id,
            time.time(),
            json.dumps({
                'action_results': action_results,
                'from_vector': transition_row['from_vector'].hex() if transition_row['from_vector'] else None,
                'to_vector': transition_row['to_vector'].hex() if transition_row['to_vector'] else None
            })
        ))

        # Update current state
        self.current_state = transition_row['to_state']
        self.state_history.append(transition_row['to_state'])

        # Update session current state
        if session_id:
            cursor.execute("""
            UPDATE vsm_sessions
            SET current_state = ?
            WHERE session_id = ?
            """, (transition_row['to_state'], session_id))

        self.conn.commit()

        # Log transition
        self.transition_log.append({
            'transition_id': transition_id,
            'from_state': transition_row['from_state'],
            'to_state': transition_row['to_state'],
            'action_results': action_results
        })

        print(f"🔄 Executed transition: {transition_row['from_state']} → {transition_row['to_state']}")
        return {
            'success': True,
            'from_state': transition_row['from_state'],
            'to_state': transition_row['to_state'],
            'transition_id': transition_id,
            'action_results': action_results
        }

    def run_cogitation_loop(self,
                          max_steps: int = 10,
                          session_id: str = None,
                          similarity_threshold: float = 0.7) -> Dict:
        """
        Run the main cogitation loop until goal state or max steps

        Args:
            max_steps: Maximum number of steps to execute
            session_id: Optional session ID
            similarity_threshold: Minimum similarity for valid transitions

        Returns:
            Dictionary with execution summary
        """
        if not session_id:
            session_id = self.start_session()

        steps_executed = 0
        goal_achieved = False

        print(f"🤖 Starting cogitation loop (session: {session_id})")

        while steps_executed < max_steps:
            steps_executed += 1
            print(f"\n📍 Step {steps_executed}/{max_steps} - Current state: {self.current_state}")

            # Check if current state is a goal state
            cursor = self.conn.cursor()
            cursor.execute("SELECT is_goal FROM vsm_states WHERE state_id = ?", (self.current_state,))
            state_row = cursor.fetchone()

            if state_row and state_row['is_goal']:
                print(f"🎯 Goal state achieved: {self.current_state}")
                goal_achieved = True
                break

            # Find valid transitions
            valid_transitions = self.find_valid_transitions(self.current_state, similarity_threshold)

            if not valid_transitions:
                print(f"❌ No valid transitions from state {self.current_state}")
                break

            print(f"🔄 Found {len(valid_transitions)} valid transitions")

            # Select transition with highest similarity * probability
            best_transition = max(valid_transitions,
                                key=lambda t: t['similarity'] * t['probability'])

            print(f"🎯 Selected transition: {best_transition['transition_id']} "
                  f"(similarity: {best_transition['similarity']:.3f}, "
                  f"probability: {best_transition['probability']})")

            # Execute the transition
            try:
                result = self.execute_transition(best_transition['transition_id'], session_id)
                print(f"✅ Transition executed: {result['from_state']} → {result['to_state']}")
            except Exception as e:
                print(f"❌ Transition failed: {e}")
                break

        # End session
        status = "goal_achieved" if goal_achieved else "max_steps_reached"
        self.end_session(session_id, status)

        print(f"🏁 Cogitation loop completed: {status} after {steps_executed} steps")

        return {
            'session_id': session_id,
            'steps_executed': steps_executed,
            'goal_achieved': goal_achieved,
            'final_state': self.current_state,
            'state_history': self.state_history,
            'transition_log': self.transition_log
        }

    def create_knowledge_distillation_workflow(self):
        """
        Create a predefined workflow for knowledge distillation using VSM
        This demonstrates how to integrate KnowledgeDistiller with VectorStateMachine
        """
        if not self.knowledge_distiller:
            print("⚠️  KnowledgeDistiller not available for workflow creation")
            return

        print("🔧 Creating knowledge distillation workflow...")

        # Create states for distillation process
        initial_state = self.create_state(
            np.array([1, 0, 0, 0, 0, 0, 0, 0]),  # Simple vector for initial state
            {"description": "Initial state - ready to distill"},
            is_initial=True
        )

        probe_generation_state = self.create_state(
            np.array([0, 1, 0, 0, 0, 0, 0, 0]),
            {"description": "Probe generation state"}
        )

        oracle_interrogation_state = self.create_state(
            np.array([0, 0, 1, 0, 0, 0, 0, 0]),
            {"description": "Oracle interrogation state"}
        )

        crystallization_state = self.create_state(
            np.array([0, 0, 0, 1, 0, 0, 0, 0]),
            {"description": "Knowledge crystallization state"}
        )

        goal_state = self.create_state(
            np.array([0, 0, 0, 0, 1, 0, 0, 0]),
            {"description": "Goal state - distillation complete"},
            is_goal=True
        )

        # Create transitions
        self.create_transition(
            initial_state,
            probe_generation_state,
            condition_vector=np.array([1, 1, 0, 0, 0, 0, 0, 0]),
            action_sql="SELECT 'Generating probes...' as status",
            metadata={"step": "generate_probes"}
        )

        self.create_transition(
            probe_generation_state,
            oracle_interrogation_state,
            condition_vector=np.array([0, 1, 1, 0, 0, 0, 0, 0]),
            action_sql="SELECT 'Interrogating oracle...' as status",
            metadata={"step": "interrogate_oracle"}
        )

        self.create_transition(
            oracle_interrogation_state,
            crystallization_state,
            condition_vector=np.array([0, 0, 1, 1, 0, 0, 0, 0]),
            action_sql="SELECT 'Crystallizing knowledge...' as status",
            metadata={"step": "crystallize_knowledge"}
        )

        self.create_transition(
            crystallization_state,
            goal_state,
            condition_vector=np.array([0, 0, 0, 1, 1, 0, 0, 0]),
            action_sql="SELECT 'Distillation complete!' as status",
            metadata={"step": "complete"}
        )

        # Set initial state
        self.set_initial_state(initial_state)

        print("✅ Knowledge distillation workflow created")
        return {
            'initial_state': initial_state,
            'goal_state': goal_state,
            'states': [initial_state, probe_generation_state, oracle_interrogation_state,
                      crystallization_state, goal_state]
        }

    def integrate_with_knowledge_distiller(self, distiller):
        """Integrate with KnowledgeDistiller for enhanced functionality"""
        self.knowledge_distiller = distiller

        # Manually register KnowledgeDistiller UDFs on the VSM connection
        def sql_llm_generate(prompt):
            """SQL UDF that calls LLM directly from SQLite queries"""
            try:
                # Use synchronous method directly
                if hasattr(distiller.llm_client, 'interrogate_oracle_sync'):
                    return distiller.llm_client.interrogate_oracle_sync(prompt)
                elif hasattr(distiller.llm_client, 'interrogate_oracle'):
                    # For async methods, use our helper
                    return distiller._mock_llm_sync_response(prompt)
                else:
                    return f"LLM response for: {prompt}"
            except Exception as e:
                return f"Error generating LLM response: {str(e)}"

        def sql_llm_generate_probes(domain, num_probes=5):
            """SQL UDF that generates probes for a domain"""
            try:
                # Use synchronous method directly
                if hasattr(distiller.llm_client, 'generate_probes_sync'):
                    probes = distiller.llm_client.generate_probes_sync(domain, int(num_probes))
                    return json.dumps(probes)
                elif hasattr(distiller.llm_client, 'generate_probes'):
                    # Use mock knowledge base directly
                    return json.dumps(distiller._mock_generate_probes_sync(domain, int(num_probes)))
                else:
                    return json.dumps([])
            except Exception as e:
                return json.dumps([])

        def sql_create_embedding(text):
            """SQL UDF that creates embeddings directly in SQL"""
            try:
                embedding = distiller._create_embedding(text)
                return distiller._serialize_embedding(embedding)
            except Exception as e:
                return b""

        def sql_cosine_similarity(a_blob, b_blob):
            """SQL UDF that calculates cosine similarity between embeddings"""
            try:
                a = distiller._deserialize_embedding(a_blob)
                b = distiller._deserialize_embedding(b_blob)
                return distiller._cosine_similarity(a, b)
            except Exception as e:
                return 0.0

        # Register the UDFs on the VSM connection
        self.conn.create_function("LLM_GENERATE", 1, sql_llm_generate)
        self.conn.create_function("LLM_GENERATE_PROBES", 2, sql_llm_generate_probes)
        self.conn.create_function("CREATE_EMBEDDING", 1, sql_create_embedding)
        self.conn.create_function("COSINE_SIMILARITY", 2, sql_cosine_similarity)

        def sql_distill_knowledge(domain, concept, explanation):
            """SQL UDF that performs complete knowledge distillation"""
            try:
                # This would normally be async, but for SQL UDF we make it synchronous
                knowledge_id = asyncio.run(distiller._crystallize_knowledge(domain, concept, explanation))
                return knowledge_id
            except Exception as e:
                return f"Error: {str(e)}"
        self.conn.create_function("DISTILL_KNOWLEDGE", 3, sql_distill_knowledge)
        print("🔌 Registered KnowledgeDistiller UDFs on VSM connection")

        if hasattr(distiller, 'enable_sql_driven_distillation'):
            # Also enable on distiller's own connection
            distiller.enable_sql_driven_distillation()

        print("🔗 Integrated VectorStateMachine with KnowledgeDistiller")

    def get_execution_history(self, session_id: str = None) -> List[Dict]:
        """Get execution history for a session"""
        cursor = self.conn.cursor()

        if session_id:
            cursor.execute("""
            SELECT * FROM vsm_execution_history
            WHERE session_id = ?
            ORDER BY step_number
            """, (session_id,))
        else:
            cursor.execute("""
            SELECT * FROM vsm_execution_history
            ORDER BY execution_id DESC
            LIMIT 50
            """)

        history = []
        for row in cursor.fetchall():
            history.append({
                'execution_id': row['execution_id'],
                'session_id': row['session_id'],
                'step_number': row['step_number'],
                'from_state': row['from_state'],
                'to_state': row['to_state'],
                'transition_id': row['transition_id'],
                'timestamp': row['timestamp'],
                'metadata': json.loads(row['metadata']) if row['metadata'] else {}
            })

        return history

    def get_session_info(self, session_id: str) -> Dict:
        """Get information about a specific session"""
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM vsm_sessions WHERE session_id = ?", (session_id,))
        row = cursor.fetchone()

        if not row:
            return None

        return {
            'session_id': row['session_id'],
            'initial_state': row['initial_state'],
            'current_state': row['current_state'],
            'start_time': row['start_time'],
            'end_time': row['end_time'],
            'status': row['status'],
            'duration': row['end_time'] - row['start_time'] if row['end_time'] else None,
            'metadata': json.loads(row['metadata']) if row['metadata'] else {}
        }

    def visualize_state_machine(self) -> str:
        """Generate a visualization of the state machine (simple text representation)"""
        cursor = self.conn.cursor()

        # Get all states
        cursor.execute("SELECT state_id, is_initial, is_goal FROM vsm_states")
        states = cursor.fetchall()

        # Get all transitions
        cursor.execute("SELECT from_state, to_state FROM vsm_transitions")
        transitions = cursor.fetchall()

        # Build visualization
        visualization = "📊 Vector State Machine Visualization\n"
        visualization += "=" * 50 + "\n"

        # States
        visualization += "States:\n"
        for state in states:
            markers = []
            if state['is_initial']:
                markers.append("🟢 INITIAL")
            if state['is_goal']:
                markers.append("🔴 GOAL")
            markers_str = " [" + ", ".join(markers) + "]" if markers else ""
            visualization += f"  • {state['state_id']}{markers_str}\n"

        # Transitions
        visualization += "\nTransitions:\n"
        for trans in transitions:
            visualization += f"  • {trans['from_state']} → {trans['to_state']}\n"

        return visualization

    def close(self):
        """Close database connection"""
        self.conn.close()
        print("🔌 Vector State Machine connection closed")

# Example usage and testing
async def example_vsm_usage():
    """Example of using the VectorStateMachine"""
    print("🚀 Vector State Machine Example")

    # Initialize VSM
    vsm = VectorStateMachine("test_vsm.db")

    try:
        # Create a simple state machine
        state1 = vsm.create_state(np.array([1, 0, 0]), {"name": "State 1"}, is_initial=True)
        state2 = vsm.create_state(np.array([0, 1, 0]), {"name": "State 2"})
        state3 = vsm.create_state(np.array([0, 0, 1]), {"name": "State 3"}, is_goal=True)

        # Create transitions
        trans1 = vsm.create_transition(state1, state2, np.array([1, 1, 0]))
        trans2 = vsm.create_transition(state2, state3, np.array([0, 1, 1]))

        print(f"✅ Created state machine with states: {state1}, {state2}, {state3}")
        print(f"🔄 Created transitions: {trans1}, {trans2}")

        # Start session and run cogitation loop
        session_id = vsm.start_session()
        result = vsm.run_cogitation_loop(max_steps=5)

        print(f"🏁 Cogitation loop result: {result['status']}")
        print(f"   Steps: {result['steps_executed']}")
        print(f"   Final state: {result['final_state']}")

        # Visualize the state machine
        print("\n" + vsm.visualize_state_machine())

        # Test knowledge distillation workflow
        if hasattr(vsm, 'create_knowledge_distillation_workflow'):
            workflow = vsm.create_knowledge_distillation_workflow()
            print(f"🔧 Knowledge distillation workflow: {workflow}")

    finally:
        vsm.close()

if __name__ == "__main__":
    # Run example (note: this is synchronous, but we keep the async signature for compatibility)
    example_vsm_usage()