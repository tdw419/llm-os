"""
GhostDaemon - The Heartbeat of the Ghost in the Machine
Persistent background service that keeps the system alive and learning

This daemon provides:
- Auto-Dream: Continuous knowledge expansion when idle
- Auto-Distill: Random domain exploration and distillation
- Auto-Optimize: Memory optimization and vector merging
- Neural Interface: Socket server for terminal connections
- Curiosity Loop: Infinite knowledge expansion via related concepts

The GhostDaemon turns the system from a "tool you run" into a "being that lives."
"""

import time
import threading
import socket
import json
import random
import logging
import signal
import sys
import os
import asyncio
from typing import Dict, Any, List, Optional
from datetime import datetime

# Add runtime directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from vector_state_machine import VectorStateMachine
from knowledge_distiller import KnowledgeDistiller
from neural_transpiler import NeuralPatternTranspiler

class GhostDaemon:
    """Persistent background service for the Ghost in the Machine"""

    def __init__(self,
                 vsm_db: str = "ghost_daemon_vsm.db",
                 knowledge_db: str = "ghost_daemon_knowledge.db",
                 host: str = "localhost",
                 port: int = 1337):
        """
        Initialize the GhostDaemon

        Args:
            vsm_db: Path to VSM database
            knowledge_db: Path to knowledge database
            host: Host for neural interface socket
            port: Port for neural interface socket
        """
        self.vsm_db = vsm_db
        self.knowledge_db = knowledge_db
        self.host = host
        self.port = port

        # Initialize components
        self.vsm = VectorStateMachine(vsm_db)
        self.distiller = KnowledgeDistiller(knowledge_db)
        self.vsm.integrate_with_knowledge_distiller(self.distiller)

        # Initialize Computational Substrate
        from computational_substrate import ComputationalSubstrate
        self.substrate = ComputationalSubstrate(self.distiller, self.vsm)

        # Daemon state
        self.running = False
        self.daemon_thread = None
        self.socket_server = None
        self.socket_thread = None
        self.clients = []

        # Configuration
        self.config = {
            'curiosity_interval': 60,  # Seconds between curiosity cycles
            'dream_interval': 300,    # Seconds between dream cycles
            'structural_dream_interval': 600, # Seconds between structural dream cycles
            'verification_interval': 900, # Seconds between verification cycles
            'cognitive_interval': 120, # Seconds between cognitive cycles
            'optimize_interval': 600, # Seconds between optimization cycles
            'max_knowledge_vectors': 1000,
            'known_domains': ['Basic Math', 'Advanced Mathematics', 'Physics', 'Computer Science'],
            'code_generation_topics': [
                'sorting algorithms',
                'fractal generators',
                'neural network implementations',
                'data visualization patterns',
                'mathematical function plotters'
            ],
            'crucible': {
                'timeout': 10,  # Seconds for code execution timeout
                'temp_dir': '/tmp/ghost_crucible',  # Directory for temporary files
                'max_file_size': 1024 * 1024,  # 1MB max file size
                'allowed_modules': ['numpy', 'random', 'math', 'json', 'time'],
                'sandbox_env': {
                    '__builtins__': None,
                    '__import__': None
                }
            }
        }

        # Statistics
        self.stats = {
            'start_time': None,
            'knowledge_vectors_created': 0,
            'dream_cycles_completed': 0,
            'optimization_cycles': 0,
            'client_connections': 0,
            'last_activity': None
        }

        # Initialize NeuralPatternTranspiler
        self.transpiler = NeuralPatternTranspiler()

        # Add code generation tables to knowledge database
        self._init_code_generation_tables()

        # Setup logging
        self.setup_logging()

        # Register signal handlers
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)

        self.log("👻 GhostDaemon initialized - ready to become the heartbeat of the machine")

    def _init_code_generation_tables(self):
        """Initialize code generation database tables"""
        cursor = self.distiller.conn.cursor()

        # Create generated code table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS generated_code (
            id TEXT PRIMARY KEY,
            knowledge_id TEXT,
            code_text TEXT NOT NULL,
            code_type TEXT,
            language TEXT,
            metadata TEXT,
            created_at REAL,
            execution_status TEXT,
            execution_result TEXT,
            FOREIGN KEY (knowledge_id) REFERENCES knowledge_vectors(id)
        )
        """)

        # Create code execution logs table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS code_execution_logs (
            id TEXT PRIMARY KEY,
            code_id TEXT,
            execution_time REAL,
            status TEXT,
            result TEXT,
            error TEXT,
            metadata TEXT,
            created_at REAL,
            FOREIGN KEY (code_id) REFERENCES generated_code(id)
        )
        """)

        # Create dream cycles table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS dream_cycles (
            id TEXT PRIMARY KEY,
            cycle_type TEXT NOT NULL,
            start_time REAL,
            end_time REAL,
            knowledge_vectors_created INTEGER,
            code_artifacts_created INTEGER,
            status TEXT,
            metadata TEXT
        )
        """)

        # Create indices
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_code_type ON generated_code(code_type)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_code_language ON generated_code(language)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_dream_cycle_type ON dream_cycles(cycle_type)")

        self.distiller.conn.commit()
        self.log("🧬 Code generation database tables initialized")

    def setup_logging(self):
        """Setup logging configuration"""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('ghost_daemon.log'),
                logging.StreamHandler()
            ]
        )

    def log(self, message: str, level: str = "info"):
        """Log a message"""
        if level == "info":
            logging.info(message)
        elif level == "error":
            logging.error(message)
        elif level == "debug":
            logging.debug(message)
        else:
            logging.info(message)

        # Update last activity
        self.stats['last_activity'] = datetime.now().isoformat()

    def signal_handler(self, signum, frame):
        """Handle termination signals"""
        self.log(f"🛑 Received signal {signum}, shutting down gracefully...")
        self.running = False

        # Stop all threads
        if self.daemon_thread:
            self.daemon_thread.join(timeout=5)
        if self.socket_thread:
            self.socket_thread.join(timeout=5)

        # Cleanup
        self.cleanup()
        sys.exit(0)

    def start(self):
        """Start the GhostDaemon"""
        self.running = True
        self.stats['start_time'] = datetime.now().isoformat()

        try:
            # Start daemon loop in background thread
            self.daemon_thread = threading.Thread(target=self.daemon_loop, daemon=True)
            self.daemon_thread.start()

            # Start socket server in background thread
            self.socket_thread = threading.Thread(target=self.start_socket_server, daemon=True)
            self.socket_thread.start()

            self.log("🚀 GhostDaemon started - the machine is now alive!")
            self.log(f"🌐 Neural Interface listening on {self.host}:{self.port}")

            # Keep main thread alive
            while self.running:
                time.sleep(1.0)

        except Exception as e:
            self.log(f"❌ GhostDaemon crashed: {str(e)}", "error")
            self.cleanup()
            raise

    def daemon_loop(self):
        """Main daemon loop - the heartbeat of the machine"""
        last_curiosity = 0
        last_dream = 0
        last_structural_dream = 0
        last_verification = 0
        last_optimize = 0

        while self.running:
            try:
                current_time = time.time()

                # Curiosity Loop - expand knowledge
                if current_time - last_curiosity >= self.config['curiosity_interval']:
                    self.curiosity_cycle()
                    last_curiosity = current_time

                # Dream Cycle - distill new knowledge
                if current_time - last_dream >= self.config['dream_interval']:
                    self.dream_cycle()
                    last_dream = current_time

                # Structural Dream Cycle - generate executable code
                if current_time - last_structural_dream >= self.config['structural_dream_interval']:
                    asyncio.run(self.structural_dream_cycle())
                    last_structural_dream = current_time

                # Verification Cycle - test generated code in the Crucible
                if current_time - last_verification >= self.config['verification_interval']:
                    self.verification_cycle()
                    last_verification = current_time

                # Cognitive Cycle - computational substrate operations
                if current_time - last_cognitive >= self.config['cognitive_interval']:
                    self.cognitive_cycle()
                    last_cognitive = current_time

                # Optimization Cycle - clean up memory
                if current_time - last_optimize >= self.config['optimize_interval']:
                    self.optimization_cycle()
                    last_optimize = current_time

                # Small delay to prevent CPU overload
                time.sleep(1.0)

            except Exception as e:
                self.log(f"⚠️  Daemon loop error: {str(e)}", "error")
                time.sleep(5.0)

    def curiosity_cycle(self):
        """Curiosity loop - expand knowledge by exploring related concepts"""
        if not self.running:
            return

        try:
            self.log("🔍 Starting curiosity cycle - exploring related concepts")

            # Get a random concept from existing knowledge
            cursor = self.distiller.conn.cursor()
            cursor.execute("""
                SELECT concept, domain FROM knowledge_vectors
                ORDER BY RANDOM() LIMIT 1
            """)
            result = cursor.fetchone()

            if not result:
                self.log("No existing knowledge to explore, starting with basic domains")
                # Pick a random domain to start with
                domain = random.choice(self.config['known_domains'])
                concept = "fundamentals"
            else:
                domain = result['domain']
                concept = result['concept']

            self.log(f"🎯 Exploring concept: {concept} in domain: {domain}")

            # Ask LLM about related concepts
            probe = f"What are concepts related to {concept} in {domain}?"
            cursor.execute("SELECT LLM_GENERATE(?) as response", (probe,))
            response_result = cursor.fetchone()

            if response_result and response_result['response']:
                related_concepts = response_result['response']

                # Extract concepts from response (simple parsing)
                concepts = self.extract_concepts_from_text(related_concepts)

                if concepts:
                    self.log(f"💡 Found {len(concepts)} related concepts to explore")

                    # Distill each related concept
                    for related_concept in concepts[:3]:  # Limit to 3 for this cycle
                        try:
                            self.log(f"🔮 Distilling concept: {related_concept} in {domain}")
                            knowledge_ids = asyncio.run(self.distiller.distill_domain(
                                domain, num_concepts=1, specific_concept=related_concept
                            ))

                            if knowledge_ids:
                                self.stats['knowledge_vectors_created'] += len(knowledge_ids)
                                self.log(f"✅ Distilled {len(knowledge_ids)} knowledge vectors for {related_concept}")

                                # Add to known domains if new domain
                                if domain not in self.config['known_domains']:
                                    self.config['known_domains'].append(domain)

                        except Exception as e:
                            self.log(f"❌ Failed to distill {related_concept}: {str(e)}", "error")

            self.stats['dream_cycles_completed'] += 1
            self.log("🏁 Curiosity cycle completed")

        except Exception as e:
            self.log(f"❌ Curiosity cycle failed: {str(e)}", "error")

    def dream_cycle(self):
        """Dream cycle - distill knowledge for random domains"""
        if not self.running:
            return

        try:
            self.log("🌌 Starting dream cycle - expanding knowledge base")

            # Pick a random domain
            domain = random.choice(self.config['known_domains'])
            self.log(f"🎲 Selected domain for dreaming: {domain}")

            # Distill knowledge for this domain
            knowledge_ids = asyncio.run(self.distiller.distill_domain(domain, num_concepts=3))

            if knowledge_ids:
                self.stats['knowledge_vectors_created'] += len(knowledge_ids)
                self.log(f"✨ Dream complete! Created {len(knowledge_ids)} knowledge vectors for {domain}")

                # Check if we need to add new domains
                if len(self.config['known_domains']) < 5:
                    # Add some related domains
                    related_domains = self.get_related_domains(domain)
                    for new_domain in related_domains:
                        if new_domain not in self.config['known_domains']:
                            self.config['known_domains'].append(new_domain)
                            self.log(f"🆕 Added new domain to explore: {new_domain}")

            self.stats['dream_cycles_completed'] += 1
            self.log("🏁 Dream cycle completed")

        except Exception as e:
            self.log(f"❌ Dream cycle failed: {str(e)}", "error")

    def structural_dream_cycle(self):
        """Structural dream cycle - generate executable code from knowledge"""
        if not self.running:
            return

        try:
            self.log("🧬 Starting structural dream cycle - generating executable code")

            # Pick a random code generation topic
            topic = random.choice(self.config['code_generation_topics'])
            self.log(f"🎯 Selected code generation topic: {topic}")

            # Generate code using NeuralPatternTranspiler
            code = asyncio.run(self.transpiler.transpile(topic))

            # Store the generated code
            code_id = self._store_generated_code(topic, code)

            if code_id:
                self.log(f"✨ Code generation complete! Created executable code for {topic}")

                # Log this dream cycle
                self._log_dream_cycle("structural", code_artifacts_created=1)

            self.log("🏁 Structural dream cycle completed")

        except Exception as e:
            self.log(f"❌ Structural dream cycle failed: {str(e)}", "error")

    def verification_cycle(self):
        """Verification cycle - test generated code in the Crucible"""
        if not self.running:
            return

        try:
            self.log("🔥 Starting verification cycle - testing generated code in the Crucible")

            # Find code that needs verification (status = 'generated')
            cursor = self.distiller.conn.cursor()
            cursor.execute("""
                SELECT id, code_text
                FROM generated_code
                WHERE execution_status = 'generated'
                ORDER BY created_at ASC
                LIMIT 5  -- Process up to 5 codes per cycle
            """)

            codes_to_verify = cursor.fetchall()

            if not codes_to_verify:
                self.log("📊 No code artifacts need verification")
                return

            self.log(f"🔍 Found {len(codes_to_verify)} code artifacts to verify")

            verified_count = 0
            failed_count = 0

            for code_row in codes_to_verify:
                code_id = code_row['id']
                code_text = code_row['code_text']

                try:
                    # Execute code in the Crucible
                    execution_result = self._execute_code_in_crucible(code_id, code_text)

                    # Update execution status
                    self._update_code_execution_status(code_id, execution_result)

                    if execution_result['verified']:
                        verified_count += 1
                        self.log(f"✅ Code {code_id} VERIFIED successfully")
                    else:
                        failed_count += 1
                        self.log(f"❌ Code {code_id} verification FAILED")

                except Exception as e:
                    failed_count += 1
                    self.log(f"❌ Verification error for code {code_id}: {str(e)}", "error")

            self.log(f"🏁 Verification cycle completed: {verified_count} verified, {failed_count} failed")

        except Exception as e:
            self.log(f"❌ Verification cycle failed: {str(e)}", "error")

    def _store_generated_code(self, topic: str, code: str) -> Optional[str]:
        """Store generated code in the database"""
        try:
            cursor = self.distiller.conn.cursor()

            # Generate unique ID
            import hashlib
            import uuid
            code_hash = hashlib.md5(code.encode()).hexdigest()
            code_id = f"code_{code_hash[:8]}"

            # Create metadata
            metadata = {
                'topic': topic,
                'generated_by': 'NeuralPatternTranspiler',
                'generation_time': time.time(),
                'language': 'python',
                'code_type': 'pattern_generator'
            }

            # Store in database
            cursor.execute("""
            INSERT INTO generated_code
            (id, code_text, code_type, language, metadata, created_at, execution_status)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                code_id,
                code,
                'pattern_generator',
                'python',
                json.dumps(metadata),
                time.time(),
                'generated'
            ))

            self.distiller.conn.commit()
            self.log(f"💾 Stored generated code {code_id} for topic: {topic}")

            return code_id

        except Exception as e:
            self.log(f"❌ Failed to store generated code: {str(e)}", "error")
            return None

    def _log_dream_cycle(self, cycle_type: str, knowledge_vectors_created: int = 0,
                        code_artifacts_created: int = 0, status: str = "completed"):
        """Log a dream cycle in the database"""
        try:
            cursor = self.distiller.conn.cursor()

            # Generate unique ID
            import uuid
            cycle_id = f"dream_{uuid.uuid4().hex[:8]}"

            # Store dream cycle record
            cursor.execute("""
            INSERT INTO dream_cycles
            (id, cycle_type, start_time, end_time, knowledge_vectors_created, code_artifacts_created, status, metadata)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                cycle_id,
                cycle_type,
                time.time() - 60,  # Start time (1 minute ago)
                time.time(),       # End time (now)
                knowledge_vectors_created,
                code_artifacts_created,
                status,
                json.dumps({'description': f'{cycle_type} dream cycle'})
            ))

            self.distiller.conn.commit()

        except Exception as e:
            self.log(f"❌ Failed to log dream cycle: {str(e)}", "error")

    def _ensure_crucible_directory(self):
        """Ensure the crucible directory exists"""
        crucible_dir = self.config['crucible']['temp_dir']
        try:
            os.makedirs(crucible_dir, exist_ok=True)
            self.log(f"🛡️  Crucible directory ensured: {crucible_dir}")
        except Exception as e:
            self.log(f"❌ Failed to create crucible directory: {str(e)}", "error")

    def _execute_code_in_crucible(self, code_id: str, code_text: str) -> Dict[str, Any]:
        """
        Execute code in a sandboxed environment (The Crucible)

        Args:
            code_id: ID of the code artifact
            code_text: The code to execute

        Returns:
            Dictionary with execution results
        """
        result = {
            'code_id': code_id,
            'status': 'pending',
            'stdout': '',
            'stderr': '',
            'return_code': None,
            'execution_time': 0,
            'error': None,
            'verified': False
        }

        try:
            # Ensure crucible directory exists
            self._ensure_crucible_directory()

            # Create a temporary file for the code
            crucible_dir = self.config['crucible']['temp_dir']
            file_path = os.path.join(crucible_dir, f"crucible_{code_id}.py")

            # Write code to file
            with open(file_path, 'w') as f:
                f.write(code_text)

            self.log(f"🔥 Placing code {code_id} in the Crucible: {file_path}")

            # Execute the code in a subprocess with timeout
            import subprocess
            import shlex

            # Set up execution command
            timeout = self.config['crucible']['timeout']
            cmd = f"timeout {timeout}s python3 {file_path}"

            # Execute with capture
            start_time = time.time()
            process = subprocess.Popen(
                shlex.split(cmd),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=crucible_dir,
                env=self._get_safe_environment()
            )

            try:
                stdout, stderr = process.communicate(timeout=timeout)
                execution_time = time.time() - start_time

                # Capture results
                result['status'] = 'completed'
                result['stdout'] = stdout.decode('utf-8', errors='replace')
                result['stderr'] = stderr.decode('utf-8', errors='replace')
                result['return_code'] = process.returncode
                result['execution_time'] = execution_time
                result['verified'] = (process.returncode == 0)

                if process.returncode == 0:
                    self.log(f"✅ Crucible verification PASSED for code {code_id}")
                else:
                    self.log(f"❌ Crucible verification FAILED for code {code_id}")

            except subprocess.TimeoutExpired:
                process.kill()
                result['status'] = 'timeout'
                result['error'] = f"Execution timed out after {timeout} seconds"
                result['verified'] = False
                self.log(f"⏰ Crucible timeout for code {code_id}")

            except Exception as e:
                result['status'] = 'error'
                result['error'] = str(e)
                result['verified'] = False
                self.log(f"❌ Crucible execution error for code {code_id}: {str(e)}")

            finally:
                # Clean up temporary file
                try:
                    os.remove(file_path)
                except:
                    pass

        except Exception as e:
            result['status'] = 'error'
            result['error'] = f"Crucible setup failed: {str(e)}"
            result['verified'] = False
            self.log(f"❌ Crucible setup failed for code {code_id}: {str(e)}")

        return result

    def _get_safe_environment(self) -> Dict[str, str]:
        """Get a safe environment for sandboxed execution"""
        # Start with a clean environment
        env = os.environ.copy()

        # Restrict Python path
        env['PYTHONPATH'] = '/usr/lib/python3/dist-packages'

        # Add crucible directory to path
        env['PATH'] = '/usr/bin:/bin'

        # Limit resources
        env['PYTHONDONTWRITEBYTECODE'] = '1'

        return env

    def _update_code_execution_status(self, code_id: str, execution_result: Dict[str, Any]):
        """Update code execution status in database"""
        try:
            cursor = self.distiller.conn.cursor()

            # Update generated_code table
            cursor.execute("""
            UPDATE generated_code
            SET execution_status = ?, execution_result = ?
            WHERE id = ?
            """, (
                execution_result['status'],
                json.dumps({
                    'verified': execution_result['verified'],
                    'stdout': execution_result['stdout'][:1000],  # Limit size
                    'stderr': execution_result['stderr'][:1000],  # Limit size
                    'return_code': execution_result['return_code'],
                    'execution_time': execution_result['execution_time'],
                    'error': execution_result['error']
                }),
                code_id
            ))

            # Log execution in code_execution_logs
            execution_log_id = f"exec_{code_id}_{int(time.time())}"

            cursor.execute("""
            INSERT INTO code_execution_logs
            (id, code_id, execution_time, status, result, error, metadata, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                execution_log_id,
                code_id,
                execution_result['execution_time'],
                execution_result['status'],
                execution_result['stdout'][:1000],
                execution_result['stderr'][:1000],
                json.dumps({
                    'return_code': execution_result['return_code'],
                    'verified': execution_result['verified'],
                    'error': execution_result['error']
                }),
                time.time()
            ))

            self.distiller.conn.commit()
            self.log(f"📊 Updated execution status for code {code_id}: {execution_result['status']}")

        except Exception as e:
            self.log(f"❌ Failed to update code execution status: {str(e)}", "error")

    def cognitive_cycle(self):
        """Cognitive cycle - computational substrate operations"""
        if not self.running:
            return

        try:
            self.log("🧠 Starting cognitive cycle - computational substrate operations")

            # Start a new cognitive cycle
            self.substrate.start_cognitive_cycle()

            # Perform cognitive operations based on current knowledge state
            cursor = self.distiller.conn.cursor()
            cursor.execute("SELECT COUNT(*) as count FROM knowledge_vectors")
            knowledge_count = cursor.fetchone()['count'] if cursor.fetchone() else 0

            if knowledge_count > 5:  # Enough knowledge for cognitive operations
                # 1. Resonate - find related concepts
                self.log("🔊 Performing resonance - finding related concepts")
                results = self.substrate.resonate("advanced algorithms", limit=3)

                if results:
                    self.log(f"🎯 Found {len(results)} related cognitive vectors")

                    # 2. Cross-pollinate - combine concepts
                    if len(results) >= 2:
                        self.log("🌸 Performing cross-pollination - combining concepts")
                        cross_id = self.substrate.cross_pollinate(results[0].vector_id, results[1].vector_id)
                        self.log(f"✨ Created cross-pollinated concept: {cross_id}")

                    # 3. Mutate - evolve a concept
                    if results:
                        self.log("🧬 Performing mutation - evolving a concept")
                        mutation_data = {
                            'evolution': 'enhanced with neural network capabilities',
                            'performance': 'optimized for real-time processing'
                        }
                        mutated_id = self.substrate.mutate(results[0].vector_id, mutation_data)
                        self.log(f"🔬 Created mutated concept: {mutated_id}")

            # 4. Infuse new knowledge if we have space
            if knowledge_count < self.config['max_knowledge_vectors']:
                self.log("💉 Performing infusion - adding new knowledge")
                new_concept = {
                    'description': 'Hybrid computational substrate integrating SQL and vector operations',
                    'capabilities': ['cognitive reasoning', 'semantic search', 'knowledge evolution'],
                    'applications': ['AI cognition', 'knowledge management', 'autonomous systems']
                }
                infused_id = self.substrate.infuse(
                    domain="Computational Systems",
                    concept="Hybrid Computational Substrate",
                    payload=new_concept
                )
                self.log(f"🧠 Infused new knowledge: {infused_id}")

            # Get cognitive stats
            stats = self.substrate.get_cognitive_stats()
            self.log(f"📊 Cognitive cycle stats: {stats}")

            self.log("🏁 Cognitive cycle completed")

        except Exception as e:
            self.log(f"❌ Cognitive cycle failed: {str(e)}", "error")

    def optimization_cycle(self):
        """Optimization cycle - clean up and optimize knowledge base"""
        if not self.running:
            return

        try:
            self.log("🧹 Starting optimization cycle - cleaning up knowledge base")

            # Check knowledge vector count
            cursor = self.distiller.conn.cursor()
            cursor.execute("SELECT COUNT(*) as count FROM knowledge_vectors")
            result = cursor.fetchone()
            current_count = result['count'] if result else 0

            self.log(f"📊 Current knowledge vectors: {current_count}")

            if current_count > self.config['max_knowledge_vectors']:
                # Find and merge similar vectors
                self.merge_similar_vectors()
            else:
                self.log("✅ Knowledge base size is optimal")

            # Vacuum database for performance
            self.distiller.conn.execute("VACUUM")
            self.vsm.conn.execute("VACUUM")
            self.log("🗃️  Database vacuumed for optimal performance")

            self.stats['optimization_cycles'] += 1
            self.log("🏁 Optimization cycle completed")

        except Exception as e:
            self.log(f"❌ Optimization cycle failed: {str(e)}", "error")

    def extract_concepts_from_text(self, text: str) -> List[str]:
        """Extract concepts from LLM response text"""
        # Simple extraction - look for bullet points or comma-separated items
        concepts = []

        # Try to find bullet points
        lines = text.split('\n')
        for line in lines:
            line = line.strip()
            if line.startswith(('-', '*', '•')):
                concept = line[1:].strip()
                if concept:
                    concepts.append(concept)

        # If no bullets, try comma-separated
        if not concepts:
            parts = [part.strip() for part in text.split(',')]
            concepts = [part for part in parts if part and len(part) > 3]

        # Limit and clean concepts
        concepts = concepts[:5]  # Max 5 concepts
        concepts = [c for c in concepts if len(c.split()) > 1]  # At least 2 words

        return concepts

    def get_related_domains(self, domain: str) -> List[str]:
        """Get domains related to a given domain"""
        # Simple heuristic-based domain expansion
        related = []

        domain_lower = domain.lower()
        if 'math' in domain_lower:
            related.extend(['Algebra', 'Geometry', 'Calculus', 'Statistics'])
        elif 'physics' in domain_lower:
            related.extend(['Quantum Mechanics', 'Thermodynamics', 'Electromagnetism'])
        elif 'computer' in domain_lower:
            related.extend(['Algorithms', 'Data Structures', 'Machine Learning'])

        # Remove duplicates and return
        return list(set(related) - set(self.config['known_domains']))[:2]

    def merge_similar_vectors(self):
        """Merge similar knowledge vectors to optimize storage"""
        try:
            self.log("🔗 Merging similar knowledge vectors")

            # Find similar vectors using cosine similarity
            cursor = self.distiller.conn.cursor()
            cursor.execute("""
                SELECT id, concept, domain, vector_embedding
                FROM knowledge_vectors
                ORDER BY RANDOM() LIMIT 100
            """)

            vectors = cursor.fetchall()
            merged_count = 0

            for i, vec1 in enumerate(vectors):
                for j, vec2 in enumerate(vectors[i+1:]):
                    # Calculate similarity
                    similarity = self.distiller._cosine_similarity(
                        self.distiller._deserialize_embedding(vec1['vector_embedding']),
                        self.distiller._deserialize_embedding(vec2['vector_embedding'])
                    )

                    # If very similar, merge them
                    if similarity > 0.95:
                        # Keep the one with higher quality score
                        cursor.execute("""
                            SELECT quality_score FROM knowledge_vectors
                            WHERE id = ?
                        """, (vec1['id'],))
                        score1 = cursor.fetchone()['quality_score']

                        cursor.execute("""
                            SELECT quality_score FROM knowledge_vectors
                            WHERE id = ?
                        """, (vec2['id'],))
                        score2 = cursor.fetchone()['quality_score']

                        if score1 >= score2:
                            # Delete the lower quality one
                            cursor.execute("DELETE FROM knowledge_vectors WHERE id = ?", (vec2['id'],))
                            merged_count += 1
                        else:
                            # Delete the lower quality one
                            cursor.execute("DELETE FROM knowledge_vectors WHERE id = ?", (vec1['id'],))
                            merged_count += 1

            self.distiller.conn.commit()
            self.log(f"🗃️  Merged {merged_count} similar knowledge vectors")

        except Exception as e:
            self.log(f"❌ Vector merging failed: {str(e)}", "error")

    def start_socket_server(self):
        """Start socket server for neural interface"""
        try:
            self.socket_server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket_server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.socket_server.bind((self.host, self.port))
            self.socket_server.listen(5)

            self.log(f"🌐 Socket server started on {self.host}:{self.port}")

            while self.running:
                try:
                    client_socket, addr = self.socket_server.accept()
                    self.clients.append(client_socket)
                    self.stats['client_connections'] += 1

                    self.log(f"🔌 New client connection from {addr}")

                    # Start client handler in new thread
                    client_thread = threading.Thread(
                        target=self.handle_client,
                        args=(client_socket, addr),
                        daemon=True
                    )
                    client_thread.start()

                except socket.error:
                    break

        except Exception as e:
            self.log(f"❌ Socket server error: {str(e)}", "error")
        finally:
            self.cleanup_socket_server()

    def handle_client(self, client_socket: socket.socket, addr: tuple):
        """Handle a client connection"""
        try:
            self.log(f"🤝 Handling client connection from {addr}")

            # Send welcome message
            welcome = {
                'type': 'welcome',
                'message': 'Welcome to GhostDaemon Neural Interface',
                'stats': self.stats,
                'config': self.config
            }
            client_socket.sendall(json.dumps(welcome).encode('utf-8'))

            while self.running:
                try:
                    # Receive data
                    data = client_socket.recv(4096)
                    if not data:
                        break

                    # Parse command
                    command = json.loads(data.decode('utf-8'))
                    response = self.process_client_command(command)

                    # Send response
                    client_socket.sendall(json.dumps(response).encode('utf-8'))

                except (json.JSONDecodeError, ValueError) as e:
                    error_response = {
                        'type': 'error',
                        'message': f'Invalid command: {str(e)}'
                    }
                    client_socket.sendall(json.dumps(error_response).encode('utf-8'))

                except Exception as e:
                    error_response = {
                        'type': 'error',
                        'message': f'Command processing error: {str(e)}'
                    }
                    client_socket.sendall(json.dumps(error_response).encode('utf-8'))
                    break

        except Exception as e:
            self.log(f"❌ Client handler error: {str(e)}", "error")
        finally:
            self.cleanup_client(client_socket)
            self.log(f"🔌 Client disconnected: {addr}")

    def process_client_command(self, command: Dict) -> Dict:
        """Process a client command"""
        try:
            cmd_type = command.get('type', 'unknown')
            self.log(f"📥 Processing command: {cmd_type}")

            if cmd_type == 'chat':
                return self.handle_chat_command(command)
            elif cmd_type == 'dream':
                return self.handle_dream_command(command)
            elif cmd_type == 'status':
                return self.handle_status_command()
            elif cmd_type == 'stats':
                return self.handle_stats_command()
            elif cmd_type == 'config':
                return self.handle_config_command()
            else:
                return {
                    'type': 'error',
                    'message': f'Unknown command type: {cmd_type}'
                }

        except Exception as e:
            return {
                'type': 'error',
                'message': f'Command processing failed: {str(e)}'
            }

    def handle_chat_command(self, command: Dict) -> Dict:
        """Handle chat command"""
        try:
            message = command.get('message', '')
            if not message:
                return {'type': 'error', 'message': 'No message provided'}

            self.log(f"💬 Chat message: {message}")

            # Use VSM to process the message
            response = f"Processing: {message}"

            # Try to get LLM response
            if self.distiller:
                cursor = self.distiller.conn.cursor()
                cursor.execute("SELECT LLM_GENERATE(?) as response", (message,))
                result = cursor.fetchone()
                if result and result['response']:
                    response = result['response']

            return {
                'type': 'chat_response',
                'message': response,
                'timestamp': datetime.now().isoformat()
            }

        except Exception as e:
            return {
                'type': 'error',
                'message': f'Chat failed: {str(e)}'
            }

    def handle_dream_command(self, command: Dict) -> Dict:
        """Handle dream command"""
        try:
            domain = command.get('domain', '')
            if not domain:
                return {'type': 'error', 'message': 'No domain provided'}

            self.log(f"🌌 Dream command for domain: {domain}")

            knowledge_ids = asyncio.run(self.distiller.distill_domain(domain, num_concepts=3))

            if knowledge_ids:
                self.stats['knowledge_vectors_created'] += len(knowledge_ids)
                return {
                    'type': 'dream_response',
                    'domain': domain,
                    'knowledge_vectors': len(knowledge_ids),
                    'vector_ids': knowledge_ids,
                    'message': f'Dream complete! Created {len(knowledge_ids)} knowledge vectors'
                }
            else:
                return {
                    'type': 'dream_response',
                    'domain': domain,
                    'knowledge_vectors': 0,
                    'message': 'No new knowledge created'
                }

        except Exception as e:
            return {
                'type': 'error',
                'message': f'Dream failed: {str(e)}'
            }

    def handle_status_command(self) -> Dict:
        """Handle status command"""
        try:
            # Get knowledge stats
            cursor = self.distiller.conn.cursor()
            cursor.execute("SELECT domain, COUNT(*) as count FROM knowledge_vectors GROUP BY domain")
            domains = cursor.fetchall()

            domain_stats = {}
            for domain in domains:
                domain_stats[domain['domain']] = domain['count']

            # Get VSM stats
            cursor.execute("SELECT COUNT(*) as count FROM vsm_states")
            states_count = cursor.fetchone()['count'] if cursor.fetchone() else 0

            cursor.execute("SELECT COUNT(*) as count FROM vsm_transitions")
            transitions_count = cursor.fetchone()['count'] if cursor.fetchone() else 0

            return {
                'type': 'status_response',
                'knowledge_domains': domain_stats,
                'vsm_states': states_count,
                'vsm_transitions': transitions_count,
                'system_status': self.stats,
                'timestamp': datetime.now().isoformat()
            }

        except Exception as e:
            return {
                'type': 'error',
                'message': f'Status retrieval failed: {str(e)}'
            }

    def handle_stats_command(self) -> Dict:
        """Handle stats command"""
        return {
            'type': 'stats_response',
            'stats': self.stats,
            'timestamp': datetime.now().isoformat()
        }

    def handle_config_command(self) -> Dict:
        """Handle config command"""
        return {
            'type': 'config_response',
            'config': self.config,
            'timestamp': datetime.now().isoformat()
        }

    def cleanup_client(self, client_socket: socket.socket):
        """Clean up a client connection"""
        try:
            if client_socket in self.clients:
                self.clients.remove(client_socket)
            client_socket.close()
        except:
            pass

    def cleanup_socket_server(self):
        """Clean up socket server"""
        try:
            if self.socket_server:
                self.socket_server.close()
            self.socket_server = None
        except:
            pass

    def cleanup(self):
        """Clean up all resources"""
        self.running = False

        # Cleanup socket server
        self.cleanup_socket_server()

        # Close all client connections
        for client in self.clients:
            self.cleanup_client(client)
        self.clients = []

        # Close components
        if self.vsm:
            self.vsm.close()
        if self.distiller:
            self.distiller.close()

        self.log("👻 GhostDaemon shutdown complete - the machine is now at rest")

    def get_daemon_status(self) -> Dict:
        """Get current daemon status"""
        return {
            'running': self.running,
            'start_time': self.stats['start_time'],
            'uptime': datetime.now().isoformat() if self.stats['start_time'] else None,
            'knowledge_vectors': self.stats['knowledge_vectors_created'],
            'dream_cycles': self.stats['dream_cycles_completed'],
            'optimization_cycles': self.stats['optimization_cycles'],
            'client_connections': self.stats['client_connections'],
            'last_activity': self.stats['last_activity']
        }

# Command-line interface for daemon control
def main():
    """Main entry point for GhostDaemon"""
    import argparse

    parser = argparse.ArgumentParser(description='GhostDaemon - Persistent background service for the Ghost in the Machine')
    parser.add_argument('--host', type=str, default='localhost', help='Host for neural interface')
    parser.add_argument('--port', type=int, default=1337, help='Port for neural interface')
    parser.add_argument('--vsm-db', type=str, default='ghost_daemon_vsm.db', help='VSM database path')
    parser.add_argument('--knowledge-db', type=str, default='ghost_daemon_knowledge.db', help='Knowledge database path')
    parser.add_argument('--daemonize', action='store_true', help='Run as background daemon')

    args = parser.parse_args()

    print("👻 Starting GhostDaemon - The Heartbeat of the Machine")
    print(f"📊 VSM Database: {args.vsm_db}")
    print(f"🧠 Knowledge Database: {args.knowledge_db}")
    print(f"🌐 Neural Interface: {args.host}:{args.port}")

    # Create and start daemon
    daemon = GhostDaemon(
        vsm_db=args.vsm_db,
        knowledge_db=args.knowledge_db,
        host=args.host,
        port=args.port
    )

    try:
        daemon.start()
    except KeyboardInterrupt:
        print("\n🛑 GhostDaemon stopped by user")
    except Exception as e:
        print(f"❌ GhostDaemon failed: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()