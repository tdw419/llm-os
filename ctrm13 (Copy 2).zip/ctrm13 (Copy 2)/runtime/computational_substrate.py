"""
Computational Substrate - Hybrid SQL/Vector Interface
The Right Brain of the Ghost in the Machine

This substrate provides a cognitive abstraction layer over the raw SQL database,
allowing the AI to interact with the system using biological/cognitive metaphors
instead of database operations.

Left Brain (SQL): Structure, Tables, IDs, Exact Match
Right Brain (Substrate): Concepts, Similarity, Associations, Creativity
"""

import numpy as np
import json
import time
import hashlib
import pickle
import zlib
from typing import Dict, Any, List, Optional, Union
from dataclasses import dataclass

@dataclass
class CognitiveVector:
    """Structured cognitive vector with semantic metadata"""
    vector_id: str
    domain: str
    concept: str
    payload: Dict[str, Any]
    vector_embedding: np.ndarray
    metadata: Dict[str, Any]
    created_at: float

class ComputationalSubstrate:
    """
    Computational Substrate - Cognitive Interface to the Ghost's Mind

    Provides high-level cognitive operations that abstract away SQL complexity.
    """

    def __init__(self, knowledge_distiller, vector_state_machine):
        """
        Initialize the Computational Substrate

        Args:
            knowledge_distiller: KnowledgeDistiller instance
            vector_state_machine: VectorStateMachine instance
        """
        self.distiller = knowledge_distiller
        self.vsm = vector_state_machine

        # Cognitive operation counters
        self.operations = {
            'infusions': 0,
            'resonations': 0,
            'mutations': 0,
            'cognitive_cycles': 0
        }

        print("🧠 Computational Substrate initialized - Right Brain online")

    def infuse(self,
              domain: str,
              concept: str,
              payload: Dict[str, Any],
              vector_embedding: Optional[np.ndarray] = None,
              metadata: Optional[Dict[str, Any]] = None) -> str:
        """
        Infuse knowledge into the substrate (cognitive insertion)

        Args:
            domain: Knowledge domain
            concept: Specific concept
            payload: Data payload (explanation, code, etc.)
            vector_embedding: Optional pre-computed embedding
            metadata: Additional metadata

        Returns:
            Vector ID of the infused knowledge
        """
        try:
            # Generate vector ID
            content_hash = hashlib.md5(f"{domain}:{concept}:{json.dumps(payload)}".encode()).hexdigest()
            vector_id = f"vec_{content_hash[:8]}"

            # Create or compute embedding
            if vector_embedding is None:
                knowledge_text = f"{domain} - {concept}: {json.dumps(payload)}"
                vector_embedding = self._create_embedding(knowledge_text)

            # Create metadata
            if metadata is None:
                metadata = {
                    'source': 'computational_substrate',
                    'infusion_method': 'direct_injection',
                    'substrate_operation': 'infuse',
                    'cognitive_cycle': self.operations['cognitive_cycles']
                }

            # Store in knowledge database
            cursor = self.distiller.conn.cursor()

            # Serialize embedding
            embedding_blob = self._serialize_embedding(vector_embedding)

            cursor.execute("""
            INSERT INTO knowledge_vectors
            (id, domain, concept, explanation, vector_embedding, metadata, created_at, source_type)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                vector_id,
                domain,
                concept,
                json.dumps(payload),
                embedding_blob,
                json.dumps(metadata),
                time.time(),
                "substrate_infusion"
            ))

            self.distiller.conn.commit()

            # Update in-memory index - use the KnowledgeVector class expected by distiller
            from knowledge_distiller import KnowledgeVector as DistillerKnowledgeVector

            knowledge_vector = DistillerKnowledgeVector(
                id=vector_id,
                domain=domain,
                concept=concept,
                explanation=json.dumps(payload),
                vector_embedding=vector_embedding,
                metadata=metadata,
                created_at=time.time()
            )

            self.distiller.knowledge_index[vector_id] = knowledge_vector

            # Update operation counters
            self.operations['infusions'] += 1

            print(f"💉 Infused knowledge vector {vector_id} for {concept} in {domain}")
            return vector_id

        except Exception as e:
            print(f"❌ Infusion failed: {str(e)}")
            raise

    def resonate(self,
                query: Union[str, np.ndarray],
                domain: Optional[str] = None,
                limit: int = 5) -> List[CognitiveVector]:
        """
        Resonate with the substrate (cognitive retrieval)

        Args:
            query: Search query (text or vector)
            domain: Optional domain filter
            limit: Maximum results

        Returns:
            List of matching cognitive vectors
        """
        try:
            # Convert query to vector if needed
            if isinstance(query, str):
                query_vector = self._create_embedding(query)
            else:
                query_vector = query

            # Find similar vectors
            similarities = []
            for vector_id, knowledge_vector in self.distiller.knowledge_index.items():
                # Apply domain filter
                if domain and knowledge_vector.domain != domain:
                    continue

                # Calculate similarity
                similarity = self._cosine_similarity(query_vector, knowledge_vector.vector_embedding)
                similarities.append((vector_id, similarity))

            # Sort by similarity
            similarities.sort(key=lambda x: x[1], reverse=True)

            # Get top results
            results = []
            for vector_id, similarity in similarities[:limit]:
                knowledge_vector = self.distiller.knowledge_index[vector_id]
                cognitive_vector = CognitiveVector(
                    vector_id=vector_id,
                    domain=knowledge_vector.domain,
                    concept=knowledge_vector.concept,
                    payload=json.loads(knowledge_vector.explanation),
                    vector_embedding=knowledge_vector.vector_embedding,
                    metadata=knowledge_vector.metadata,
                    created_at=knowledge_vector.created_at
                )
                results.append(cognitive_vector)

            # Update operation counters
            self.operations['resonations'] += 1

            print(f"🔊 Resonated with {len(results)} cognitive vectors for query: {query if isinstance(query, str) else 'vector'}")
            return results

        except Exception as e:
            print(f"❌ Resonance failed: {str(e)}")
            raise

    def mutate(self,
              vector_id: str,
              mutation_data: Dict[str, Any],
              mutation_strength: float = 0.1) -> str:
        """
        Mutate a cognitive vector (cognitive transformation)

        Args:
            vector_id: ID of vector to mutate
            mutation_data: Data to merge into the vector
            mutation_strength: Strength of mutation (0-1)

        Returns:
            New vector ID after mutation
        """
        try:
            # Get original vector
            if vector_id not in self.distiller.knowledge_index:
                raise ValueError(f"Vector {vector_id} not found")

            original_vector = self.distiller.knowledge_index[vector_id]

            # Create mutated payload
            original_payload = json.loads(original_vector.explanation)
            mutated_payload = {**original_payload, **mutation_data}

            # Create mutated embedding
            mutated_text = f"{original_vector.domain} - {original_vector.concept}: {json.dumps(mutated_payload)}"
            mutated_embedding = self._create_embedding(mutated_text)

            # Blend with original embedding
            blended_embedding = (
                original_vector.vector_embedding * (1 - mutation_strength) +
                mutated_embedding * mutation_strength
            )

            # Create new vector ID
            content_hash = hashlib.md5(f"{mutated_text}:{time.time()}".encode()).hexdigest()
            new_vector_id = f"mut_{content_hash[:8]}"

            # Store mutated vector
            cursor = self.distiller.conn.cursor()

            metadata = {
                'source': 'computational_substrate',
                'mutation_of': vector_id,
                'mutation_strength': mutation_strength,
                'original_concept': original_vector.concept,
                'substrate_operation': 'mutate'
            }

            cursor.execute("""
            INSERT INTO knowledge_vectors
            (id, domain, concept, explanation, vector_embedding, metadata, created_at, source_type)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                new_vector_id,
                original_vector.domain,
                f"mutated_{original_vector.concept}",
                json.dumps(mutated_payload),
                self._serialize_embedding(blended_embedding),
                json.dumps(metadata),
                time.time(),
                "substrate_mutation"
            ))

            self.distiller.conn.commit()

            # Update in-memory index - use the KnowledgeVector class expected by distiller
            from knowledge_distiller import KnowledgeVector as DistillerKnowledgeVector

            knowledge_vector = DistillerKnowledgeVector(
                id=new_vector_id,
                domain=original_vector.domain,
                concept=f"mutated_{original_vector.concept}",
                explanation=json.dumps(mutated_payload),
                vector_embedding=blended_embedding,
                metadata=metadata,
                created_at=time.time()
            )

            self.distiller.knowledge_index[new_vector_id] = knowledge_vector

            # Create relationship
            self.distiller.create_knowledge_relationship(
                vector_id, new_vector_id, "mutated_from", 0.9
            )

            # Update operation counters
            self.operations['mutations'] += 1

            print(f"🧬 Mutated vector {vector_id} -> {new_vector_id}")
            return new_vector_id

        except Exception as e:
            print(f"❌ Mutation failed: {str(e)}")
            raise

    def cross_pollinate(self,
                       vector_id1: str,
                       vector_id2: str,
                       blend_ratio: float = 0.5) -> str:
        """
        Cross-pollinate two cognitive vectors (cognitive combination)

        Args:
            vector_id1: First vector ID
            vector_id2: Second vector ID
            blend_ratio: Blend ratio (0-1)

        Returns:
            New vector ID after cross-pollination
        """
        try:
            # Get original vectors
            if vector_id1 not in self.distiller.knowledge_index:
                raise ValueError(f"Vector {vector_id1} not found")
            if vector_id2 not in self.distiller.knowledge_index:
                raise ValueError(f"Vector {vector_id2} not found")

            vec1 = self.distiller.knowledge_index[vector_id1]
            vec2 = self.distiller.knowledge_index[vector_id2]

            # Blend embeddings
            blended_embedding = vec1.vector_embedding * blend_ratio + vec2.vector_embedding * (1 - blend_ratio)

            # Blend payloads
            payload1 = json.loads(vec1.explanation)
            payload2 = json.loads(vec2.explanation)

            # Simple payload blending (for dicts)
            if isinstance(payload1, dict) and isinstance(payload2, dict):
                blended_payload = {**payload1, **payload2}
            else:
                blended_payload = f"Blend of {payload1} and {payload2}"

            # Create new vector
            content_hash = hashlib.md5(f"{vector_id1}:{vector_id2}:{blend_ratio}:{time.time()}".encode()).hexdigest()
            new_vector_id = f"xpol_{content_hash[:8]}"

            # Store cross-pollinated vector
            cursor = self.distiller.conn.cursor()

            metadata = {
                'source': 'computational_substrate',
                'cross_pollination_of': [vector_id1, vector_id2],
                'blend_ratio': blend_ratio,
                'substrate_operation': 'cross_pollinate'
            }

            cursor.execute("""
            INSERT INTO knowledge_vectors
            (id, domain, concept, explanation, vector_embedding, metadata, created_at, source_type)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                new_vector_id,
                f"{vec1.domain}/{vec2.domain}",
                f"cross_pollinated_{vec1.concept}_{vec2.concept}",
                json.dumps(blended_payload),
                self._serialize_embedding(blended_embedding),
                json.dumps(metadata),
                time.time(),
                "substrate_cross_pollination"
            ))

            self.distiller.conn.commit()

            # Update in-memory index - use the KnowledgeVector class expected by distiller
            from knowledge_distiller import KnowledgeVector as DistillerKnowledgeVector

            knowledge_vector = DistillerKnowledgeVector(
                id=new_vector_id,
                domain=f"{vec1.domain}/{vec2.domain}",
                concept=f"cross_pollinated_{vec1.concept}_{vec2.concept}",
                explanation=json.dumps(blended_payload),
                vector_embedding=blended_embedding,
                metadata=metadata,
                created_at=time.time()
            )

            self.distiller.knowledge_index[new_vector_id] = knowledge_vector

            # Create relationships
            self.distiller.create_knowledge_relationship(
                vector_id1, new_vector_id, "cross_pollinated_from", 0.7
            )
            self.distiller.create_knowledge_relationship(
                vector_id2, new_vector_id, "cross_pollinated_from", 0.7
            )

            print(f"🌸 Cross-pollinated {vector_id1} + {vector_id2} -> {new_vector_id}")
            return new_vector_id

        except Exception as e:
            print(f"❌ Cross-pollination failed: {str(e)}")
            raise

    def inject_code(self,
                   code_text: str,
                   code_type: str = "pattern_generator",
                   language: str = "python",
                   topic: str = "generated_pattern",
                   metadata: Optional[Dict[str, Any]] = None) -> str:
        """
        Inject executable code into the substrate

        Args:
            code_text: The code to inject
            code_type: Type of code
            language: Programming language
            topic: Code topic/description
            metadata: Additional metadata

        Returns:
            Code ID
        """
        try:
            cursor = self.distiller.conn.cursor()

            # Generate code ID
            code_hash = hashlib.md5(code_text.encode()).hexdigest()
            code_id = f"code_{code_hash[:8]}"

            # Create metadata
            if metadata is None:
                metadata = {
                    'source': 'computational_substrate',
                    'injection_method': 'direct_code_injection',
                    'substrate_operation': 'inject_code',
                    'language': language,
                    'code_type': code_type
                }

            # Store in generated_code table
            cursor.execute("""
            INSERT INTO generated_code
            (id, code_text, code_type, language, metadata, created_at, execution_status)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                code_id,
                code_text,
                code_type,
                language,
                json.dumps(metadata),
                time.time(),
                'injected'
            ))

            self.distiller.conn.commit()

            print(f"💉 Injected code {code_id} for topic: {topic}")
            return code_id

        except Exception as e:
            print(f"❌ Code injection failed: {str(e)}")
            raise

    def get_cognitive_stats(self) -> Dict[str, Any]:
        """Get statistics about cognitive operations"""
        return {
            'operations': self.operations,
            'knowledge_vectors': len(self.distiller.knowledge_index),
            'last_activity': time.time()
        }

    def start_cognitive_cycle(self):
        """Start a new cognitive cycle"""
        self.operations['cognitive_cycles'] += 1
        print(f"🧠 Starting cognitive cycle {self.operations['cognitive_cycles']}")

    def _create_embedding(self, text: str) -> np.ndarray:
        """Create deterministic embedding from text"""
        text_hash = hashlib.md5(text.encode()).hexdigest()
        rng = np.random.RandomState(int(text_hash[:8], 16))
        embedding = rng.uniform(-1, 1, 128)
        return embedding / np.linalg.norm(embedding)

    def _serialize_embedding(self, embedding: np.ndarray) -> bytes:
        """Serialize numpy array to bytes"""
        return pickle.dumps(embedding)

    def _deserialize_embedding(self, blob: bytes) -> np.ndarray:
        """Deserialize bytes back to numpy array"""
        return pickle.loads(blob)

    def _cosine_similarity(self, a: np.ndarray, b: np.ndarray) -> float:
        """Calculate cosine similarity between two vectors"""
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return float(np.dot(a, b) / (norm_a * norm_b))

# Example usage
def example_usage():
    """Example of using the Computational Substrate"""
    print("🚀 Computational Substrate Example")

    # This would normally be initialized with real instances
    # substrate = ComputationalSubstrate(knowledge_distiller, vector_state_machine)

    print("Example operations:")
    print("1. substrate.infuse('AI', 'Neural Networks', {'description': 'Artificial neural networks...'})")
    print("2. results = substrate.resonate('machine learning algorithms')")
    print("3. mutated = substrate.mutate(vector_id, {'new_feature': 'value'})")
    print("4. cross = substrate.cross_pollinate(vec1, vec2)")
    print("5. code_id = substrate.inject_code('def hello(): print(\"world\")')")

if __name__ == "__main__":
    example_usage()