import asyncio
import json
import os
import tempfile
import pytest
from pathlib import Path
from datetime import datetime
import numpy as np

# Add src to path for testing
import sys
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from script2vec.script2vec import Script2Vec
from script2vec.ctrm_script_interface import CTRMScriptInterface
from script2vec.decorators import auto_vectorize, vectorize_class, track_script_evolution
from script2vec.cli import Script2VecCLI

def test_script2vec_initialization():
    """Test Script2Vec initialization"""
    s2v = Script2Vec()
    assert s2v is not None
    assert s2v.default_vector_dim == 1536
    assert len(s2v.vector_cache) == 0

def test_python_to_vector_basic():
    """Test basic Python to vector conversion"""
    s2v = Script2Vec()

    # Simple Python script
    script = """
def hello_world():
    '''A simple hello world function'''
    print("Hello, World!")

# Call the function
hello_world()
"""

    # Test semantic embedding
    result = s2v.python_to_vector(script, strategy="semantic")
    assert "vector" in result
    assert "script_hash" in result
    assert "concepts" in result
    assert result["type"] == "semantic"
    assert len(result["vector"]) == 1536
    assert isinstance(result["vector"], list)

    # Test AST embedding
    result_ast = s2v.python_to_vector(script, strategy="ast")
    assert "vector" in result_ast
    assert "features" in result_ast
    assert result_ast["type"] == "ast"
    assert len(result_ast["vector"]) == 1536

    # Test hybrid embedding
    result_hybrid = s2v.python_to_vector(script, strategy="hybrid")
    assert "vector" in result_hybrid
    assert "components" in result_hybrid
    assert result_hybrid["type"] == "hybrid"
    assert len(result_hybrid["vector"]) == 1536

def test_script2vec_caching():
    """Test vector caching functionality"""
    s2v = Script2Vec()

    script = "def test(): pass"

    # First call - should not be cached
    result1 = s2v.python_to_vector(script, strategy="semantic")
    cache_stats = s2v.get_cache_stats()
    assert cache_stats["cached_vectors"] == 1

    # Second call - should be cached
    result2 = s2v.python_to_vector(script)
    assert result1["script_hash"] == result2["script_hash"]
    assert cache_stats["cached_vectors"] == 1  # Should still be 1 (cached)

    # Clear cache
    s2v.clear_cache()
    assert s2v.get_cache_stats()["cached_vectors"] == 0

def test_ctrm_format_conversion():
    """Test CTRM format conversion"""
    s2v = Script2Vec()

    script = """
import numpy as np

def calculate_mean(data):
    '''Calculate the mean of a dataset'''
    return np.mean(data)
"""

    ctrm_format = s2v.to_ctrm_format(script)
    assert "vector" in ctrm_format
    assert "source" in ctrm_format
    assert ctrm_format["source"] == "python_script"
    assert "script_hash" in ctrm_format
    assert "concepts" in ctrm_format
    assert "metadata" in ctrm_format
    assert "lines_of_code" in ctrm_format["metadata"]

def test_file_embedding():
    """Test file embedding functionality"""
    s2v = Script2Vec()

    # Create a temporary Python file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
        f.write("""
def test_function():
    '''Test function for embedding'''
    return "test"
""")
        temp_file = f.name

    try:
        # Embed the file
        result = s2v.embed_file(temp_file)
        assert "vector" in result
        assert "script_hash" in result
        assert result["type"] == "semantic"  # Default strategy

    finally:
        # Clean up
        os.unlink(temp_file)

def test_directory_embedding():
    """Test directory embedding functionality"""
    s2v = Script2Vec()

    # Create a temporary directory with Python files
    with tempfile.TemporaryDirectory() as temp_dir:
        # Create some test files
        for i in range(3):
            with open(os.path.join(temp_dir, f"test_{i}.py"), 'w') as f:
                f.write(f"""
def function_{i}():
    '''Function {i}'''
    return {i}
""")

        # Embed the directory
        result = s2v.embed_directory(temp_dir)
        assert "directory_vector" in result
        assert "file_vectors" in result
        assert "file_count" in result
        assert result["file_count"] == 3
        assert len(result["file_vectors"]) == 3

def test_similarity_search():
    """Test similarity search functionality"""
    s2v = Script2Vec()

    # Create some test scripts
    script1 = """
def add(a, b):
    return a + b
"""

    script2 = """
def subtract(a, b):
    return a - b
"""

    script3 = """
def multiply(a, b):
    return a * b
"""

    # Create a database of scripts
    script_db = {
        "add": s2v.python_to_vector(script1)["vector"],
        "subtract": s2v.python_to_vector(script2)["vector"],
        "multiply": s2v.python_to_vector(script3)["vector"]
    }

    # Search for similar scripts
    query = """
def sum_numbers(x, y):
    return x + y
"""

    similar = s2v.find_similar_scripts(query, script_db, threshold=0.1)
    assert len(similar) > 0
    assert similar[0]["similarity"] >= 0.1

def test_cosine_similarity():
    """Test cosine similarity calculation"""
    s2v = Script2Vec()

    # Test with identical vectors
    vec1 = [1.0, 0.0, 0.0]
    vec2 = [1.0, 0.0, 0.0]
    similarity = s2v.cosine_similarity(vec1, vec2)
    assert similarity == 1.0

    # Test with orthogonal vectors
    vec3 = [1.0, 0.0, 0.0]
    vec4 = [0.0, 1.0, 0.0]
    similarity = s2v.cosine_similarity(vec3, vec4)
    assert similarity == 0.0

    # Test with random vectors
    vec5 = [1.0, 2.0, 3.0]
    vec6 = [4.0, 5.0, 6.0]
    similarity = s2v.cosine_similarity(vec5, vec6)
    assert 0.0 <= similarity <= 1.0

@pytest.mark.asyncio
async def test_ctrm_interface():
    """Test CTRM interface functionality"""
    interface = CTRMScriptInterface()

    script = """
def test_function():
    '''Test function for CTRM'''
    return "CTRM test"
"""

    # Test script to CTRM conversion
    result = await interface.script_to_ctrm(script, purpose="test")
    assert "script_hash" in result
    assert "ctrm_vector_hash" in result
    assert "vector" in result
    assert "status" in result
    assert result["status"] == "submitted"

    # Test finding similar code
    similar = await interface.find_similar_code_in_ctrm(script, threshold=0.7)
    assert isinstance(similar, list)

    # Test script improvement
    improvement = await interface.improve_script_via_ctrm(script, improvement_type="optimize")
    assert "suggestions" in improvement
    assert "improved_vector_hash" in improvement

    # Test script analysis
    analysis = await interface.analyze_script_quality(script)
    assert "quality_score" in analysis
    assert "analysis" in analysis

@pytest.mark.asyncio
async def test_decorators():
    """Test decorator functionality"""

    # Test auto_vectorize decorator
    @auto_vectorize(purpose="test_function", store_in_ctrm=False)
    def test_function():
        return "test"

    result = test_function()
    assert result == "test"

    # Test vectorize_class decorator
    @vectorize_class(purpose="test_class", store_in_ctrm=False)
    class TestClass:
        def method(self):
            return "method"

    obj = TestClass()
    assert obj.method() == "method"

    # Test track_script_evolution decorator
    @track_script_evolution(purpose="test_evolution", store_in_ctrm=False)
    def evolving_function():
        return "original"

    result = evolving_function()
    assert result == "original"

def test_cli_initialization():
    """Test CLI initialization"""
    cli = Script2VecCLI()
    assert cli is not None
    assert cli.script2vec is not None
    assert cli.ctrm_interface is not None
    assert cli.parser is not None

@pytest.mark.asyncio
async def test_cli_convert_command():
    """Test CLI convert command"""
    cli = Script2VecCLI()

    # Create a temporary Python file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
        f.write("""
def cli_test():
    return "CLI test"
""")
        temp_file = f.name

    try:
        # Create args for convert command
        class Args:
            command = "convert"
            filepath = temp_file
            output = None
            strategy = "semantic"
            ctrm = False
            purpose = "test"

        result = await cli._handle_convert(Args())
        assert "vector" in result
        assert "script_hash" in result

    finally:
        # Clean up
        os.unlink(temp_file)

def test_web_interface_initialization():
    """Test web interface initialization"""
    try:
        from script2vec.web_interface import Script2VecWebInterface
        web_interface = Script2VecWebInterface(host="127.0.0.1", port=8001)

        # Check if FastAPI is available
        if web_interface.available:
            assert web_interface.app is not None
            assert web_interface.script2vec is not None
            assert web_interface.ctrm_interface is not None
        else:
            print("FastAPI not available - skipping web interface test")
            assert True

    except ImportError:
        print("FastAPI not available - skipping web interface test")
        assert True

def test_comprehensive_integration():
    """Test comprehensive integration of all components"""
    # Create instances
    s2v = Script2Vec()
    ctrm_interface = CTRMScriptInterface()

    # Test script
    test_script = """
import numpy as np
from typing import List, Dict

class DataProcessor:
    '''A class for processing data'''

    def __init__(self, data: List[float]):
        self.data = data
        self.mean = np.mean(data)
        self.std = np.std(data)

    def normalize(self) -> List[float]:
        '''Normalize the data'''
        return [(x - self.mean) / self.std for x in self.data]

    def analyze(self) -> Dict:
        '''Analyze the data'''
        return {
            'mean': self.mean,
            'std': self.std,
            'min': min(self.data),
            'max': max(self.data)
        }

# Example usage
if __name__ == "__main__":
    processor = DataProcessor([1, 2, 3, 4, 5])
    normalized = processor.normalize()
    analysis = processor.analyze()
    print(f"Analysis: {analysis}")
"""

    # Test vector conversion
    vector_result = s2v.python_to_vector(test_script)
    assert "vector" in vector_result
    assert len(vector_result["vector"]) == 1536

    # Test CTRM conversion
    async def test_ctrm():
        ctrm_result = await ctrm_interface.script_to_ctrm(test_script, purpose="comprehensive_test")
        assert "ctrm_vector_hash" in ctrm_result

        # Test similarity search
        similar = await ctrm_interface.find_similar_code_in_ctrm(test_script)
        assert isinstance(similar, list)

        # Test improvement
        improvement = await ctrm_interface.improve_script_via_ctrm(test_script, improvement_type="optimize")
        assert "suggestions" in improvement

    # Run async test
    asyncio.run(test_ctrm())

def test_performance_and_scalability():
    """Test performance and scalability"""
    s2v = Script2Vec()

    # Test with multiple scripts
    scripts = []
    for i in range(10):
        scripts.append(f"""
def function_{i}(x, y):
    '''Function {i}'''
    return x + y + {i}

class Class_{i}:
    def method(self):
        return {i}
""")

    # Time the conversions
    import time
    start_time = time.time()

    results = []
    for script in scripts:
        result = s2v.python_to_vector(script)
        results.append(result)

    end_time = time.time()

    # Should complete reasonably quickly
    assert len(results) == 10
    assert end_time - start_time < 5.0  # Should take less than 5 seconds

    # Test caching performance
    start_time = time.time()

    cached_results = []
    for script in scripts:
        result = s2v.python_to_vector(script)  # Should be cached
        cached_results.append(result)

    end_time = time.time()

    # Cached version should be faster
    cached_time = end_time - start_time
    assert cached_time < 1.0  # Should be very fast with caching

def test_error_handling():
    """Test error handling"""
    s2v = Script2Vec()

    # Test with invalid Python syntax
    invalid_script = "def invalid syntax here"

    # Should fall back to semantic embedding
    result = s2v.python_to_vector(invalid_script, strategy="ast_embedding")
    assert "vector" in result
    assert result["type"] == "semantic"  # Should fall back to semantic

    # Test with empty script
    empty_script = ""
    result = s2v.python_to_vector(empty_script)
    assert "vector" in result

if __name__ == "__main__":
    # Run all tests
    test_script2vec_initialization()
    test_python_to_vector_basic()
    test_script2vec_caching()
    test_ctrm_format_conversion()
    test_file_embedding()
    test_directory_embedding()
    test_similarity_search()
    test_cosine_similarity()

    # Run async tests
    asyncio.run(test_ctrm_interface())
    asyncio.run(test_decorators())

    test_cli_initialization()
    asyncio.run(test_cli_convert_command())
    test_web_interface_initialization()
    test_comprehensive_integration()
    test_performance_and_scalability()
    test_error_handling()

    print("✅ All Script2Vec tests passed!")