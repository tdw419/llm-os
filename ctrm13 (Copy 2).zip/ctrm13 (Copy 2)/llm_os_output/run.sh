#!/bin/bash
echo "Starting LLM OS..."
cd "$(dirname "$0")"
python bootstrap.py
